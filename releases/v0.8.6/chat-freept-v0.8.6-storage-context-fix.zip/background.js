"use strict";
const ALARM = "cfpt-run-watch";
const STORE = "cfpt:background-runs:v1";
const PERIOD_MINUTES = 0.5;
const MAX_MISSED_HEARTBEATS = 5;
const RUN_LOCK_PREFIX = "cfpt:lock:";
let pending = Promise.resolve();

async function listRuns() {
  return (await chrome.storage.session.get(STORE))[STORE] ?? {};
}
async function saveRuns(runs) {
  await chrome.storage.session.set({ [STORE]: runs });
  if (Object.keys(runs).length) {
    if (!(await chrome.alarms.get(ALARM))) {
      await chrome.alarms.create(ALARM, { periodInMinutes: PERIOD_MINUTES });
    }
  } else {
    await chrome.alarms.clear(ALARM);
  }
}
async function releaseLock(run) {
  if (!run?.conversationId || !run?.nonce) return;
  const key = RUN_LOCK_PREFIX + run.conversationId;
  const lock = (await chrome.storage.local.get(key))[key];
  if (lock?.nonce === run.nonce) await chrome.storage.local.remove(key);
}
async function setActivity(tab, message) {
  if (!tab?.id || !/^https:\/\/(chatgpt\.com|chat\.openai\.com)\//.test(tab.url ?? "")) return;
  const id = String(tab.id);
  const runs = await listRuns();
  const previous = runs[id];
  if (message.active && typeof message.conversationId === "string" && message.conversationId &&
      typeof message.nonce === "string" && message.nonce) {
    if (previous?.conversationId && previous.conversationId !== message.conversationId) {
      await releaseLock(previous);
    }
    runs[id] = {
      conversationId: message.conversationId,
      nonce: message.nonce,
      previousAutoDiscardable: previous?.previousAutoDiscardable ?? tab.autoDiscardable !== false,
      failedWakes: 0
    };
    // Active development tabs should not be auto-discarded by Memory Saver.
    try { await chrome.tabs.update(tab.id, { autoDiscardable: false }); } catch { /* Chrome policy */ }
  } else if (previous) {
    delete runs[id];
    try { if (previous.previousAutoDiscardable) await chrome.tabs.update(tab.id, { autoDiscardable: true }); } catch { /* tab closed */ }
    // Normal inactivity need not delete the lock; existing tab logic owns the lock lifecycle.
  }
  await saveRuns(runs);
}
function enqueue(task) {
  pending = pending.then(task).catch(error => console.warn("[ChatFreePT] background watch", error));
}
chrome.runtime.onMessage.addListener((message, sender) => {
  if (message?.type === "cfpt-run-activity") {
    enqueue(() => setActivity(sender.tab, message));
    return;
  }
  switch (message?.type) {
    case "notify":
      void chrome.notifications.create({
        type: "basic", iconUrl: "icons/icon128.png", title: message.title, message: message.message
      });
      break;
    case "badge": {
      const tabId = sender.tab?.id;
      void chrome.action.setBadgeBackgroundColor({ color: "#10a37f" });
      void chrome.action.setBadgeText(tabId !== undefined ? { text: message.text, tabId } : { text: message.text });
      break;
    }
  }
});
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name !== ALARM) return;
  enqueue(async () => {
    const runs = await listRuns();
    for (const [key, run] of Object.entries(runs)) {
      const tabId = Number(key);
      let tab;
      try { tab = await chrome.tabs.get(tabId); } catch {
        await releaseLock(run);
        delete runs[key];
        continue;
      }
      if (!/^https:\/\/(chatgpt\.com|chat\.openai\.com)\//.test(tab.url ?? "")) {
        await releaseLock(run);
        delete runs[key];
        continue;
      }
      // Preserve tab ownership even if the page's JS timers are throttled or temporarily frozen.
      const lockKey = RUN_LOCK_PREFIX + run.conversationId;
      const lock = (await chrome.storage.local.get(lockKey))[lockKey];
      if (!lock || lock.nonce !== run.nonce) {
        delete runs[key];
        continue;
      }
      // A tab that is frozen might not answer messages for minutes. Do not
      // permanently unregister it: that made background automation stop until
      // the user returned to the tab. Once it misses several wakes, stop
      // refreshing its lock so another live tab can safely take over.
      if ((run.failedWakes ?? 0) < MAX_MISSED_HEARTBEATS) {
        await chrome.storage.local.set({ [lockKey]: { ...lock, at: Date.now() } });
      }
      if (tab.discarded) {
        // Discarded pages have no live owner; release the lock for safe reload recovery.
        delete runs[key];
        await releaseLock(run);
        continue;
      }
      try {
        const wake = chrome.tabs.sendMessage(tabId, {
          type: "cfpt-background-wake", conversationId: run.conversationId, nonce: run.nonce
        });
        const reply = await Promise.race([
          wake,
          new Promise((_, reject) => setTimeout(() => reject(new Error("Wake timed out")), 6000))
        ]);
        if (reply?.active) run.failedWakes = 0;
        else {
          delete runs[key];
          if (run.previousAutoDiscardable) {
            try { await chrome.tabs.update(tabId, { autoDiscardable: true }); } catch {}
          }
        }
      } catch {
        // Keep retrying the existing tab without forcing it to the foreground.
        // Its lock will naturally expire if the tab remains unresponsive.
        run.failedWakes = Math.min((run.failedWakes ?? 0) + 1, MAX_MISSED_HEARTBEATS);
      }
    }
    await saveRuns(runs);
  });
});
// One cleanup path prevents stale registrations and restores Chrome's discard
// policy when a running tab leaves ChatGPT or closes.
async function forgetTab(tabId) {
  const runs = await listRuns();
  const key = String(tabId);
  const run = runs[key];
  if (!run) return;
  delete runs[key];
  await releaseLock(run);
  if (run.previousAutoDiscardable) {
    try { await chrome.tabs.update(tabId, { autoDiscardable: true }); } catch { /* closed */ }
  }
  await saveRuns(runs);
}
chrome.tabs.onUpdated.addListener((tabId, change) => {
  if (change.url && !/^https:\/\/(chatgpt\.com|chat\.openai\.com)\//.test(change.url)) {
    enqueue(() => forgetTab(tabId));
  }
});
chrome.tabs.onRemoved.addListener((tabId) => enqueue(() => forgetTab(tabId)));
chrome.runtime.onStartup.addListener(() => {
  enqueue(async () => saveRuns(await listRuns()));
});
chrome.action.onClicked.addListener((tab) => {
  const url = tab.url ?? "";
  if (tab.id !== undefined && /https:\/\/(chatgpt\.com|chat\.openai\.com)\//.test(url)) {
    void chrome.tabs.sendMessage(tab.id, { type: "toggle-panel" }).catch(async () => {
      if (await injectIntoChatGptTab(tab)) {
        try { await chrome.tabs.sendMessage(tab.id, { type: "toggle-panel" }); return; } catch {}
      }
      await chrome.runtime.openOptionsPage();
    });
  } else {
    void chrome.runtime.openOptionsPage();
  }
});

// Single-writer lock broker: persistent state survives service-worker restarts, while
// tab identity lets the next page load recover an orphaned lock without a 90s wait.
const LOCK_STALE_MS = 90000;
const CHATGPT_URLS = ["https://chatgpt.com/*", "https://chat.openai.com/*"];
const LOCK_ACTIONS = new Set(["acquire", "heartbeat", "release"]);

function sameConversation(url, conversationId) {
  try {
    const parsed = new URL(url);
    if (!(["chatgpt.com", "chat.openai.com"].includes(parsed.hostname))) return false;
    return parsed.pathname.split("/").includes(conversationId);
  } catch { return false; }
}
async function ownerResponds(tabId, lock, conversationId) {
  try {
    const reply = await Promise.race([
      chrome.tabs.sendMessage(tabId, { type: "cfpt-owner-probe", conversationId, nonce: lock.nonce }),
      new Promise(resolve => setTimeout(() => resolve(null), 1250))
    ]);
    return reply?.owned === true;
  } catch { return false; }
}
async function legacyOwnerMayBeAlive(conversationId, lock, requesterId) {
  // v0.7.7 locks omitted tabId. With no other matching tab, the old owner
  // cannot exist: reclaim immediately, rather than showing a false read-only UI.
  const tabs = await chrome.tabs.query({ url: CHATGPT_URLS });
  const others = tabs.filter(tab => tab.id !== requesterId && sameConversation(tab.url, conversationId));
  if (!others.length) return false;
  for (const tab of others) {
    if (tab.id !== undefined && await ownerResponds(tab.id, lock, conversationId)) return true;
  }
  // Old content versions cannot answer probes; retain a fresh lease if a
  // second eligible tab exists rather than risk simultaneous automation.
  return Date.now() - lock.at < LOCK_STALE_MS;
}
async function acquireConversationLock(conversationId, nonce, tabId) {
  const key = RUN_LOCK_PREFIX + conversationId;
  const lock = (await chrome.storage.local.get(key))[key];
  if (lock && lock.nonce !== nonce) {
    if (typeof lock.tabId === "number" && lock.tabId !== tabId) {
      let tab;
      try { tab = await chrome.tabs.get(lock.tabId); } catch { /* closed tab */ }
      if (tab && !tab.discarded && sameConversation(tab.url, conversationId)) {
        // An existing page still owns this conversation while its lease is fresh.
        // After expiration, probe the owner before allowing takeover.
        if (Date.now() - lock.at < LOCK_STALE_MS ||
            await ownerResponds(lock.tabId, lock, conversationId)) return false;
      }
    } else if (lock.tabId === undefined &&
               await legacyOwnerMayBeAlive(conversationId, lock, tabId)) {
      return false;
    }
    // Same tab reloaded, owner tab closed/navigated/discarded, or expired lease.
  }
  await chrome.storage.local.set({ [key]: { tabId, nonce, at: Date.now() } });
  return true;
}
async function handleConversationLock(message, tab) {
  const { action, conversationId, nonce } = message;
  if (!LOCK_ACTIONS.has(action) || typeof conversationId !== "string" ||
      !conversationId || conversationId.length > 160 ||
      typeof nonce !== "string" || !nonce || nonce.length > 160 ||
      !Number.isInteger(tab?.id) || !isChatGptTab(tab.url ?? "")) return false;
  const key = RUN_LOCK_PREFIX + conversationId;
  if (action === "acquire") return acquireConversationLock(conversationId, nonce, tab.id);
  const lock = (await chrome.storage.local.get(key))[key];
  if (!lock || lock.nonce !== nonce ||
      (typeof lock.tabId === "number" && lock.tabId !== tab.id)) return false;
  if (action === "release") {
    await chrome.storage.local.remove(key);
  } else {
    await chrome.storage.local.set({ [key]: { tabId: tab.id, nonce, at: Date.now() } });
  }
  return true;
}
// Small host check: Chrome content messages originate only from matching sites.
function isChatGptTab(url) {
  try { return ["chatgpt.com", "chat.openai.com"].includes(new URL(url).hostname); }
  catch { return false; }
}
chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (message?.type !== "cfpt-lock") return false;
  // Lock operations join the same queue as background cleanup and alarm writes.
  pending = pending.then(async () => {
    if (!isChatGptTab(sender.tab?.url ?? "")) return { ok: false, owned: false };
    return { ok: true, owned: await handleConversationLock(message, sender.tab) };
  }).then(reply => { respond(reply); }, error => {
    console.warn("[ChatFreePT] conversation lock", error);
    respond({ ok: false, owned: false });
  });
  return true;
});

// Manifest content scripts do not run retroactively in already-open tabs after
// installation, updates, or browser session restore. Idempotency is enforced by
// the content script itself, so these attempts cannot create duplicate loops.
async function injectIntoChatGptTab(tab) {
  if (!Number.isInteger(tab?.id) || tab.discarded || !isChatGptTab(tab.url ?? "")) return false;
  try {
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] });
    return true;
  } catch (error) {
    console.debug("[ChatFreePT] tab will initialize on next navigation", error);
    return false;
  }
}
async function injectIntoOpenChatGptTabs() {
  const tabs = await chrome.tabs.query({ url: ["https://chatgpt.com/*", "https://chat.openai.com/*"] });
  for (const tab of tabs) await injectIntoChatGptTab(tab);
}
function startExistingTabInjection() {
  void injectIntoOpenChatGptTabs().catch(error => console.warn("[ChatFreePT] tab injection", error));
}
chrome.runtime.onInstalled?.addListener(startExistingTabInjection);
chrome.runtime.onStartup?.addListener(startExistingTabInjection);

// Storage operations are a narrow fallback for content-script worlds where
// chrome.runtime messaging works but chrome.storage is not exposed. The
// service worker remains the only privileged broker; page storage is never used.
chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (message?.type !== "cfpt-storage") return false;
  if (!isChatGptTab(sender.tab?.url ?? "")) {
    respond({ ok: false, error: "unrecognized sender" });
    return false;
  }
  const { area, operation, payload } = message;
  const validKey = (key) => typeof key === "string" && key.startsWith("cfpt:") && key.length <= 230 &&
    (area === "local" || key === "cfpt:settings");
  const keys = operation === "set" && payload && typeof payload === "object" && !Array.isArray(payload)
    ? Object.keys(payload) : Array.isArray(payload) ? payload : [payload];
  if (!(area === "local" || area === "sync") ||
      !(operation === "get" || operation === "set" || (area === "local" && operation === "remove")) ||
      keys.length < 1 || keys.length > 50 || !keys.every(validKey) ||
      (operation === "set" && (payload === null || typeof payload !== "object" || Array.isArray(payload)))) {
    respond({ ok: false, error: "invalid storage request" });
    return false;
  }
  (async () => {
    const storage = chrome.storage[area];
    if (!storage || typeof storage[operation] !== "function") {
      return { ok: false, error: "browser storage API unavailable" };
    }
    const value = await storage[operation](payload);
    return { ok: true, value: value ?? null };
  })().then(respond, () => respond({ ok: false, error: "storage operation failed" }));
  return true;
});
