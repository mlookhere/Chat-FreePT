"use strict";
(() => {
  // src/page/chat-state-bridge.ts
  var BRIDGE_SOURCE = "cfpt-chat-state-bridge";
  var EVENT_VERSION = 1;
  var installed = false;
  var requestSeq = 0;
  function emit(payload) {
    window.postMessage(
      { source: BRIDGE_SOURCE, payload: { version: EVENT_VERSION, ...payload } },
      "*"
    );
  }
  function nextRequestId() {
    requestSeq += 1;
    return `turn-${requestSeq}`;
  }
  function absoluteUrl(input) {
    if (typeof input === "string") return input;
    if (input instanceof URL) return input.toString();
    return input.url;
  }
  function pathname(input) {
    try {
      return new URL(absoluteUrl(input), location.href).pathname;
    } catch {
      return "";
    }
  }
  function method(input, init) {
    if (init?.method) return init.method.toUpperCase();
    return input instanceof Request ? input.method.toUpperCase() : "GET";
  }
  function collectStrings(value, out) {
    if (typeof value === "string") {
      out.push(value);
      return;
    }
    if (Array.isArray(value)) {
      for (const item of value) collectStrings(item, out);
      return;
    }
    if (!value || typeof value !== "object") return;
    for (const item of Object.values(value)) collectStrings(item, out);
  }
  function protocolCandidateText(raw) {
    const pieces = [raw, raw.replace(/\\n/g, "\n").replace(/\\"/g, '"')];
    for (const line of raw.split(/\r?\n/)) {
      const trimmed = line.trim();
      if (!trimmed.startsWith("data:")) continue;
      const body = trimmed.slice(5).trim();
      if (!body || body === "[DONE]") continue;
      try {
        const parsed = JSON.parse(body);
        const strings = [];
        collectStrings(parsed, strings);
        if (strings.length > 0) pieces.push(strings.join(""));
      } catch {
      }
    }
    try {
      const parsed = JSON.parse(raw);
      const strings = [];
      collectStrings(parsed, strings);
      if (strings.length > 0) pieces.push(strings.join(""));
    } catch {
    }
    return pieces.join("\n");
  }
  function markerSummary(status, fields) {
    const parts = [status];
    for (const key of ["PHASE", "REPO", "ITEM", "NOTE"]) {
      const value = fields[key];
      if (value) parts.push(`${key.toLowerCase()}=${value}`);
    }
    return parts.join(" ");
  }
  function extractMarker(raw) {
    const text = protocolCandidateText(raw);
    const match = lastStatusMatch(text);
    if (!match?.[1]) return null;
    const status = match[1].toUpperCase();
    const fields = parseMarkerFields(text.slice(match.index).trimStart());
    const payload = buildMarkerPayload(status, fields);
    assignOptionalMarkerFields(payload, fields);
    payload.text += `
# ${markerSummary(status, fields)}`;
    return payload;
  }
  function lastStatusMatch(text) {
    const statusRe = /(?:^|\n)\s*(?:>\s*)?(?:\*\*|__|`)?CHATFREEPT_STATUS(?:\*\*|__|`)?\s*:(?:\*\*|__|`)?\s*(CONTINUE|NEEDS(?:[_ -]+)INPUT|PLAN(?:[_ -]+)READY|TESTING|COMPLETE|ERROR)\b/gi;
    let match = null;
    for (let next = statusRe.exec(text); next; next = statusRe.exec(text)) match = next;
    return match;
  }
  function parseMarkerFields(tail) {
    const fields = {};
    for (const line of tail.split(/\r?\n/).slice(1, 29)) {
      const trimmed = line.trim();
      if (!trimmed || /^`{3,}/.test(trimmed)) continue;
      const field = /^\s*(?:>\s*)?(?:\*\*|__|`)?(V|PHASE|REPO|ITEM|NOTE|URL|BRANCH|ISSUE|PR|CI|CHECKS|ACTIONS)(?:\*\*|__|`)?\s*:(?:\*\*|__|`)?\s*(.+?)\s*$/i.exec(line);
      if (!field?.[1] || !field[2]) break;
      const value = field[2].replace(/\\n/g, " ").replace(/^(?:\*\*|__|`)+|(?:\*\*|__|`)+$/g, "").trim();
      const link = /^\[([^\]]+)\]\((https:\/\/[^)]+)\)$/.exec(value);
      fields[field[1].toUpperCase()] = link ? link[2] : value;
    }
    return fields;
  }
  function buildMarkerPayload(status, fields) {
    const keys = ["V", "PHASE", "REPO", "ITEM", "NOTE", "URL", "BRANCH", "ISSUE", "PR", "CI", "CHECKS", "ACTIONS"];
    const lines = keys.flatMap((key) => fields[key] ? [`${key}: ${fields[key]}`] : []);
    return {
      status,
      version: Number.parseInt(fields["V"] ?? "1", 10) || 1,
      text: [`CHATFREEPT_STATUS: ${status}`, ...lines].join("\n")
    };
  }
  function assignOptionalMarkerFields(payload, fields) {
    if (fields["PHASE"]) payload.phase = fields["PHASE"];
    if (fields["REPO"]) payload.repo = fields["REPO"];
    if (fields["ITEM"]) payload.item = fields["ITEM"];
    if (fields["NOTE"]) payload.note = fields["NOTE"];
    if (fields["URL"]) payload.url = fields["URL"];
    if (fields["BRANCH"]) payload.branch = fields["BRANCH"];
    if (fields["ISSUE"]) payload.issue = fields["ISSUE"];
    if (fields["PR"]) payload.pr = fields["PR"];
    if (fields["CI"]) payload.ci = fields["CI"];
    if (fields["CHECKS"]) payload.checks = fields["CHECKS"];
    if (fields["ACTIONS"]) payload.actions = fields["ACTIONS"];
  }
  async function inspectConversationResponse(response, requestId) {
    try {
      const raw = await response.text();
      emit({ event: "generation-complete", requestId, marker: extractMarker(raw) });
    } catch (error) {
      const name = error instanceof Error ? error.name : "";
      emit({
        event: "generation-aborted",
        requestId,
        reason: name || "response-read-failed"
      });
    }
  }
  async function inspectStreamStatus(response, requestId) {
    try {
      const body = await response.json();
      if (typeof body.status === "string") {
        emit({ event: "stream-status", requestId, status: body.status.toUpperCase() });
      }
    } catch {
    }
  }
  function install() {
    if (installed) return;
    installed = true;
    const nativeFetch = window.fetch.bind(window);
    window.fetch = async (input, init) => {
      const path = pathname(input);
      const verb = method(input, init);
      const requestId = nextRequestId();
      const isConversation = verb === "POST" && path === "/backend-api/f/conversation";
      const isStop = verb === "POST" && path === "/backend-api/stop_conversation";
      const isStreamStatus = verb === "GET" && /\/backend-api\/conversation\/[^/]+\/stream_status$/.test(path);
      if (isConversation) emit({ event: "generation-start", requestId });
      if (isStop) emit({ event: "generation-interrupted", requestId, reason: "stop_conversation" });
      try {
        const response = await nativeFetch(input, init);
        if (isConversation) void inspectConversationResponse(response.clone(), requestId);
        if (isStreamStatus) void inspectStreamStatus(response.clone(), requestId);
        return response;
      } catch (error) {
        if (isConversation) {
          const name = error instanceof Error ? error.name : "fetch-failed";
          emit({ event: "generation-aborted", requestId, reason: name });
        }
        throw error;
      }
    };
  }
  if (!window.__CFPT_CHAT_STATE_BRIDGE__) {
    window.__CFPT_CHAT_STATE_BRIDGE__ = true;
    install();
  }
})();
