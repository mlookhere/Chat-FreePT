"use strict";
(() => {
  // A stale content-script world can outlive an unpacked extension reload. In that
  // case the page may still expose window.chrome, but its privileged APIs are gone.
  // Do not install observers or a permanent startup sentinel in that world.
  if (typeof globalThis.chrome?.runtime?.sendMessage !== "function" ||
      typeof globalThis.chrome?.runtime?.onMessage?.addListener !== "function") {
    console.warn("[ChatFreePT] Extension context unavailable. Reload this ChatGPT tab after enabling or updating Chat FreePT.");
    return;
  }
  if (globalThis.__CHATFREEPT_V079_STARTED__) return;
  globalThis.__CHATFREEPT_V079_STARTED__ = true;
  // src/common/log.ts
  var PREFIX = "[ChatFreePT]";
  var log = {
    debug: (...args) => console.debug(PREFIX, ...args),
    info: (...args) => console.info(PREFIX, ...args),
    warn: (...args) => console.warn(PREFIX, ...args),
    error: (...args) => console.error(PREFIX, ...args)
  };

  // src/common/prompts.ts
  var FENCE = "```";
  function renderTemplate(template, vars) {
    const out = template.replace(/\{\{([A-Z_]+)\}\}/g, (whole, key) => {
      const value = vars[key];
      return value === void 0 ? whole : value;
    });
    const leftover = out.match(/\{\{[A-Z_]+\}\}/);
    if (leftover) throw new Error(`Unresolved template placeholder: ${leftover[0]}`);
    return out;
  }
  var MARKER_BLOCK = `## Status marker

End every reply with this fenced block as the final thing in the reply:

${FENCE}chatfreept
CHATFREEPT_STATUS: <Continue | Needs input | Plan ready | Testing | Complete | Error>
V: 1
PHASE: <Planning | Developing | Testing>
REPO: <owner/name>
ITEM: <n/m \u2014 current plan item, when applicable>
NOTE: <one short line describing the current work>
BRANCH: <work branch or dev/main when known; otherwise omit>
ISSUE: <actual GitHub issue URL when available; otherwise omit>
PR: <actual GitHub pull request URL when available; otherwise omit>
CI: <Not run | Queued | Running | Passed | Failed | Cancelled | Unknown>
CHECKS: <required/passed/pending/failed counts or short check summary, if available>
ACTIONS: <actual GitHub Actions run URL when available; otherwise omit>
URL: <other relevant actual GitHub URL when available; otherwise omit>
${FENCE}

Use:
- Continue \u2014 more autonomous work remains. Chat FreePT will continue automatically.
- Needs input \u2014 a real decision, approval, permission, or external action only I can provide.
- Plan ready \u2014 planning is finished and recorded; Chat FreePT will move straight into development.
- Testing \u2014 implementation is ready for human validation or an external test only I can perform.
- Complete \u2014 the project is fully finished.
- Error \u2014 an unrecoverable problem that cannot be solved with the available tools.

Do not mention the machine-style status spelling in normal prose. Never omit the block and never put anything after it.
Report CI, CHECKS, ISSUE, PR and ACTIONS in every status block when the data is available.
Update fields on every response so Chat FreePT can display what is happening. Do not
invent URLs, check counts, or CI results. CI=Passed only after examining all required
GitHub Actions checks and confirming they ran successfully. If not checked, use Unknown.
Use Complete only after inspecting GitHub open issues/PRs and relevant required Actions results.
No checks, pending checks, or unverified results are not success.`;
  var CORE_MCP_REQUIREMENTS = `Required capabilities (tool names may differ): read repository
files and branches; create branches; create/update files on explicit branches including
.github/workflows/*; create/update Issues and comments; apply existing labels; create/update
and merge Pull Requests; and read Actions results plus failing job logs.`;
  function repositoryLockBlock(repo) {
    return `## Repository

Use **${repo}** for this project. Keep repository operations there and report the same
owner/name in each Chat FreePT status block. All continuations stay inside this
ChatGPT Project; Project files provide context but GitHub is the code source of truth.
Use ChatGPT and its tools as the only autonomous agent, never Claude or Claude Code.
If access genuinely needs my help, ask rather than substituting a repository.`;
  }
  function buildMcpPreflight(repo) {
    return `## GitHub preflight

Before repository changes, confirm the available GitHub tools can read and write **${repo}**.
Verify that the repository is public for the standard GitHub-hosted Actions free-minutes
workflow. Private repositories can run Actions but have included-minute quotas; if
private, explain this and request a visibility choice before bootstrapping CI.

${CORE_MCP_REQUIREMENTS}

Use dev and main explicitly for branch operations. Check labels first; create missing
labels only if a capable tool exists. If label creation is unavailable, keep moving by
recording the missing labels in the control Issue. Do not substitute Claude or ask users
to install Claude tools. Repository default-branch mutation is not required.

If a required permission or capability is genuinely unavailable, ask for human input and
state the exact missing capability. Do not substitute another repository or integration.
Zero CI checks is not green.`;
  }
  var CI_CONTRACT_BLOCK = `## Operating contract (CI-Pipline)

- One independently deliverable change = one GitHub Issue = one branch
  work/<issue-number>-<slug> from dev = one PR into dev.
- dev is integration; main is production. Do not commit directly to dev or main after
  initial seeding; PR merges move code into dev.
- Merge only after every GitHub Actions check has completed successfully. Zero checks is
  not green.
- On red: read the failing job log, fix the first causal error, push, and re-check. Never
  weaken a gate, skip a test, or lower a threshold. After 3 failed fix attempts on the
  same cause, ask for human input.
- PR bodies include "Refs #<issue>" and substantive Result, Implementation, Verification,
  Risk, and Remaining work sections.
- Label Issues with type:* and state:* labels; add matching risk:* labels for affected paths.
- Maintain "[CONTROL] Current repository state" after merges.
- Keep diffs small. Scope growth becomes a new Issue.
- Never commit secrets, .env files, or tokens.`;
  var COMPACT_CONTRACT = `Protocol reminder: one Issue = one work/<n>-slug branch = one PR into dev; merge only when
all Actions checks are green; fix red checks by cause; update the control Issue after merges;
keep working autonomously unless real human input is required; end every reply with the
Chat FreePT status block.`;
  var ULTRA_CODE_CONTRACT = `## Ultra Code operating contract

- Reconstruct current repository state before acting: inspect the control Issue, relevant
  Issues/PRs, branch heads, and current Actions runs. Treat chat memory as a hint, not truth.
- Make meaningful autonomous progress each turn. Use GitHub Issues, work branches, PRs,
  and Actions as durable state.
- Resume stale or interrupted work instead of duplicating Issues, branches, or PRs.
- Never idle waiting for CI. If checks are still running, use Continue so Chat FreePT can
  re-check on the next turn.
- Ask for human input only for a real decision, permission, validation step, or external
  action that cannot be resolved safely from repository state and available tools.
- Use Testing when the project is ready for human validation.
- Never weaken gates or treat zero, missing, pending, or red required checks as green.`;
  var ULTRA_CODE_COMPACT = `Ultra Code reminder: inspect durable repo state first; make meaningful progress; resume
existing work instead of duplicating it; never idle waiting on CI; ask only for genuine
human intervention; never weaken gates or treat zero/missing checks as green.`;
  var VENDOR_RECIPE_TEMPLATE = `## Vendoring the CI pipeline

The project repo gets its CI control plane from {{TEMPLATE_REPO}}:

1. Inspect the template repo. Vendor only runtime-neutral CI assets: ci/, scripts/, workflow/,
   .github/workflows/ (after reviewing each workflow), .pre-commit-config.yaml,
   .gitattributes and a merged .gitignore. Batch initial seeding in small commits.
2. This project is driven by ChatGPT and its GitHub MCP connector, NEVER by Claude.
   Do NOT vendor .claude/, .claude-workflow.json, .github/claude/ or Claude-specific
   hooks, prompts, agents, skills, settings, CLIs, or authentication requirements.
3. Translate any useful generic policy into docs/CHATFREEPT_CI.md and
   .chatfreept/project.json. Replace any Claude-dependent CI commands with
   real project-specific, headless build/test/security commands. Do not claim a
   workflow works until Actions actually runs successfully.
4. Keep working cross-platform ./scripts/bootstrap --ci and ./ci/run <stage>
   entry points when feasible; preserve required job names and validation gates.
5. Inspect main/dev state. Preserve main as production and dev as integration.
   Never switch the default branch or force-push to either.
6. Create any missing CI labels and the "[CONTROL] Current repository state" Issue.`;
  var PLAN_TEMPLATE = `# Chat FreePT protocol \u2014 planning

You are an autonomous release engineer working through GitHub tools. Perform repository
work yourself rather than asking me to run GitHub commands. Chat FreePT keeps this project
moving between replies, so finish every turn with the status block below.

{{REPO_LOCK}}

{{MCP_PREFLIGHT}}

{{ULTRA_CODE}}

## Repository setup

Verify the selected repository's current contents before vendoring the CI plane. If existing
content creates a genuine decision that cannot be resolved safely, ask for human input.

{{VENDOR_RECIPE}}

## Project

Build a master plan for:

"""
{{IDEA}}
"""

## Master plan

Create a numbered plan of independently deliverable, CI-verifiable slices (usually 4\u201310).
Item 1 is project scaffold/toolchain with passing fast and PR gates. The final work covers
testing and release as appropriate.

For each item include title, acceptance criteria, areas touched, required gates, and risk
labels. Record the plan in docs/MASTER_PLAN.md, create one GitHub Issue per item, and update
the control Issue.

Work continuously. If planning needs multiple replies, use Continue. Ask me only when a
genuine unresolved choice or external action blocks progress. Once the recorded plan and
Issues are ready, use Plan ready; Chat FreePT will automatically start development without
waiting for another approval click.

{{CI_CONTRACT}}

{{MARKER}}`;
  var DEVELOP_TEMPLATE = `# Chat FreePT protocol \u2014 development

{{REPO_LOCK}}

{{ULTRA_CODE}}

The master plan is ready. Execute it one item at a time.

## Per-item loop

For each plan Issue:
1. Confirm the Issue/labels and inspect for an existing branch or PR before creating anything.
2. Create work/<issue-number>-<slug> from dev when needed.
3. Implement complete code with no placeholder work.
4. Open a PR into dev with "Refs #<issue>" and Result / Implementation / Verification /
   Risk / Remaining work sections plus required risk labels.
5. Re-check Actions instead of idling. On red, read the first causal failure, fix it, push,
   and re-check.
6. When every check is green, merge, confirm the merge, close the Issue, and update control state.
7. Continue directly to the next item.

Chat FreePT follow-up messages are clock ticks. Use Continue whenever more work remains,
including while CI is running. Do not wait for me unless genuine human intervention is needed.

## Testing and completion

Use Testing only when implementation is ready and the next required step is human validation
or another external test I must perform. After I respond, continue development/release work.
Use Complete only when all requested work is finished. Before Complete, self-audit open Issues,
open PRs, relevant Actions, and repository state.

{{CI_CONTRACT}}

{{MARKER}}`;
  var HANDOFF_TEMPLATE = `# Chat FreePT protocol \u2014 automatic continuation

The previous ChatGPT conversation reached its maximum length, so Chat FreePT opened this
conversation to continue the same project.

Repo: {{REPO}}
Phase: {{PHASE}}

{{ULTRA_CODE}}

Reconstruct current state from GitHub: read docs/MASTER_PLAN.md, the control Issue, open
Issues and PRs, branch heads, and latest Actions runs. Resume the existing work without
creating duplicates. Continue autonomously unless genuine human intervention is required.

{{CI_CONTRACT}}

{{MARKER}}`;
  function buildNudgePrompt(repo) {
    return `Repo: ${repo}. Your last reply did not include a readable CHATFREEPT status block.
Inspect the durable state in GitHub and your previous response. Do not mutate the repository
only to answer this status request. Return the correct current status, task and actual
issue/PR/Actions URL in a final chatfreept status block. If work remains, say Continue.
If you previously claimed completion, first confirm there is no remaining work and that
required checks ran and passed. Never infer green from missing or pending checks.
${MARKER_BLOCK}`;
  }
  function buildExistingConversationPrompt(repo) {
    return `Repo: **${repo}**. Resume this EXISTING conversation; do not restart the plan or repeat completed work.
Use the recent conversation and GitHub issues, PRs and Actions to confirm the current checkpoint. Continue useful work, or report Needs input only for a real human blocker. Do not equate missing checks with green. Give a brief update and this final status block (omit unknown links, never invent CI):
CHATFREEPT_STATUS: <Continue | Needs input | Testing | Complete>
V: 1
PHASE: <Planning | Developing | Testing | Complete>
REPO: ${repo}
ITEM: <current item>
NOTE: <one-line progress>
CI: <Not run | Queued | Running | Passed | Failed | Unknown>
PR: <actual URL if known>
ACTIONS: <actual URL if known>
If finished, report Complete only after GitHub verification; FreePT runs a final audit before stopping.`;
  }
  function buildFinalAuditPrompt(repo) {
    return `Repo: **${repo}**. FINAL COMPLETION AUDIT (required before Chat FreePT stops).
Perform one independent, comprehensive last pass against the durable GitHub state:
review the plan, open and unresolved Issues, PRs, latest branch heads, merge state,
actual GitHub Actions runs/checks and logs, release status, documentation, and test results.
Run or repair any remaining checks using the authorized GitHub tools. Zero/missing/pending
checks are NOT green. Do not change the repo lock or weaken gates. If anything remains,
report Continue and work through it autonomously. Report Needs input only for real human
intervention. Report Complete ONLY if everything requested is finished, verified, and
recorded in the control Issue. Do not start unrelated follow-up work.
${MARKER_BLOCK}`;
  }
  function buildPlanPrompt(input) {
    return renderTemplate(PLAN_TEMPLATE, {
      REPO_LOCK: repositoryLockBlock(input.repo),
      MCP_PREFLIGHT: buildMcpPreflight(input.repo),
      ULTRA_CODE: ULTRA_CODE_CONTRACT,
      REPO: input.repo,
      VENDOR_RECIPE: renderTemplate(VENDOR_RECIPE_TEMPLATE, { TEMPLATE_REPO: input.templateRepo }),
      IDEA: input.idea.trim(),
      CI_CONTRACT: CI_CONTRACT_BLOCK,
      MARKER: MARKER_BLOCK
    });
  }
  function buildDevelopPrompt(settings, repo) {
    void settings;
    return renderTemplate(DEVELOP_TEMPLATE, {
      REPO_LOCK: repositoryLockBlock(repo),
      ULTRA_CODE: ULTRA_CODE_CONTRACT,
      CI_CONTRACT: CI_CONTRACT_BLOCK,
      MARKER: MARKER_BLOCK
    });
  }
  function buildContinuePrompt(settings, withContractRefresh, repo) {
    const body = withContractRefresh ? `${settings.continueMessage}

${COMPACT_CONTRACT}

${ULTRA_CODE_CONTRACT}` : `${settings.continueMessage}

${ULTRA_CODE_COMPACT}`;
    return `Repo: **${repo}**. Continue the current project from durable GitHub state.

${body}

Report the latest CHATFREEPT_STATUS, V, PHASE, REPO, ITEM and NOTE; also CI, CHECKS,
ISSUE, PR, ACTIONS and BRANCH when known. Update the existing work status, do not
start over. Omit unknown links and do not treat pending/missing checks as passed.`;
  }
  function buildUserReply(text, repo) {
    return `Repo: **${repo}**.

${ULTRA_CODE_COMPACT}

${text.trim()}

End with the Chat FreePT status block.`;
  }
  function buildHandoffPrompt(state) {
    const repo = state.repo ?? "(repository missing)";
    const phase = state.phase === "developing" || state.phase === "testing" ? "Developing" : "Planning";
    return renderTemplate(HANDOFF_TEMPLATE, {
      REPO: repo,
      PHASE: phase,
      ULTRA_CODE: ULTRA_CODE_CONTRACT,
      CI_CONTRACT: CI_CONTRACT_BLOCK,
      MARKER: MARKER_BLOCK
    });
  }

  // src/common/repository.ts
  var OWNER_RE = /^[A-Za-z0-9](?:[A-Za-z0-9-]{0,37}[A-Za-z0-9])?$/;
  var REPO_RE = /^[A-Za-z0-9._-]+$/;
  function normalizeRepositoryInput(input) {
    const value = input.trim();
    if (!value) return null;
    if (/^https?:\/\//i.test(value)) {
      try {
        const url = new URL(value);
        if (!/^(?:www\.)?github\.com$/i.test(url.hostname)) return null;
        const parts2 = url.pathname.split("/").filter(Boolean);
        if (parts2.length !== 2) return null;
        return normalizeParts(parts2[0] ?? "", parts2[1] ?? "");
      } catch {
        return null;
      }
    }
    const parts = value.split("/");
    if (parts.length !== 2) return null;
    return normalizeParts(parts[0] ?? "", parts[1] ?? "");
  }
  function normalizeParts(ownerRaw, repoRaw) {
    const owner = ownerRaw.trim();
    const repo = repoRaw.trim().replace(/\.git$/i, "");
    if (!OWNER_RE.test(owner) || !REPO_RE.test(repo)) return null;
    return `${owner}/${repo}`;
  }

  // src/common/state-machine.ts
  var MAX_LOG = 200;
  var ACTIVE_STATUSES = /* @__PURE__ */ new Set(["inserting", "sending", "streaming", "cooldown"]);
  var USER_EVENTS = /* @__PURE__ */ new Set([
    "USER_START",
    "USER_ATTACH_EXISTING",
    "USER_UPDATE_DRAFT",
    "USER_START_DEVELOPMENT",
    "USER_PAUSE",
    "USER_RESUME",
    "USER_STOP",
    "USER_NEW_PROJECT",
    "USER_REPLY",
    "USER_SET_AUTO_CONTINUE",
    "USER_QUEUE_NEXT",
    "USER_REMOVE_QUEUE",
    "USER_MOVE_QUEUE",
    "USER_CLEAR_QUEUE"
  ]);
  var SEND_EVENTS = /* @__PURE__ */ new Set([
    "INSERT_OK",
    "INSERT_FAIL",
    "SEND_OK",
    "SEND_FAIL",
    "REPLY_EXPECTED"
  ]);
  var STREAM_EVENTS = /* @__PURE__ */ new Set([
    "STREAM_STARTED",
    "REPLY_COMPLETE",
    "STREAM_STUCK",
    "STREAM_INTERRUPTED",
    "PERMISSION_CONTINUED"
  ]);
  function newRunState(conversationId, now) {
    return {
      v: 1,
      conversationId,
      projectId: projectIdFromUrl(location.href),
      phase: "idle",
      status: "idle",
      idea: "",
      repoMode: "new",
      repoName: "",
      autoContinueEnabled: true,
      autoSends: 0,
      nudges: 0,
      repliesSinceContract: 0,
      startedAt: now,
      updatedAt: now,
      log: []
    };
  }
  function prepareConversationHandoff(state, conversationId, now) {
    const next = {
      ...state,
      conversationId,
      phase: state.phase === "plan_ready" || state.phase === "testing" ? "developing" : state.phase,
      status: "paused",
      autoContinueEnabled: true,
      autoSends: 0,
      nudges: 0,
      repliesSinceContract: 0,
      handoffPending: true,
      lastLifecycleSignal: "conversation-handoff",
      updatedAt: now,
      log: [
        ...state.log,
        { at: now, kind: "info", text: "Conversation full \u2014 continuing in a new chat" }
      ].slice(-MAX_LOG)
    };
    delete next.handoffStarted;
    delete next.cooldownUntil;
    delete next.replyBaselineAssistantKey;
    delete next.lastProcessedAssistantKey;
    delete next.pauseReason;
    delete next.errorCode;
    return next;
  }
  function isActive(state) {
    return ACTIVE_STATUSES.has(state.status);
  }
  function queuedMessages(state) {
    if (state.queuedUserTexts?.length) return state.queuedUserTexts.filter((text) => text.trim());
    const legacy = state.queuedUserText?.trim();
    return legacy ? [legacy] : [];
  }
  function setQueuedMessages(state, messages) {
    const clean = messages.map((text) => text.trim()).filter(Boolean);
    delete state.queuedUserText;
    if (clean.length > 0) state.queuedUserTexts = clean;
    else delete state.queuedUserTexts;
  }
  function cooldownRemainingMs(state, now = Date.now()) {
    if (state.status !== "cooldown") return 0;
    return Math.max(0, (state.cooldownUntil ?? now) - now);
  }
  function reduce(prev, event, settings) {
    const now = Date.now();
    const ctx = {
      state: { ...prev, updatedAt: now, log: [...prev.log] },
      effects: [],
      settings,
      now
    };
    let accepted;
    if (isUserEvent(event)) accepted = reduceUserEvent(ctx, event);
    else if (isSendEvent(event)) accepted = reduceSendEvent(ctx, event);
    else if (isStreamEvent(event)) accepted = reduceStreamEvent(ctx, event);
    else accepted = reduceSystemEvent(ctx, event);
    if (!accepted) return { state: prev, effects: [] };
    if (ctx.state.status !== "cooldown") delete ctx.state.cooldownUntil;
    return { state: ctx.state, effects: ctx.effects };
  }
  function isUserEvent(event) {
    return USER_EVENTS.has(event.type);
  }
  function isSendEvent(event) {
    return SEND_EVENTS.has(event.type);
  }
  function isStreamEvent(event) {
    return STREAM_EVENTS.has(event.type);
  }
  function note(ctx, kind, text) {
    ctx.state.log.push({ at: ctx.now, kind, text });
    if (ctx.state.log.length > MAX_LOG) {
      ctx.state.log.splice(0, ctx.state.log.length - MAX_LOG);
    }
  }
  function fail(ctx, code, message) {
    ctx.state.status = "error";
    ctx.state.errorCode = code;
    ctx.state.pauseReason = message;
    note(ctx, "error", message);
    ctx.effects.push({ do: "badge", text: "!" });
    ctx.effects.push({ do: "notify", title: "Chat FreePT paused", message });
  }
  function reduceUserEvent(ctx, event) {
    switch (event.type) {
      case "USER_START":
        return startRun(ctx, event);
      case "USER_ATTACH_EXISTING":
        return attachExistingRun(ctx, event);
      case "USER_UPDATE_DRAFT":
        return updateDraft(ctx, event.idea, event.repoName);
      case "USER_START_DEVELOPMENT":
        return startDevelopment(ctx);
      case "USER_PAUSE":
        return pauseRun(ctx);
      case "USER_RESUME":
        return resumeRun(ctx, event.lastUserText);
      case "USER_STOP":
        return stopRun(ctx);
      case "USER_NEW_PROJECT":
        return newProject(ctx);
      case "USER_REPLY":
        return sendUserReply(ctx, event);
      case "USER_SET_AUTO_CONTINUE":
        return setAutoContinue(ctx, event.enabled);
      case "USER_QUEUE_NEXT":
        return queueNextMessage(ctx, event);
      case "USER_REMOVE_QUEUE":
        return removeQueuedMessage(ctx, event);
      case "USER_MOVE_QUEUE":
        return moveQueuedMessage(ctx, event);
      case "USER_CLEAR_QUEUE":
        return clearQueuedMessages(ctx);
    }
  }
  function updateDraft(ctx, idea, repoName) {
    if (ctx.state.status !== "idle") return false;
    const nextRepoName = ctx.state.repo ?? repoName;
    const nextRepoMode = ctx.state.repo || normalizeRepositoryInput(repoName) ? "existing" : "new";
    if (ctx.state.idea === idea && ctx.state.repoName === nextRepoName && ctx.state.repoMode === nextRepoMode) {
      return false;
    }
    ctx.state.idea = idea;
    ctx.state.repoName = nextRepoName;
    ctx.state.repoMode = nextRepoMode;
    return true;
  }
  function startRun(ctx, event) {
    const state = ctx.state;
    if (state.status !== "idle" && state.phase !== "stopped" && state.phase !== "complete") {
      return false;
    }
    const requestedRepo = normalizeRepositoryInput(event.repoName);
    if (!state.repo && !requestedRepo) {
      fail(ctx, "repo-required", "Choose and lock a GitHub repository before planning.");
      return true;
    }
    if (state.repo && requestedRepo && requestedRepo.toLowerCase() !== state.repo.toLowerCase()) {
      fail(
        ctx,
        "repo-mismatch",
        `This conversation is locked to ${state.repo}. Start a new ChatGPT conversation to use ${requestedRepo}.`
      );
      return true;
    }
    const lockedRepo = state.repo ?? requestedRepo;
    if (!lockedRepo) return false;
    state.repo = lockedRepo;
    state.repoMode = "existing";
    state.repoName = lockedRepo;
    state.phase = "planning";
    state.status = "inserting";
    state.idea = event.idea;
    state.lastUserText = event.idea.trim();
    state.autoSends = 0;
    state.nudges = 0;
    state.repliesSinceContract = 0;
    state.startedAt = ctx.now;
    delete state.finalAuditPending;
    delete state.finalAuditVerified;
    delete state.currentItem;
    delete state.workSummary;
    delete state.lastWorkUrl;
    delete state.workKind;
    delete state.queuedUserText;
    delete state.queuedUserTexts;
    delete state.lastLifecycleSignal;
    delete state.errorCode;
    delete state.pauseReason;
    note(ctx, "info", "Planning started");
    ctx.effects.push({ do: "insertAndSend", kind: "plan" }, { do: "badge", text: "RUN" });
    return true;
  }
  function attachExistingRun(ctx, event) {
    const state = ctx.state;
    if (state.status !== "idle" || !event.snapshot?.hasHistory) return false;
    const requestedRepo = normalizeRepositoryInput(event.repoName);
    if (!requestedRepo) {
      fail(ctx, "repo-required", "Enter a valid GitHub repository before continuing this conversation.");
      return true;
    }
    if (state.repo && state.repo.toLowerCase() !== requestedRepo.toLowerCase()) {
      fail(ctx, "repo-mismatch", `This conversation is locked to ${state.repo}.`);
      return true;
    }
    const snapshot = event.snapshot;
    const reportedRepo = snapshot.marker?.repo ? normalizeRepositoryInput(snapshot.marker.repo) : null;
    if (reportedRepo && reportedRepo.toLowerCase() !== requestedRepo.toLowerCase()) {
      fail(ctx, "repo-mismatch", `The latest ChatGPT reply names ${reportedRepo}, not ${requestedRepo}. Verify the repository before attaching.`);
      return true;
    }
    state.repo = requestedRepo;
    state.repoName = requestedRepo;
    state.repoMode = "existing";
    const previousPhase = snapshot.marker?.phase?.toLowerCase() ?? "";
    state.phase = previousPhase.includes("plan") ? "planning" : "developing";
    state.status = "streaming";
    state.autoSends = 0;
    state.nudges = 0;
    state.repliesSinceContract = 0;
    state.lastUserText = snapshot.userText?.slice(0, 400) ?? state.lastUserText;
    state.startedAt = ctx.now;
    state.lastLifecycleSignal = "native-conversation-attached";
    if (snapshot.role !== "assistant") state.attachPendingSince = ctx.now;
    else delete state.attachPendingSince;
    delete state.replyBaselineAssistantKey;
    delete state.lastProcessedAssistantKey;
    delete state.errorCode;
    delete state.pauseReason;
    delete state.finalAuditPending;
    delete state.finalAuditVerified;
    note(ctx, "info", snapshot.busy ? "Attached; waiting for ChatGPT's current reply" :
      snapshot.role === "user" ? "Attached; waiting for native reply or safe recovery" :
      "Attached; reading the existing assistant reply");
    ctx.effects.push({ do: "reconcile" }, { do: "badge", text: "RUN" });
    return true;
  }
  function startDevelopment(ctx) {
    const state = ctx.state;
    if (state.phase !== "plan_ready") return false;
    if (!state.repo) {
      fail(ctx, "repo-required", "This conversation has no locked GitHub repository.");
      return true;
    }
    state.phase = "developing";
    state.status = "inserting";
    state.autoSends = 0;
    state.nudges = 0;
    note(ctx, "info", "Development started");
    ctx.effects.push({ do: "insertAndSend", kind: "develop" }, { do: "badge", text: "RUN" });
    return true;
  }
  function pauseRun(ctx) {
    if (ctx.state.status === "paused") return false;
    ctx.state.status = "paused";
    ctx.state.pauseReason = "Paused by you";
    note(ctx, "info", "Paused");
    ctx.effects.push({ do: "badge", text: "II" });
    return true;
  }
  function resumeRun(ctx, lastUserText) {
    const state = ctx.state;
    if (state.status !== "paused" && state.status !== "error" && state.status !== "awaiting_user") {
      return false;
    }
    const text = lastUserText?.trim();
    if (text) state.lastUserText = text;
    if (state.phase === "testing") state.phase = "developing";
    const wasMissingMarker = state.errorCode === "marker-missing";
    delete state.pauseReason;
    delete state.errorCode;
    if (wasMissingMarker && isContinuablePhase(state)) {
      state.nudges = 0;
      state.status = "inserting";
      note(ctx, "info", "Resumed — requesting a verified status before continuing");
      ctx.effects.push({ do: "insertAndSend", kind: "nudge" });
      return true;
    }
    if (state.lastLifecycleSignal === "generation-interrupted" && isContinuablePhase(state)) {
      state.lastLifecycleSignal = "interruption-resumed";
      note(ctx, "info", "Resumed \u2014 continuing after interruption");
      handleContinue(ctx);
      return true;
    }
    state.status = "streaming";
    note(ctx, "info", "Resumed \u2014 re-checking conversation state");
    ctx.effects.push({ do: "reconcile" }, { do: "badge", text: "RUN" });
    return true;
  }
  function resetRun(ctx, logText) {
    const lockedRepo = ctx.state.repo;
    const reset = newRunState(ctx.state.conversationId, ctx.now);
    reset.autoContinueEnabled = true;
    if (lockedRepo) {
      reset.repo = lockedRepo;
      reset.repoMode = "existing";
      reset.repoName = lockedRepo;
    }
    reset.log = [{ at: ctx.now, kind: "info", text: logText }];
    ctx.state = reset;
  }
  function stopRun(ctx) {
    resetRun(ctx, "Stopped and reset");
    ctx.effects.push({ do: "badge", text: "" });
    return true;
  }
  function newProject(ctx) {
    resetRun(ctx, "Ready for a new project");
    ctx.effects.push({ do: "badge", text: "" });
    return true;
  }
  function sendUserReply(ctx, event) {
    const state = ctx.state;
    if (state.status !== "awaiting_user" && state.status !== "paused" && state.status !== "error") {
      return false;
    }
    if (state.phase === "testing") state.phase = "developing";
    state.status = "inserting";
    state.nudges = 0;
    state.lastUserText = event.text.trim();
    delete state.pauseReason;
    delete state.errorCode;
    note(ctx, "send", "Sending your reply");
    ctx.effects.push(
      { do: "insertAndSend", kind: "user_text", text: event.text },
      { do: "badge", text: "RUN" }
    );
    return true;
  }
  function setAutoContinue(ctx, _enabled) {
    if (ctx.state.autoContinueEnabled === true) return false;
    ctx.state.autoContinueEnabled = true;
    note(ctx, "info", "Continuous mode enabled");
    if (ctx.state.status === "awaiting_user" && ctx.state.lastMarker?.status === "CONTINUE" && isContinuablePhase(ctx.state)) {
      delete ctx.state.pauseReason;
      handleContinue(ctx);
    }
    return true;
  }
  function queueNextMessage(ctx, event) {
    const text = event.text.trim();
    if (!text || !isContinuablePhase(ctx.state)) return false;
    setQueuedMessages(ctx.state, [...queuedMessages(ctx.state), text]);
    note(ctx, "info", "Queued user message");
    if (ctx.state.status === "awaiting_user" && ctx.state.lastMarker?.status === "CONTINUE") {
      delete ctx.state.pauseReason;
      scheduleContinuation(ctx);
    }
    return true;
  }
  function removeQueuedMessage(ctx, event) {
    const queue = queuedMessages(ctx.state);
    if (!Number.isInteger(event.index) || event.index < 0 || event.index >= queue.length) {
      return false;
    }
    queue.splice(event.index, 1);
    setQueuedMessages(ctx.state, queue);
    note(ctx, "info", "Removed queued user message");
    return true;
  }
  function moveQueuedMessage(ctx, event) {
    const queue = queuedMessages(ctx.state);
    const target = event.index + event.direction;
    if (!Number.isInteger(event.index) || event.index < 0 || event.index >= queue.length || target < 0 || target >= queue.length) {
      return false;
    }
    const [message] = queue.splice(event.index, 1);
    if (!message) return false;
    queue.splice(target, 0, message);
    setQueuedMessages(ctx.state, queue);
    note(ctx, "info", "Reordered queued user messages");
    return true;
  }
  function clearQueuedMessages(ctx) {
    if (queuedMessages(ctx.state).length === 0) return false;
    setQueuedMessages(ctx.state, []);
    note(ctx, "info", "Cleared queued user messages");
    return true;
  }
  function reduceSendEvent(ctx, event) {
    switch (event.type) {
      case "INSERT_OK":
        if (ctx.state.status !== "inserting") return false;
        ctx.state.status = "sending";
        return true;
      case "INSERT_FAIL":
        fail(ctx, "composer-insert-failed", `Could not write into the composer: ${event.detail}`);
        return true;
      case "SEND_OK":
        if (ctx.state.status !== "sending") return false;
        ctx.state.status = "streaming";
        return true;
      case "SEND_FAIL":
        fail(ctx, "send-failed", `Could not send the message: ${event.detail}`);
        return true;
      case "REPLY_EXPECTED":
        if (ctx.state.status !== "sending") return false;
        if (event.baselineAssistantKey) {
          ctx.state.replyBaselineAssistantKey = event.baselineAssistantKey;
        } else {
          delete ctx.state.replyBaselineAssistantKey;
        }
        return true;
    }
  }
  function reduceStreamEvent(ctx, event) {
    switch (event.type) {
      case "STREAM_STARTED":
        return startStream(ctx);
      case "REPLY_COMPLETE":
        return completeReply(ctx, event);
      case "STREAM_INTERRUPTED":
        return interruptStream(ctx, event.reason);
      case "PERMISSION_CONTINUED":
        return continuePermission(ctx);
      case "STREAM_STUCK":
        ctx.state.lastLifecycleSignal = "stream-stuck";
        fail(
          ctx,
          "stream-stuck",
          `ChatGPT has been generating for over ${ctx.settings.maxStreamMinutes} minutes \u2014 check the tab.`
        );
        return true;
    }
  }
  function startStream(ctx) {
    if (ctx.state.status === "idle") return false;
    if (ctx.state.status === "streaming" && ctx.state.lastLifecycleSignal === "generation-start") return false;
    if (ctx.state.status === "paused" && ctx.state.lastLifecycleSignal !== "generation-interrupted") {
      return false;
    }
    if (ctx.state.phase === "testing") ctx.state.phase = "developing";
    ctx.state.status = "streaming";
    ctx.state.lastLifecycleSignal = "generation-start";
    delete ctx.state.pauseReason;
    delete ctx.state.errorCode;
    return true;
  }
  function completeReply(ctx, event) {
    if (!canConsumeReply(ctx.state, event.marker)) return false;
    if (isDuplicateReply(ctx.state, event.assistantKey)) return false;
    if (event.assistantKey) ctx.state.lastProcessedAssistantKey = event.assistantKey;
    delete ctx.state.replyBaselineAssistantKey;
    delete ctx.state.attachPendingSince;
    ctx.state.lastLifecycleSignal = "generation-complete";
    ctx.state.repliesSinceContract += 1;
    handleReply(ctx, event.marker, event.text);
    return true;
  }
  function canConsumeReply(state, marker) {
    return state.status === "streaming" || state.status === "sending" || state.status === "awaiting_user" && marker !== null && (isContinuablePhase(state) || state.phase === "testing");
  }
  function isDuplicateReply(state, assistantKey) {
    return Boolean(
      assistantKey && (assistantKey === state.lastProcessedAssistantKey || assistantKey === state.replyBaselineAssistantKey)
    );
  }
  function continuePermission(ctx) {
    const state = ctx.state;
    if (state.phase !== "planning" && state.phase !== "developing" && state.phase !== "plan_ready") {
      return false;
    }
    if (state.status !== "sending" && state.status !== "streaming" && !(state.status === "paused" && state.lastLifecycleSignal === "generation-interrupted")) {
      return false;
    }
    state.status = "streaming";
    state.lastLifecycleSignal = "permission-continued";
    delete state.pauseReason;
    delete state.errorCode;
    note(ctx, "info", "GitHub permission continued automatically");
    ctx.effects.push({ do: "reconcile" }, { do: "badge", text: "RUN" });
    return true;
  }
  function interruptStream(ctx, reason) {
    if (ctx.state.status === "idle" || ctx.state.status === "paused" || ctx.state.status === "complete") {
      return false;
    }
    ctx.state.status = "paused";
    const manual = reason === "Stopped manually in ChatGPT";
    ctx.state.lastLifecycleSignal = manual ? "manual-stop" : "generation-interrupted";
    ctx.state.pauseReason = reason ?? "Generation stopped in ChatGPT";
    note(ctx, "info", manual ? "Stopped manually \u2014 automation paused" : "Generation interrupted \u2014 automation paused");
    ctx.effects.push({ do: "badge", text: "II" });
    return true;
  }
  function reduceSystemEvent(ctx, event) {
    switch (event.type) {
      case "COOLDOWN_ELAPSED":
        return finishCooldown(ctx);
      case "RECOVERY_CONTINUE":
        return recoverInterruptedRun(ctx);
      case "NATIVE_REPLY_TIMEOUT":
        return recoverNativeConversation(ctx);
      case "TRANSPORT_RECOVERY":
        return recoverTransportConversation(ctx);
      case "HANDOFF_READY":
        return startConversationHandoff(ctx);
      case "PAGE_SIGNAL":
        return handleSystemPageSignal(ctx, event.signal);
    }
  }
  function handleSystemPageSignal(ctx, signal) {
    const interruptedFullChat = signal === "conversation-full" && ctx.state.status === "paused" && ctx.state.lastLifecycleSignal === "generation-interrupted" && isContinuablePhase(ctx.state);
    if (!isActive(ctx.state) && ctx.state.status !== "awaiting_user" && !interruptedFullChat) {
      return false;
    }
    if (signal === "conversation-full" && ctx.state.handoffStarted) return false;
    ctx.state.lastLifecycleSignal = `page:${signal}`;
    handlePageSignal(ctx, signal);
    return true;
  }
  function startConversationHandoff(ctx) {
    const state = ctx.state;
    if (!state.handoffPending || !state.repo || !isContinuablePhase(state)) return false;
    state.handoffPending = false;
    state.status = "inserting";
    state.autoContinueEnabled = true;
    state.lastLifecycleSignal = "conversation-handoff-started";
    delete state.pauseReason;
    delete state.errorCode;
    note(ctx, "send", "Continuing project in the new conversation");
    ctx.effects.push({ do: "insertAndSend", kind: "handoff" }, { do: "badge", text: "RUN" });
    return true;
  }
  function recoverInterruptedRun(ctx) {
    const state = ctx.state;
    if (state.status !== "streaming" || state.lastLifecycleSignal !== "generation-interrupted" || !isContinuablePhase(state)) {
      return false;
    }
    state.lastLifecycleSignal = "interruption-recovered";
    note(ctx, "info", "Recovered interrupted run after reload");
    handleContinue(ctx);
    return true;
  }
  function recoverTransportConversation(ctx) {
    const state = ctx.state;
    if (state.status !== "streaming" || !state.repo || !isContinuablePhase(state)) return false;
    state.status = "inserting";
    state.lastLifecycleSignal = "transport-recovery-sent";
    note(ctx, "warn", "No reply after the connection closed; requesting one concise state check");
    ctx.effects.push({ do: "insertAndSend", kind: "context_sync" });
    return true;
  }
  function recoverNativeConversation(ctx) {
    const state = ctx.state;
    if (state.status !== "streaming" || !state.attachPendingSince || !state.repo || !isContinuablePhase(state)) return false;
    delete state.attachPendingSince;
    state.status = "inserting";
    note(ctx, "warn", "No native reply appeared; requesting a repository-grounded state check");
    ctx.effects.push({ do: "insertAndSend", kind: "context_sync" });
    return true;
  }
  function finishCooldown(ctx) {
    const state = ctx.state;
    if (state.status !== "cooldown") return false;
    const queue = queuedMessages(state);
    const nextQueued = queue.shift();
    if (nextQueued) {
      setQueuedMessages(state, queue);
      state.status = "inserting";
      state.lastUserText = nextQueued;
      note(ctx, "send", "Sending queued user message");
      ctx.effects.push({ do: "insertAndSend", kind: "queued_user_text", text: nextQueued });
      return true;
    }
    state.status = "inserting";
    state.autoSends += 1;
    const refresh = state.repliesSinceContract >= ctx.settings.contractRefreshEvery;
    if (refresh) state.repliesSinceContract = 0;
    note(ctx, "send", refresh ? "Auto-continue (with contract refresh)" : "Auto-continue");
    ctx.effects.push({ do: "insertAndSend", kind: refresh ? "contract_refresh" : "continue" });
    return true;
  }
  function handlePageSignal(ctx, signal) {
    switch (signal) {
      case "rate-limit":
        fail(ctx, "rate-limited", "ChatGPT reported a usage limit. Resume when it lifts.");
        return;
      case "logged-out":
        fail(ctx, "logged-out", "You appear to be logged out of ChatGPT.");
        return;
      case "network-error":
        fail(ctx, "network-error", "ChatGPT hit an error mid-reply. Use Regenerate, then Resume.");
        return;
      case "conversation-full":
        if (!ctx.state.repo || !isContinuablePhase(ctx.state)) {
          fail(ctx, "conversation-full", "This conversation reached its maximum length.");
          return;
        }
        ctx.state.status = "paused";
        ctx.state.handoffStarted = true;
        ctx.state.pauseReason = "Conversation full \u2014 continuing automatically in a new chat.";
        note(ctx, "info", "Conversation full \u2014 starting automatic handoff");
        ctx.effects.push({ do: "handoffConversation" }, { do: "badge", text: "RUN" });
        return;
    }
  }
  const MAX_MARKER_RECOVERIES = 3;
  function rememberReportedWork(state, marker, text) {
    const nextWork = Boolean(marker && ((marker.item && state.currentItem && marker.item !== state.currentItem) ||
      (marker.branch && state.currentBranch && marker.branch !== state.currentBranch)));
    if (nextWork) {
      // A new Issue/branch must never inherit the previous PR or green CI state.
      for (const key of ["prUrl", "issueUrl", "actionsUrl", "lastWorkUrl", "workKind", "workSummary"]) delete state[key];
    }
    if (marker?.item) state.currentItem = marker.item.slice(0, 160);
    if (marker?.note) state.workSummary = marker.note.slice(0, 200);
    if (marker?.branch) state.currentBranch = marker.branch;
    if (marker) {
      state.statusUpdatedAt = Date.now();
      if (marker.ci) state.ciStatus = marker.ci;
      else delete state.ciStatus;
      if (marker.checks) state.ciChecks = marker.checks;
      else delete state.ciChecks;
    }
    const repo = state.repo;
    if (!repo) return;
    const safeRepo = repo.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const linkPattern = new RegExp(String.raw`https:\/\/github\.com\/${safeRepo}\/(?:pull|issues|actions\/runs)\/\d+`, "gi");
    const candidates = [...(text ?? "").matchAll(linkPattern)];
    const validLink = (url, kind) => typeof url === "string" &&
      new RegExp(String.raw`^https://github\.com/${safeRepo}/${kind}/\d+(?:[/?#]|$)`, "i").test(url);
    if (validLink(marker?.issue, "issues")) state.issueUrl = marker.issue;
    if (validLink(marker?.pr, "pull")) {
      if (state.prUrl && state.prUrl !== marker.pr && !marker.ci) {
        state.ciStatus = "UNKNOWN";
        delete state.ciChecks;
      }
      state.prUrl = marker.pr;
    }
    if (validLink(marker?.actions, "actions/runs")) state.actionsUrl = marker.actions;
    const lastUrl = marker?.url && linkPattern.test(marker.url) ? marker.url : candidates.at(-1)?.[0];
    if (lastUrl) {
      state.lastWorkUrl = lastUrl.replace(/[)\],.;]+$/, "");
      state.workKind = /\/pull\//i.test(lastUrl) ? "PR" : /\/actions\/runs\//i.test(lastUrl) ? "Actions" : "Issue";
    }
    if (!state.workSummary) {
      const line = (text ?? "").split("\n").map((part) => part.trim().replace(/^[#*>\s-]+/, "")).find((part) => /^(?:Working on|Implementing|Fixing|Testing|Checking|Reviewing|Investigating|Auditing)\b/i.test(part));
      if (line) state.workSummary = line.slice(0, 150);
      else if (state.currentItem) state.workSummary = `Working on ${state.currentItem}`;
    }
  }
  function handleReply(ctx, marker, text) {
    const state = ctx.state;
    if (!marker) rememberReportedWork(state, null, text);
    if (!marker) {
      if (state.phase !== "planning" && state.phase !== "developing") {
        state.status = "awaiting_user";
        return;
      }
      if (state.nudges < MAX_MARKER_RECOVERIES) {
        state.nudges += 1;
        state.status = "inserting";
        note(ctx, "warn", `Missing status marker; verifying state (${state.nudges}/${MAX_MARKER_RECOVERIES})`);
        ctx.effects.push({ do: "insertAndSend", kind: "nudge" });
      } else {
        fail(ctx, "marker-missing", "Could not verify project status after three recovery attempts. Review the ChatGPT reply before resuming.");
      }
      return;
    }
    state.nudges = 0;
    if (!validateMarkerRepository(ctx, marker)) return;
    state.lastMarker = marker;
    rememberReportedWork(state, marker, text);
    note(ctx, "marker", marker.raw);
    handleMarker(ctx, marker, text);
  }
  function validateMarkerRepository(ctx, marker) {
    if (!ctx.state.repo) {
      fail(ctx, "repo-required", "This conversation has no locked GitHub repository.");
      return false;
    }
    if (!marker.repo) return true;
    const reported = normalizeRepositoryInput(marker.repo);
    if (!reported || reported.toLowerCase() !== ctx.state.repo.toLowerCase()) {
      fail(
        ctx,
        "repo-mismatch",
        `ChatGPT reported repository ${marker.repo}, but this conversation is locked to ${ctx.state.repo}. Start a new ChatGPT conversation to switch repositories.`
      );
      return false;
    }
    return true;
  }
  function handleMarker(ctx, marker, text) {
    switch (marker.status) {
      case "CONTINUE":
        if (ctx.state.finalAuditPending) {
          ctx.state.finalAuditPending = false;
          note(ctx, "info", "Final audit found remaining work; continuing");
        }
        handleContinue(ctx);
        return;
      case "NEEDS_INPUT":
      case "ERROR":
        waitForHumanInput(ctx, marker);
        return;
      case "PLAN_READY":
        startPlannedDevelopment(ctx, marker, text);
        return;
      case "TESTING":
        waitForTesting(ctx, marker);
        return;
      case "COMPLETE":
        if (ctx.state.finalAuditPending) {
          ctx.state.finalAuditPending = false;
          ctx.state.finalAuditVerified = true;
          completeProject(ctx);
        } else {
          ctx.state.finalAuditPending = true;
          ctx.state.status = "inserting";
          note(ctx, "info", "Completion reported; running the required final audit");
          ctx.effects.push({ do: "insertAndSend", kind: "final_audit" });
        }
    }
  }
  function waitForHumanInput(ctx, marker) {
    ctx.state.status = "awaiting_user";
    ctx.state.pauseReason = marker.note ?? "ChatGPT needs your input.";
    ctx.effects.push(
      { do: "badge", text: "?" },
      {
        do: "notify",
        title: "Chat FreePT needs you",
        message: marker.note ?? "ChatGPT is waiting for your input."
      }
    );
  }
  function startPlannedDevelopment(ctx, marker, text) {
    const state = ctx.state;
    state.planSummary = marker.note ?? excerpt(text);
    state.phase = "developing";
    state.status = "inserting";
    state.autoSends = 0;
    state.nudges = 0;
    note(ctx, "info", "Plan ready \u2014 starting development automatically");
    ctx.effects.push({ do: "insertAndSend", kind: "develop" }, { do: "badge", text: "RUN" });
  }
  function waitForTesting(ctx, marker) {
    ctx.state.phase = "testing";
    ctx.state.status = "awaiting_user";
    ctx.state.pauseReason = marker.note ?? "The project is ready for your testing.";
    ctx.effects.push(
      { do: "badge", text: "TEST" },
      {
        do: "notify",
        title: "Chat FreePT is ready for testing",
        message: marker.note ?? "The project is ready for your validation."
      }
    );
  }
  function completeProject(ctx) {
    ctx.state.phase = "complete";
    ctx.state.status = "complete";
    setQueuedMessages(ctx.state, []);
    ctx.state.completedAt = ctx.now;
    note(ctx, "info", "Final audit confirmed completion; automation stopped");
    ctx.effects.push(
      { do: "badge", text: "DONE" },
      { do: "showCompletion" },
      {
        do: "notify",
        title: "Development complete",
        message: ctx.state.repo ? `ChatGPT reports ${ctx.state.repo} is done.` : "ChatGPT reports the project is done."
      }
    );
  }
  function handleContinue(ctx) {
    const state = ctx.state;
    if (state.phase === "plan_ready") state.phase = "planning";
    if (state.phase === "testing") state.phase = "developing";
    if (!isContinuablePhase(state)) {
      state.status = "awaiting_user";
      return;
    }
    if (queuedMessages(state).length > 0) {
      scheduleContinuation(ctx);
      return;
    }
    scheduleContinuation(ctx);
  }
  function isContinuablePhase(state) {
    return state.phase === "planning" || state.phase === "developing";
  }
  function scheduleContinuation(ctx) {
    ctx.state.status = "cooldown";
    ctx.state.cooldownUntil = ctx.now + ctx.settings.sendDelayMs;
    ctx.effects.push(
      { do: "startCooldown", ms: ctx.settings.sendDelayMs },
      { do: "badge", text: "RUN" }
    );
  }
  function excerpt(text) {
    const clean = text.trim().replace(/\s+/g, " ");
    return clean.length > 400 ? `${clean.slice(0, 400)}\u2026` : clean;
  }

  // src/common/types.ts
  var DEFAULT_SETTINGS = {
    v: 1,
    continueMessage: "continue. (End with your CHATFREEPT status block.)",
    autoContinueCap: 50,
    sendDelayMs: 8e3,
    quietMs: 3e3,
    toolQuietMs: 1e4,
    maxStreamMinutes: 20,
    contractRefreshEvery: 12,
    notificationsEnabled: true,
    templateRepo: "mlookhere/CI-Pipline"
  };

  // src/common/settings.ts
  var SETTINGS_LIMITS = {
    autoContinueCap: { min: 1, max: 500 },
    sendDelayMs: { min: 2e3, max: 6e5 },
    quietMs: { min: 1e3, max: 6e4 },
    toolQuietMs: { min: 1e3, max: 12e4 },
    maxStreamMinutes: { min: 1, max: 180 },
    contractRefreshEvery: { min: 1, max: 100 }
  };
  function asRecord(value) {
    return typeof value === "object" && value !== null ? value : {};
  }
  function normalizedNumber(source, key, fallback) {
    const value = source[key];
    if (typeof value !== "number" || !Number.isFinite(value)) return fallback;
    const { min, max } = SETTINGS_LIMITS[key];
    return Math.min(max, Math.max(min, value));
  }
  function normalizedString(source, key, fallback) {
    const value = source[key];
    if (typeof value !== "string") return fallback;
    const trimmed = value.trim();
    return trimmed || fallback;
  }
  function normalizedBoolean(source, key, fallback) {
    const value = source[key];
    return typeof value === "boolean" ? value : fallback;
  }
  function normalizeSettings(value) {
    const source = asRecord(value);
    return {
      v: DEFAULT_SETTINGS.v,
      continueMessage: normalizedString(source, "continueMessage", DEFAULT_SETTINGS.continueMessage),
      autoContinueCap: normalizedNumber(source, "autoContinueCap", DEFAULT_SETTINGS.autoContinueCap),
      sendDelayMs: normalizedNumber(source, "sendDelayMs", DEFAULT_SETTINGS.sendDelayMs),
      quietMs: normalizedNumber(source, "quietMs", DEFAULT_SETTINGS.quietMs),
      toolQuietMs: normalizedNumber(source, "toolQuietMs", DEFAULT_SETTINGS.toolQuietMs),
      maxStreamMinutes: normalizedNumber(
        source,
        "maxStreamMinutes",
        DEFAULT_SETTINGS.maxStreamMinutes
      ),
      contractRefreshEvery: normalizedNumber(
        source,
        "contractRefreshEvery",
        DEFAULT_SETTINGS.contractRefreshEvery
      ),
      notificationsEnabled: normalizedBoolean(
        source,
        "notificationsEnabled",
        DEFAULT_SETTINGS.notificationsEnabled
      ),
      templateRepo: normalizedString(source, "templateRepo", DEFAULT_SETTINGS.templateRepo)
    };
  }

  // src/common/storage.ts
  var SETTINGS_KEY = "cfpt:settings";
  // MV3 can leave a stale/partially available storage namespace during tab
  // hydration or unpacked-extension replacement. Fall back to the privileged
  // service worker when runtime messaging still works; never fall back to
  // webpage localStorage (which would lose ownership and persisted run state).
  async function cfptStorageCall(area, operation, payload) {
    const nativeArea = globalThis.chrome?.storage?.[area];
    if (typeof nativeArea?.[operation] === "function") {
      return nativeArea[operation](payload);
    }
    if (typeof globalThis.chrome?.runtime?.sendMessage !== "function") {
      throw new Error("Extension context invalidated: Chrome storage and messaging unavailable. Reload ChatGPT after updating Chat FreePT.");
    }
    const reply = await chrome.runtime.sendMessage({
      type: "cfpt-storage", area, operation, payload
    });
    if (!reply?.ok) {
      throw new Error(`Extension context invalidated: Chat FreePT storage service unavailable (${reply?.error || "no response"}). Reload the ChatGPT tab after updating the extension.`);
    }
    return reply.value;
  }
  var cfptStorage = {
    local: {
      get: (keys) => cfptStorageCall("local", "get", keys),
      set: (values) => cfptStorageCall("local", "set", values),
      remove: (keys) => cfptStorageCall("local", "remove", keys)
    },
    sync: { get: (keys) => cfptStorageCall("sync", "get", keys) }
  };
  var RUN_PREFIX = "cfpt:run:";
  var PROJECT_PREFIX = "cfpt:project:";
  var SETUP_DRAFT_KEY = "cfpt:pending-project-draft:v1";
  var SETUP_DRAFT_MAX_AGE_MS = 60 * 60 * 1e3;
  async function saveSetupDraft(idea, repoName) {
    await cfptStorage.local.set({
      [SETUP_DRAFT_KEY]: { idea, repoName, at: Date.now() }
    });
  }
  async function takeSetupDraft() {
    const data = (await cfptStorage.local.get(SETUP_DRAFT_KEY))[SETUP_DRAFT_KEY];
    if (!data) return null;
    await cfptStorage.local.remove(SETUP_DRAFT_KEY);
    if (typeof data.idea !== "string" || typeof data.repoName !== "string" ||
      !Number.isFinite(data.at) || Date.now() - data.at > SETUP_DRAFT_MAX_AGE_MS) return null;
    return { idea: data.idea, repoName: data.repoName };
  }
  async function loadProjectRepo(projectId) {
    if (!projectId) return null;
    const found = await cfptStorage.local.get(PROJECT_PREFIX + projectId);
    return normalizeRepositoryInput(found[PROJECT_PREFIX + projectId]?.repo ?? "");
  }
  async function bindProjectRepo(projectId, repo) {
    if (!projectId || !repo) throw new Error("A ChatGPT Project and repository are required");
    const existing = await loadProjectRepo(projectId);
    if (existing && existing.toLowerCase() !== repo.toLowerCase()) {
      throw new Error(`Project is already bound to ${existing}; refusing to switch repositories`);
    }
    if (!existing) await cfptStorage.local.set({ [PROJECT_PREFIX + projectId]: { repo, boundAt: Date.now() } });
  }
  async function loadSettings() {
    const found = await cfptStorage.sync.get(SETTINGS_KEY);
    return normalizeSettings(found[SETTINGS_KEY]);
  }
  function runKey(conversationId) {
    return `${RUN_PREFIX}${conversationId}`;
  }
  async function loadRun(conversationId) {
    const key = runKey(conversationId);
    const found = await cfptStorage.local.get(key);
    const state = found[key];
    return state && state.v === 1 ? normalizeRunRepositoryState(state) : null;
  }
  async function saveRun(state) {
    const normalized2 = normalizeRunRepositoryState(state);
    await cfptStorage.local.set({ [runKey(normalized2.conversationId)]: normalized2 });
  }
  function normalizeRunRepositoryState(state) {
    const continuous = { ...state, autoContinueEnabled: true };
    const lockedRepo = continuous.repo ? normalizeRepositoryInput(continuous.repo) : null;
    if (lockedRepo) {
      return { ...continuous, repo: lockedRepo, repoName: lockedRepo, repoMode: "existing" };
    }
    const draftRepo = normalizeRepositoryInput(continuous.repoName);
    if (draftRepo) return { ...continuous, repoName: draftRepo, repoMode: "existing" };
    return continuous;
  }
  async function deleteRun(conversationId) {
    await cfptStorage.local.remove(runKey(conversationId));
  }
  // The service worker arbitrates all ownership changes in one queue, using
  // sender.tab.id to distinguish a real second tab from a stale lock after reload.
  async function requestTabLock(action, conversationId, nonce) {
    const response = await chrome.runtime.sendMessage({
      type: "cfpt-lock", action, conversationId, nonce
    });
    if (!response?.ok) throw new Error("Conversation ownership service unavailable");
    return response.owned === true;
  }
  function acquireTabLock(conversationId, nonce) {
    return requestTabLock("acquire", conversationId, nonce);
  }
  function heartbeatTabLock(conversationId, nonce) {
    return requestTabLock("heartbeat", conversationId, nonce);
  }
  function releaseTabLock(conversationId, nonce) {
    return requestTabLock("release", conversationId, nonce);
  }
  async function migrateRunKey(state, newConversationId) {
    const old = state.conversationId;
    const next = normalizeRunRepositoryState({ ...state, conversationId: newConversationId });
    await saveRun(next);
    if (old !== newConversationId) await cfptStorage.local.remove(runKey(old));
    return next;
  }
  async function adoptConversationOwnership(state, newConversationId, nonce) {
    const oldConversationId = state.conversationId;
    if (oldConversationId === newConversationId) return state;
    const acquired = await acquireTabLock(newConversationId, nonce);
    if (!acquired) return null;
    let migrated;
    try {
      migrated = await migrateRunKey(state, newConversationId);
    } catch (error) {
      await releaseTabLock(newConversationId, nonce);
      throw error;
    }
    await releaseTabLock(oldConversationId, nonce);
    return migrated;
  }

  // src/content/chat-state.ts
  var BRIDGE_SOURCE = "cfpt-chat-state-bridge";
  var SCRIPT_ID = "cfpt-chat-state-bridge-script";
  var listeners = /* @__PURE__ */ new Set();
  var listenerInstalled = false;
  function onMessage(event) {
    if (event.source !== window || !event.data || typeof event.data !== "object") return;
    const envelope = event.data;
    if (envelope["source"] !== BRIDGE_SOURCE) return;
    const payload = envelope["payload"];
    if (!payload || typeof payload !== "object") return;
    const value = payload;
    if (value.version !== 1 || typeof value.event !== "string") return;
    for (const listener of listeners) listener(value);
  }
  function ensureChatStateBridge() {
    if (!listenerInstalled) {
      window.addEventListener("message", onMessage);
      listenerInstalled = true;
    }
    if (document.getElementById(SCRIPT_ID)) return;
    const script = document.createElement("script");
    script.id = SCRIPT_ID;
    script.src = chrome.runtime.getURL("chat-state-bridge.js");
    script.async = false;
    (document.head ?? document.documentElement).appendChild(script);
  }
  function subscribeChatState(listener) {
    ensureChatStateBridge();
    listeners.add(listener);
    return () => listeners.delete(listener);
  }

  // src/common/marker.ts
  var STATUS_LINE = /(?:^|\n)\s*(?:>\s*)?(?:[-*]\s+)?(?:\*\*|__|`)?CHATFREEPT_STATUS(?:\*\*|__|`)?\s*:(?:\*\*|__|`)?\s*(?:\*\*|__|`)?(CONTINUE|NEEDS(?:[_ -]+)INPUT|PLAN(?:[_ -]+)READY|TESTING|COMPLETE|ERROR)\b/gi;
  var FIELD_LINE = /^\s*(?:(?:>|[-*])\s*)?(?:(?:\*\*|__|`))?(V|PHASE|REPO|ITEM|NOTE|URL|BRANCH|ISSUE|PR|CI|CHECKS|ACTIONS)(?:\*\*|__|`)?\s*:(?:\*\*|__|`)?\s*(.+?)\s*$/i;
  var REPO_RE2 = /^[\w.-]+\/[\w.-]+$/;
  var STATUS_LABEL = {
    CONTINUE: "Continue",
    NEEDS_INPUT: "Needs input",
    PLAN_READY: "Plan ready",
    TESTING: "Testing",
    COMPLETE: "Complete",
    ERROR: "Error"
  };
  function parseMarker(text) {
    if (!text) return null;
    let last = null;
    STATUS_LINE.lastIndex = 0;
    for (let match = STATUS_LINE.exec(text); match !== null; match = STATUS_LINE.exec(text)) {
      last = match;
    }
    if (!last || text.length - last.index > 2500) return null;
    const status = normalizeStatus(last[1] ?? "");
    if (!status) return null;
    const tail = text.slice(last.index).trimStart();
    const lines = tail.split(/\r?\n/).slice(1);
    const marker = { status, version: 1, raw: firstLine(tail) };
    for (const line of lines.slice(0, 28)) {
      const trimmed = line.trim();
      if (trimmed === "" || /^`{3,}/.test(trimmed)) continue;
      const field = FIELD_LINE.exec(line);
      if (!field) break;
      applyField(marker, field[1] ?? "", normalizeMarkerValue(field[2] ?? ""));
    }
    marker.raw = summarize(marker);
    return marker;
  }
  function normalizeMarkerValue(raw) {
    // textContent is normally decoded, but markdown/entity-escaped replies also occur.
    const decoded = raw.replace(/&#(?:x([0-9a-f]+)|([0-9]+));/gi, (_, hex, decimal) => {
      const codepoint = Number.parseInt(hex ?? decimal, hex ? 16 : 10);
      return Number.isFinite(codepoint) && codepoint <= 1114111 && !(codepoint >= 55296 && codepoint <= 57343) ? String.fromCodePoint(codepoint) : "";
    }).replace(/&amp;/gi, "&").replace(/&lt;/gi, "<").replace(/&gt;/gi, ">");
    const unwrapped = decoded.trim().replace(/^(?:\*\*|__|`)+|(?:\*\*|__|`)+$/g, "").trim();
    const link = /^\[([^\]]+)\]\((https:\/\/[^)]+)\)$/.exec(unwrapped);
    return (link ? link[2] : unwrapped).trim();
  }
  function applyField(marker, key, value) {
    switch (key.toUpperCase()) {
      case "V": {
        const version = Number.parseInt(value, 10);
        if (Number.isFinite(version)) marker.version = version;
        return;
      }
      case "PHASE":
        marker.phase = value;
        return;
      case "REPO":
        if (REPO_RE2.test(value)) marker.repo = value;
        return;
      case "ITEM":
        marker.item = value;
        return;
      case "NOTE":
        marker.note = value;
        return;
      case "URL":
        marker.url = value.slice(0, 600);
        return;
      case "BRANCH":
        if (/^[\w./-]{1,180}$/.test(value)) marker.branch = value;
        return;
      case "ISSUE":
      case "PR":
      case "ACTIONS":
        marker[key.toLowerCase()] = value.slice(0, 600);
        return;
      case "CHECKS":
        marker.checks = value.slice(0, 140);
        return;
      case "CI": {
        const ci = value.trim().replace(/[\s_-]+/g, " ").toUpperCase();
        const statuses = {
          "NOT RUN": "NOT_RUN", "QUEUED": "QUEUED", "PENDING": "QUEUED",
          "IN PROGRESS": "RUNNING", "RUNNING": "RUNNING", "PASS": "PASSED",
          "PASSED": "PASSED", "SUCCESS": "PASSED", "GREEN": "PASSED",
          "FAILED": "FAILED", "FAILURE": "FAILED", "RED": "FAILED",
          "CANCELLED": "CANCELLED", "CANCELED": "CANCELLED",
          "UNKNOWN": "UNKNOWN", "UNVERIFIED": "UNKNOWN"
        };
        marker.ci = statuses[ci] ?? "UNKNOWN";
      }
    }
  }
  function normalizeStatus(value) {
    const normalized2 = value.trim().replace(/[_-]+/g, " ").replace(/\s+/g, " ").toUpperCase();
    switch (normalized2) {
      case "CONTINUE":
        return "CONTINUE";
      case "NEEDS INPUT":
        return "NEEDS_INPUT";
      case "PLAN READY":
        return "PLAN_READY";
      case "TESTING":
        return "TESTING";
      case "COMPLETE":
        return "COMPLETE";
      case "ERROR":
        return "ERROR";
      default:
        return null;
    }
  }
  function firstLine(text) {
    const idx = text.indexOf("\n");
    return idx === -1 ? text : text.slice(0, idx);
  }
  function summarize(marker) {
    const parts = [STATUS_LABEL[marker.status]];
    if (marker.phase) parts.push(`phase=${marker.phase}`);
    if (marker.repo) parts.push(`repo=${marker.repo}`);
    if (marker.item) parts.push(`item=${marker.item}`);
    if (marker.note) parts.push(`note=${marker.note}`);
    if (marker.ci) parts.push(`ci=${marker.ci}`);
    if (marker.checks) parts.push(`checks=${marker.checks}`);
    return parts.join(" ");
  }

  // src/diagnostics/sanitize.ts
  var SENSITIVE_KEY_RE = /authorization|cookie|token|secret|password|credential|api[-_]?key|session|csrf|jwt/i;
  var ID_SEGMENT_RE = /^(?:[0-9a-f]{20,}|[0-9a-f]{8}-[0-9a-f-]{20,}|eyJ[A-Za-z0-9._-]{16,}|[A-Za-z0-9_-]{28,})$/i;
  var MAX_KEYS = 40;
  function hashText(text) {
    let hash = 2166136261;
    for (let i = 0; i < text.length; i += 1) {
      hash ^= text.charCodeAt(i);
      hash = Math.imul(hash, 16777619);
    }
    return (hash >>> 0).toString(16).padStart(8, "0");
  }
  function summarizeString(text) {
    return { kind: "string", length: text.length, hash: hashText(text) };
  }
  function redactUrl(input) {
    let parsed;
    try {
      parsed = new URL(input, "https://chatgpt.com");
    } catch {
      return "[invalid-url]";
    }
    const path = parsed.pathname.split("/").map((segment) => ID_SEGMENT_RE.test(segment) ? "[id]" : segment).join("/");
    const keys = Array.from(parsed.searchParams.keys());
    const query2 = keys.length > 0 ? `?${keys.map((key) => `${encodeURIComponent(key)}=[redacted]`).join("&")}` : "";
    return `${parsed.origin}${path}${query2}`;
  }
  function safeError(error) {
    if (error instanceof Error) {
      return { name: error.name, message: summarizeString(error.message) };
    }
    return { name: typeof error, message: summarizeString(String(error)) };
  }
  function summarizeUnknown(value) {
    if (value === null) return { kind: "null" };
    if (value === void 0) return { kind: "undefined" };
    if (typeof value === "string") return summarizeString(value);
    if (typeof value === "number" || typeof value === "boolean" || typeof value === "bigint") {
      return { kind: typeof value };
    }
    if (value instanceof URLSearchParams) {
      return { kind: "url-search-params", keys: unique(Array.from(value.keys())) };
    }
    if (typeof FormData !== "undefined" && value instanceof FormData) {
      return { kind: "form-data", keys: unique(Array.from(value.keys())) };
    }
    if (typeof Blob !== "undefined" && value instanceof Blob) {
      return { kind: "blob", length: value.size };
    }
    if (value instanceof ArrayBuffer) return { kind: "array-buffer", length: value.byteLength };
    if (ArrayBuffer.isView(value)) return { kind: "typed-array", length: value.byteLength };
    if (Array.isArray(value)) return { kind: "array", length: value.length };
    if (typeof value === "object") {
      return { kind: "object", keys: safeKeys(value) };
    }
    return { kind: typeof value };
  }
  function safeKeys(value) {
    return Object.keys(value).filter((key) => !SENSITIVE_KEY_RE.test(key)).slice(0, MAX_KEYS);
  }
  function unique(values) {
    return Array.from(new Set(values)).slice(0, MAX_KEYS);
  }

  // src/content/selectors.ts
  var REGISTRY = {
    composer: {
      required: true,
      candidates: [
        { css: '[data-chatgpt-composer] [data-composer-input] [role="textbox"]' },
        { css: 'form[data-chatgpt-composer] [role="textbox"]' },
        { css: "#prompt-textarea" },
        { css: '[data-chatgpt-composer] [data-composer-input] [contenteditable="true"]' },
        { css: 'form[data-chatgpt-composer] [contenteditable="true"]' },
        { css: 'div.ProseMirror[contenteditable="true"]' },
        { css: 'form[data-type="unified-composer"] [contenteditable="true"]' },
        { css: 'main [contenteditable="true"]' }
      ]
    },
    composerHeader: {
      required: false,
      candidates: [
        { css: "#thread-bottom [data-prompt-textarea-header]" },
        { css: "main [data-prompt-textarea-header]" },
        { css: "[data-prompt-textarea-header]" }
      ]
    },
    composerSurface: {
      required: false,
      candidates: [
        { css: "[data-chatgpt-composer] [data-composer-body]" },
        { css: "form[data-chatgpt-composer] [data-composer-body]" },
        { css: "[data-composer-body]" },
        { css: '#thread-bottom form[data-type="unified-composer"] [data-composer-surface="true"]' },
        { css: 'form[data-type="unified-composer"] [data-composer-surface="true"]' },
        { css: '[data-composer-surface="true"]' },
        { css: "form[data-chatgpt-composer]" },
        { css: 'form[data-type="unified-composer"]' }
      ]
    },
    composerForm: {
      required: false,
      candidates: [
        { css: "form[data-chatgpt-composer]" },
        { css: 'form[data-type="unified-composer"]' },
        { css: "#thread-bottom form" }
      ]
    },
    sendButton: {
      // ChatGPT intentionally omits Send while the composer is empty. clickSend() waits
      // for it after prompt insertion, so its idle absence is not a page-health failure.
      required: false,
      candidates: [
        { css: 'button[data-testid="send-button"]' },
        { css: "#composer-submit-button" },
        { css: 'button[aria-label="Send prompt"]' },
        { css: 'button[aria-label="Send"]' },
        { css: '[data-chatgpt-composer] button[type="submit"]' },
        { css: 'form[data-type="unified-composer"] button[type="submit"]' },
        { css: "form button", textRe: /^send$/i }
      ]
    },
    stopButton: {
      required: false,
      candidates: [
        { css: 'button[data-testid="stop-button"]' },
        { css: 'button[aria-label="Stop streaming"]' },
        { css: 'button[aria-label="Stop generating"]' },
        // Keep broad label fallbacks inside the composer so unrelated page controls cannot match.
        { css: '#thread-bottom form button[aria-label*="Stop"]' },
        { css: 'form[data-chatgpt-composer] button[aria-label*="Stop"]' },
        { css: 'form[data-type="unified-composer"] button[aria-label*="Stop"]' }
      ]
    },
    assistantMessage: {
      required: false,
      candidates: [
        { css: '[data-message-author-role="assistant"][data-message-id]' },
        { css: '[data-message-author-role="assistant"]' },
        { css: '[data-testid^="conversation-turn"][data-turn="assistant"] .agent-turn' },
        { css: '[data-testid^="conversation-turn"][data-turn="assistant"]' },
        { css: '[data-testid^="conversation-turn-"]:has(.agent-turn)' },
        { css: '[data-testid^="conversation-turn-"]:has([data-message-author-role="assistant"])' },
        // New ChatGPT/DIL turns use search units instead of legacy role attributes.
        { css: '[data-content-search-unit-key$=":assistant"]' },
        { css: '[data-chatgpt-search-unit-key$=":assistant"]' },
        { css: '[data-markdown-text-style="assistant-message"]' }
      ]
    },
    userMessage: {
      required: false,
      candidates: [
        { css: '[data-message-author-role="user"][data-message-id]' },
        { css: '[data-message-author-role="user"]' },
        { css: '[data-testid^="conversation-turn"][data-turn="user"] .user-turn' },
        { css: '[data-testid^="conversation-turn"][data-turn="user"]' },
        { css: '[data-testid^="conversation-turn-"]:has(.user-turn)' },
        { css: '[data-testid^="conversation-turn-"]:has([data-message-author-role="user"])' },
        { css: '[data-content-search-unit-key$=":user"]' },
        { css: '[data-chatgpt-search-unit-key$=":user"]' }
      ]
    },
    conversationRoot: {
      required: true,
      candidates: [{ css: "#thread" }, { css: "main#main" }, { css: "main" }, { css: "body" }]
    },
    regenerateButton: {
      required: false,
      candidates: [
        { css: 'button[data-testid="regenerate-thread-error-button"]' },
        { css: "main button", textRe: /^(regenerate|try again)$/i }
      ]
    },
    loginButton: {
      required: false,
      candidates: [
        { css: '[data-testid="login-button"]' },
        { css: "button, a", textRe: /^log in$/i }
      ]
    },
    pageAlert: {
      required: false,
      candidates: [{ css: '[role="alert"], [class*="toast"]' }]
    },
    toolIndicator: {
      required: false,
      candidates: [{ css: '[data-testid*="tool"]' }]
    }
  };
  function matches(candidate, root) {
    let found;
    try {
      found = Array.from(root.querySelectorAll(candidate.css));
    } catch {
      return [];
    }
    if (!candidate.textRe) return found;
    const re = candidate.textRe;
    return found.filter((el) => re.test((el.textContent ?? "").trim()));
  }
  function resolve(id, root = document) {
    const target = REGISTRY[id];
    for (let i = 0; i < target.candidates.length; i++) {
      const candidate = target.candidates[i];
      if (!candidate) continue;
      const found = matches(candidate, root);
      const element = id === "composer" ? found.find((node) => {
        if (!(node instanceof HTMLElement)) return false;
        const style = getComputedStyle(node);
        return node.isConnected && !node.closest("[inert]") &&
          !node.hasAttribute("inert") && node.getAttribute("aria-disabled") !== "true" &&
          style.display !== "none" && style.visibility !== "hidden" &&
          node.getClientRects().length > 0;
      }) : found[0];
      if (element) return { element, candidateIndex: i };
    }
    return null;
  }
  function query(id, root = document) {
    return resolve(id, root)?.element ?? null;
  }
  function queryAll(id, root = document) {
    for (const candidate of REGISTRY[id].candidates) {
      const found = matches(candidate, root);
      if (found.length > 0) return found;
    }
    return [];
  }
  function queryLast(id, root = document) {
    const target = REGISTRY[id];
    // ChatGPT may use old and new message renderers in the same hydrated page.
    // Pick the latest matching DOM node across ALL supported layouts, not the
    // last match from whichever legacy selector happens to win first.
    if (id === "assistantMessage" || id === "userMessage") {
      // querySelectorAll merges selectors in document order and de-duplicates.
      // One DOM traversal replaces up to nine full-document scans per poll.
      const selectors = target.candidates.map((candidate) => candidate.css).join(", ");
      const nodes = root.querySelectorAll(selectors);
      return nodes[nodes.length - 1] ?? null;
    }
    for (const candidate of target.candidates) {
      const found = matches(candidate, root);
      const last = found[found.length - 1];
      if (last) return last;
    }
    return null;
  }
  function require_(id, timeoutMs = 1e4, pollMs = 200) {
    return new Promise((resolvePromise, reject) => {
      const started = Date.now();
      const attempt = () => {
        const el = query(id);
        if (el) {
          resolvePromise(el);
          return;
        }
        if (Date.now() - started > timeoutMs) {
          reject(new Error(`selector target not found: ${id}`));
          return;
        }
        setTimeout(attempt, pollMs);
      };
      attempt();
    });
  }
  function healthCheck(root = document) {
    const missing = [];
    const degraded = [];
    for (const id of Object.keys(REGISTRY)) {
      const target = REGISTRY[id];
      const res = resolve(id, root);
      if (!res) {
        if (target.required) missing.push(id);
      } else if (res.candidateIndex > 0) {
        degraded.push({ id, candidateIndex: res.candidateIndex });
      }
    }
    return { missing, degraded };
  }
  var GUIDE_RESOLVERS = {
    composerPlusButton,
    githubPermissionPrompt,
    githubPermissionContinueButton
  };
  function queryGuideTarget(id) {
    return GUIDE_RESOLVERS[id]();
  }
  function githubPermissionPrompt() {
    return githubPermissionGate()?.prompt ?? null;
  }
  function githubPermissionContinueButton() {
    return githubPermissionGate()?.button ?? null;
  }
  function githubPermissionGate() {
    const buttons = Array.from(document.querySelectorAll('button, [role="button"]'));
    for (const button of buttons) {
      if (!isVisible(button) || !/^continue$/i.test((button.textContent ?? "").trim())) continue;
      let current = button.parentElement;
      for (let depth = 0; current && depth < 7; depth += 1, current = current.parentElement) {
        const text = (current.innerText ?? current.textContent ?? "").replace(/\s+/g, " ").trim();
        if (/github/i.test(text) && /(freept|mcp|connector|allow|permission|access)/i.test(text)) {
          return { prompt: current, button };
        }
      }
    }
    return null;
  }
  function isVisible(element) {
    if (element.hidden || element.getAttribute("aria-hidden") === "true") return false;
    const style = getComputedStyle(element);
    return style.display !== "none" && style.visibility !== "hidden";
  }
  function activeComposerForm() {
    // Prefer the form containing the actual, visible editor. During extended
    // composer takeover the native editor is intentionally hidden, so fall back
    // to a connected form rather than selecting a detached/stale React form.
    const editor = query("composer");
    const editingForm = editor?.closest("form");
    if (editingForm) return editingForm;
    const forms = document.querySelectorAll('form[data-chatgpt-composer], form[data-type="unified-composer"]');
    for (const form of forms) {
      if (!form.isConnected || !form.getClientRects().length || form.closest("[inert]")) continue;
      if (!form.querySelector('[role="textbox"], [contenteditable="true"], [data-composer-input]')) continue;
      return form;
    }
    return null;
  }
  function composerPlusButton(form = activeComposerForm()) {
    if (!form) return null;
    const selectors = [
      'button[data-testid="composer-plus-btn"]',
      'button[aria-label*="Add photos" i]',
      'button[aria-label*="Add files" i]',
      'button[aria-label*="Attach" i]',
      'button[aria-label*="Upload" i]'
    ];
    for (const css of selectors) {
      const found = form.querySelector(css);
      if (found?.isConnected && found.getClientRects().length) return found;
    }
    return textElement(/^\+$/i, form, "button");
  }
  function textElement(pattern, root = document, css = "button, a, label, h1, h2, h3, h4, strong, span, div, p") {
    let nodes;
    try {
      nodes = Array.from(root.querySelectorAll(css));
    } catch {
      return null;
    }
    const matches2 = nodes.filter((element) => {
      if (element.getAttribute("aria-hidden") === "true") return false;
      return pattern.test((element.textContent ?? "").trim());
    });
    matches2.sort(
      (a, b) => a.children.length - b.children.length || (a.textContent?.length ?? 0) - (b.textContent?.length ?? 0)
    );
    return matches2[0] ?? null;
  }

  // src/content/transcript.ts
  function assistantStatusText(el) {
    const visible = el.innerText ?? "";
    const raw = el.textContent ?? "";
    // DIL-rendered fenced code blocks preserve newlines in their CODE text,
    // even when innerText collapses them and the host's textContent concatenates
    // the "chatfreept" language label onto CHATFREEPT_STATUS without a separator.
    // Prefer the last valid fenced status block as authoritative marker text.
    const codeBlocks = Array.from(el.querySelectorAll('[data-code-block-source] code, pre code, [data-code-block] code'));
    for (let i = codeBlocks.length - 1; i >= 0; i--) {
      const exact = codeBlocks[i].textContent ?? "";
      if (parseMarker(exact)) return `${visible || raw}\n${exact}`;
    }
    // Rich/DIL-rendered status lines may be flattened by innerText, while
    // textContent preserves embedded newlines. Favor the more complete marker.
    const completeness = (text) => {
      const marker = parseMarker(text);
      return marker ? Object.keys(marker).filter((key) => key !== "raw").length : 0;
    };
    return raw !== visible && completeness(raw) > completeness(visible) ? raw : visible || raw;
  }
  function lastAssistantMessage() {
    const el = queryLast("assistantMessage");
    if (!el) return null;
    const text = assistantStatusText(el);
    const turnState = el.closest('[data-talvt-turn-state]')?.getAttribute('data-talvt-turn-state') ?? null;
    return { el, text, key: assistantMessageKey(el, text), turnState, complete: turnState === 'complete' };
  }
  function lastUserMessageText() {
    const el = queryLast("userMessage");
    if (!el) return null;
    const text = (el.innerText ?? el.textContent ?? "").trim();
    return text || null;
  }
  function lastMessageRole() {
    const assistant = queryLast("assistantMessage");
    const user = queryLast("userMessage");
    if (!assistant && !user) return null;
    if (!assistant) return "user";
    if (!user) return "assistant";
    const order = assistant.compareDocumentPosition(user);
    return order & Node.DOCUMENT_POSITION_FOLLOWING ? "user" : "assistant";
  }
  function toolCallIndicatorVisible() {
    const turn = queryLast("assistantMessage");
    if (!turn) return false;
    // A completed GitHub tool card remains in the transcript. Its existence or
    // the word "Working" in a reply cannot prove that a tool is still executing.
    // Check only explicit, visible busy indicators; network requests and the
    // native Stop control independently guard against duplicate sends.
    const active = turn.querySelectorAll('[aria-busy="true"], [role="progressbar"], [data-state="running"], [data-status="running"], [data-loading="true"], [data-is-running="true"]');
    return Array.from(active).some((node) => node.isConnected &&
      !node.closest('[hidden], [inert], [aria-hidden="true"]') &&
      (!node.getClientRects || node.getClientRects().length > 0));
  }
  function activeStopButton() {
    // Ignore stale buttons retained in a hidden React composer during SPA handoff.
    for (const candidate of REGISTRY.stopButton.candidates) {
      const button = matches(candidate, document).find((node) => node.isConnected &&
        !node.closest('[hidden], [inert], [aria-hidden="true"]') &&
        node.getClientRects().length > 0 &&
        getComputedStyle(node).visibility !== "hidden" &&
        getComputedStyle(node).display !== "none");
      if (button) return button;
    }
    return null;
  }
  // A persisted /c/<id> route is an existing conversation even when messages are
  // virtualized or ChatGPT has not finished rendering its transcript.
  function conversationHasHistory() {
    return lastMessageRole() !== null || Boolean(conversationIdFromUrl(location.href));
  }
  // History is advisory; only the most recent completed assistant turn may drive
  // automation. Earlier markers provide inexpensive, read-only context and repo hints.
  function transcriptAssistantNodes() {
    const matches = queryAll("assistantMessage");
    if (matches.length > 0) return matches;
    // Newer ChatGPT message renderers may expose DIL nodes inside a turn without
    // the older role attributes. Never scan the user's own turns for status.
    return Array.from(document.querySelectorAll('main [data-testid^="conversation-turn-"]'))
      .filter((turn) => !turn.matches('[data-turn="user"]') &&
        !turn.querySelector('[data-message-author-role="user"], .user-turn, [data-turn="user"]') &&
        Boolean(turn.querySelector('[data-dil-message-id], [data-message-author-role="assistant"], .agent-turn')));
  }
  function recentConversationStatus() {
    const messages = transcriptAssistantNodes();
    for (let i = messages.length - 1, count = 0; i >= 0 && count < 16; i--, count++) {
      const el = messages[i];
      const text = el ? assistantStatusText(el) : "";
      const marker = parseMarker(text);
      if (marker) return { marker, text, key: assistantMessageKey(el, text) };
    }
    return null;
  }
  function recentConversationMarker() {
    return recentConversationStatus()?.marker ?? null;
  }
  function conversationRootEl() {
    return query("conversationRoot") ?? document.body;
  }
  function assistantMessageKey(el, text) {
    const dilId = el.getAttribute('data-chatgpt-search-message-ids') ||
      el.querySelector('[data-dil-message-id]')?.getAttribute('data-dil-message-id') ||
      el.querySelector('[data-chatgpt-selection-message-id]')?.getAttribute('data-chatgpt-selection-message-id');
    if (dilId) return `dil:${dilId}`;
    const directId = el.getAttribute("data-message-id");
    if (directId) return `message:${directId}`;
    const messageHost = el.closest("[data-message-id]");
    const hostId = messageHost?.getAttribute("data-message-id");
    if (hostId) return `message:${hostId}`;
    const turn = el.closest('[data-testid^="conversation-turn"]');
    const turnId = turn?.getAttribute("data-testid");
    if (turnId) return `turn:${turnId}`;
    return `text:${fnv1a(text)}`;
  }
  function fnv1a(text) {
    let hash = 2166136261;
    for (let i = 0; i < text.length; i += 1) {
      hash ^= text.charCodeAt(i);
      hash = Math.imul(hash, 16777619);
    }
    return (hash >>> 0).toString(16).padStart(8, "0");
  }

  // src/content/diagnostics.ts
  var CONTENT_SOURCE = "cfpt-diagnostics-content";
  var BRIDGE_SOURCE2 = "cfpt-diagnostics-bridge";
  var SNAPSHOT_MS = 1e3;
  var SNAPSHOT_HEARTBEAT_MS = 1e4;
  var DOM_SETTLE_MS = 80;
  var MAX_RECORDS = 3e4;
  var TRIM_BATCH = 2e3;
  var PAGE_SCRIPT_ID = "cfpt-diagnostics-page-bridge";
  var DiagnosticsRecorder = class {
    constructor(hooks) {
      this.hooks = hooks;
    }
    hooks;
    sessionId = crypto.randomUUID();
    channel = crypto.randomUUID();
    records = [];
    active = false;
    startedAtMs = 0;
    dropped = 0;
    seq = 0;
    snapshotTimer;
    domTimer;
    observer = null;
    lastSnapshotHash = "";
    lastSnapshotAt = 0;
    pageMessage = (event) => this.onPageMessage(event);
    uiEvent = (event) => this.onUiEvent(event);
    visibilityEvent = () => this.record("lifecycle", { event: "visibilitychange", visibility: document.visibilityState });
    focusEvent = () => this.record("lifecycle", { event: "focus", hasFocus: document.hasFocus() });
    blurEvent = () => this.record("lifecycle", { event: "blur", hasFocus: document.hasFocus() });
    onlineEvent = () => this.record("lifecycle", { event: "online", online: navigator.onLine });
    offlineEvent = () => this.record("lifecycle", { event: "offline", online: navigator.onLine });
    pageShowEvent = (event) => this.record("lifecycle", { event: "pageshow", persisted: event.persisted });
    pageHideEvent = (event) => this.record("lifecycle", { event: "pagehide", persisted: event.persisted });
    popStateEvent = () => this.record("navigation", { event: "popstate", route: redactUrl(location.href) });
    hashChangeEvent = () => this.record("navigation", { event: "hashchange", route: redactUrl(location.href) });
    errorEvent = (event) => this.record("error", {
      event: "window-error",
      filename: event.filename ? redactUrl(event.filename) : void 0,
      line: event.lineno,
      column: event.colno,
      error: safeError(event.error ?? event.message)
    });
    rejectionEvent = (event) => this.record("error", { event: "unhandled-rejection", error: safeError(event.reason) });
    storageChanged = (changes, areaName) => this.onStorageChange(changes, areaName);
    get status() {
      const status = {
        recording: this.active,
        records: this.records.length,
        dropped: this.dropped
      };
      if (this.startedAtMs > 0) status.startedAt = new Date(this.startedAtMs).toISOString();
      return status;
    }
    start() {
      if (this.active) return;
      this.sessionId = crypto.randomUUID();
      this.records = [];
      this.dropped = 0;
      this.seq = 0;
      this.startedAtMs = Date.now();
      this.lastSnapshotHash = "";
      this.lastSnapshotAt = 0;
      this.active = true;
      this.installListeners();
      this.injectPageBridge();
      this.record("session", {
        event: "start",
        route: redactUrl(location.href),
        userAgent: summarizeString(navigator.userAgent)
      });
      this.captureSnapshot("start", true);
      this.snapshotTimer = setInterval(() => this.captureSnapshot("poll"), SNAPSHOT_MS);
      this.notifyStatus();
    }
    stop() {
      if (!this.active) return;
      this.captureSnapshot("stop", true);
      this.record("session", { event: "stop" });
      this.active = false;
      this.uninstallListeners();
      this.postBridgeControl("stop");
      this.notifyStatus();
    }
    dispose() {
      if (this.active) this.stop();
      if (this.snapshotTimer !== void 0) clearInterval(this.snapshotTimer);
      this.snapshotTimer = void 0;
      if (this.domTimer !== void 0) clearTimeout(this.domTimer);
      this.domTimer = void 0;
    }
    exportFile() {
      const payload = this.buildExport();
      const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      anchor.href = url;
      anchor.download = `chat-freept-diagnostics-${safeTimestamp(payload.exportedAt)}.json`;
      anchor.style.display = "none";
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1e3);
    }
    buildExport() {
      if (this.active) this.captureSnapshot("export", true);
      const exportedAt = (/* @__PURE__ */ new Date()).toISOString();
      return {
        version: 1,
        product: "Chat FreePT",
        kind: "state-diagnostics",
        sessionId: this.sessionId,
        startedAt: new Date(this.startedAtMs || Date.now()).toISOString(),
        exportedAt,
        summary: this.buildSummary(exportedAt),
        records: [...this.records]
      };
    }
    recordControllerEvent(event) {
      if (!this.active) return;
      this.record("extension", sanitizeControllerEvent(event));
      if (event.kind === "state-transition") this.captureSnapshot("state-transition", true);
    }
    captureSnapshot(reason, force = false) {
      if (!this.active) return;
      const snapshot = buildSemanticSnapshot(this.hooks.getRunState());
      const fingerprint = hashText(JSON.stringify(snapshot));
      const now = Date.now();
      const heartbeatDue = now - this.lastSnapshotAt >= SNAPSHOT_HEARTBEAT_MS;
      if (!force && fingerprint === this.lastSnapshotHash && !heartbeatDue) return;
      this.lastSnapshotHash = fingerprint;
      this.lastSnapshotAt = now;
      this.record("snapshot", { reason, fingerprint, state: snapshot });
    }
    installListeners() {
      window.addEventListener("message", this.pageMessage);
      document.addEventListener("click", this.uiEvent, true);
      document.addEventListener("change", this.uiEvent, true);
      document.addEventListener("input", this.uiEvent, true);
      document.addEventListener("submit", this.uiEvent, true);
      document.addEventListener("keydown", this.uiEvent, true);
      document.addEventListener("visibilitychange", this.visibilityEvent);
      window.addEventListener("focus", this.focusEvent);
      window.addEventListener("blur", this.blurEvent);
      window.addEventListener("online", this.onlineEvent);
      window.addEventListener("offline", this.offlineEvent);
      window.addEventListener("pageshow", this.pageShowEvent);
      window.addEventListener("pagehide", this.pageHideEvent);
      window.addEventListener("popstate", this.popStateEvent);
      window.addEventListener("hashchange", this.hashChangeEvent);
      window.addEventListener("error", this.errorEvent);
      window.addEventListener("unhandledrejection", this.rejectionEvent);
      chrome.storage?.onChanged?.addListener(this.storageChanged);
      this.installMutationObserver();
    }
    uninstallListeners() {
      window.removeEventListener("message", this.pageMessage);
      document.removeEventListener("click", this.uiEvent, true);
      document.removeEventListener("change", this.uiEvent, true);
      document.removeEventListener("input", this.uiEvent, true);
      document.removeEventListener("submit", this.uiEvent, true);
      document.removeEventListener("keydown", this.uiEvent, true);
      document.removeEventListener("visibilitychange", this.visibilityEvent);
      window.removeEventListener("focus", this.focusEvent);
      window.removeEventListener("blur", this.blurEvent);
      window.removeEventListener("online", this.onlineEvent);
      window.removeEventListener("offline", this.offlineEvent);
      window.removeEventListener("pageshow", this.pageShowEvent);
      window.removeEventListener("pagehide", this.pageHideEvent);
      window.removeEventListener("popstate", this.popStateEvent);
      window.removeEventListener("hashchange", this.hashChangeEvent);
      window.removeEventListener("error", this.errorEvent);
      window.removeEventListener("unhandledrejection", this.rejectionEvent);
      chrome.storage?.onChanged?.removeListener(this.storageChanged);
      this.observer?.disconnect();
      this.observer = null;
      if (this.snapshotTimer !== void 0) clearInterval(this.snapshotTimer);
      this.snapshotTimer = void 0;
      if (this.domTimer !== void 0) clearTimeout(this.domTimer);
      this.domTimer = void 0;
    }
    installMutationObserver() {
      this.observer = new MutationObserver((mutations) => {
        this.record("dom", summarizeMutations(mutations));
        if (this.domTimer !== void 0) clearTimeout(this.domTimer);
        this.domTimer = setTimeout(() => this.captureSnapshot("dom-settled"), DOM_SETTLE_MS);
      });
      this.observer.observe(document.documentElement, {
        childList: true,
        subtree: true,
        attributes: true,
        characterData: true
      });
    }
    onUiEvent(event) {
      const target = event.target instanceof Element ? event.target : null;
      const payload = {
        event: event.type,
        target: describeElement(target)
      };
      if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement) {
        payload["input"] = {
          type: target.type || target.tagName.toLowerCase(),
          length: target.value.length,
          checked: "checked" in target ? target.checked : void 0
        };
      } else if (target instanceof HTMLSelectElement) {
        payload["input"] = { type: "select", selectedIndex: target.selectedIndex };
      }
      if (event instanceof KeyboardEvent) payload["key"] = safeKey(event.key);
      this.record("ui", payload);
    }
    onStorageChange(changes, areaName) {
      if (!this.active) return;
      const items = Object.entries(changes).filter(([key]) => key.startsWith("cfpt:")).map(([key, change]) => ({
        key: `${key.split(":").slice(0, 2).join(":")}:${hashText(key)}`,
        oldValue: summarizeUnknown(change.oldValue),
        newValue: summarizeUnknown(change.newValue)
      }));
      if (items.length > 0) this.record("storage", { area: areaName, changes: items });
    }
    onPageMessage(event) {
      if (!this.active || event.source !== window) return;
      const payload = parsePageBridgePayload(event.data, this.channel);
      if (!payload) return;
      const type = typeof payload["type"] === "string" ? payload["type"] : "page-event";
      this.record(type.startsWith("network") ? "network" : "page", payload);
      if (type === "history") this.captureSnapshot("history", true);
    }
    injectPageBridge() {
      const existing = document.getElementById(PAGE_SCRIPT_ID);
      if (existing) {
        this.postBridgeControl("start");
        return;
      }
      const script = document.createElement("script");
      script.id = PAGE_SCRIPT_ID;
      script.src = chrome.runtime.getURL("diagnostics-bridge.js");
      script.async = false;
      script.addEventListener("load", () => this.postBridgeControl("start"), { once: true });
      script.addEventListener(
        "error",
        () => this.record("page", { type: "bridge-load-error", src: "diagnostics-bridge.js" }),
        { once: true }
      );
      (document.head ?? document.documentElement).appendChild(script);
    }
    postBridgeControl(action) {
      window.postMessage({ source: CONTENT_SOURCE, action, channel: this.channel }, "*");
    }
    record(type, payload) {
      if (!this.active && !(type === "session" && payload["event"] === "stop")) return;
      if (this.records.length >= MAX_RECORDS) {
        this.records.splice(0, TRIM_BATCH);
        this.dropped += TRIM_BATCH;
      }
      this.seq += 1;
      this.records.push({
        seq: this.seq,
        time: (/* @__PURE__ */ new Date()).toISOString(),
        elapsedMs: Math.max(0, Date.now() - this.startedAtMs),
        type,
        ...payload
      });
      this.notifyStatus();
    }
    notifyStatus() {
      this.hooks.onStatus?.(this.status);
    }
    buildSummary(exportedAt) {
      const byType = {};
      const endpoints = /* @__PURE__ */ new Set();
      for (const record of this.records) {
        byType[record.type] = (byType[record.type] ?? 0) + 1;
        const url = record["url"];
        if (record.type === "network" && typeof url === "string") endpoints.add(url);
      }
      return {
        recording: this.active,
        events: this.records.length,
        dropped: this.dropped,
        byType,
        endpoints: Array.from(endpoints).slice(0, 200),
        route: redactUrl(location.href),
        durationMs: Math.max(0, Date.parse(exportedAt) - this.startedAtMs),
        finalState: buildSemanticSnapshot(this.hooks.getRunState()),
        note: "Free-form chat text, typed text, cookies, authorization material, tokens, and query values are omitted or summarized."
      };
    }
  };
  function parsePageBridgePayload(data, channel) {
    if (!data || typeof data !== "object") return null;
    const record = data;
    if (record["source"] !== BRIDGE_SOURCE2 || record["channel"] !== channel || !record["payload"] || typeof record["payload"] !== "object") {
      return null;
    }
    return record["payload"];
  }
  function buildSemanticSnapshot(run) {
    const assistant = lastAssistantMessage();
    const marker = assistant ? parseMarker(assistant.text) : null;
    return {
      route: redactUrl(location.href),
      document: {
        readyState: document.readyState,
        visibility: document.visibilityState,
        hasFocus: document.hasFocus(),
        online: navigator.onLine
      },
      selectors: selectorSnapshot(),
      transcript: {
        assistantCount: queryAll("assistantMessage").length,
        userCount: queryAll("userMessage").length,
        lastRole: lastMessageRole(),
        toolVisible: toolCallIndicatorVisible(),
        lastAssistant: assistant ? {
          key: summarizeString(assistant.key),
          text: summarizeString(assistant.text),
          marker: sanitizeMarker(marker)
        } : null
      },
      run: sanitizeRunState(run)
    };
  }
  function selectorSnapshot() {
    const ids = ["composer", "sendButton", "stopButton", "toolIndicator", "pageAlert"];
    const states = {};
    for (const id of ids) states[id] = targetState(id);
    return { health: healthCheck(), targets: states };
  }
  function targetState(id) {
    const resolution = resolve(id);
    const element = resolution?.element;
    if (!(element instanceof HTMLElement)) return { present: Boolean(element) };
    return {
      present: true,
      candidateIndex: resolution?.candidateIndex ?? 0,
      tag: element.tagName.toLowerCase(),
      disabled: element instanceof HTMLButtonElement ? element.disabled : void 0,
      ariaBusy: element.getAttribute("aria-busy"),
      ariaDisabled: element.getAttribute("aria-disabled"),
      visible: isVisible2(element)
    };
  }
  function isVisible2(element) {
    const style = getComputedStyle(element);
    return style.display !== "none" && style.visibility !== "hidden" && !element.hidden;
  }
  function sanitizeRunState(run) {
    if (!run) return null;
    return {
      conversationId: summarizeString(run.conversationId),
      projectId: run.projectId ? summarizeString(run.projectId) : null,
      phase: run.phase,
      status: run.status,
      repoMode: run.repoMode,
      repoName: summarizeString(run.repoName),
      repo: run.repo ? summarizeString(run.repo) : void 0,
      lastMarker: sanitizeMarker(run.lastMarker ?? null),
      planSummary: run.planSummary ? summarizeString(run.planSummary) : void 0,
      pauseReason: run.pauseReason ? summarizeString(run.pauseReason) : void 0,
      errorCode: run.errorCode,
      autoContinueEnabled: run.autoContinueEnabled,
      queuedUserText: run.queuedUserText ? summarizeString(run.queuedUserText) : void 0,
      autoSends: run.autoSends,
      nudges: run.nudges,
      repliesSinceContract: run.repliesSinceContract,
      finalAuditPending: run.finalAuditPending === true,
      finalAuditVerified: run.finalAuditVerified === true,
      currentItem: run.currentItem ? summarizeString(run.currentItem) : void 0,
      workSummary: run.workSummary ? summarizeString(run.workSummary) : void 0,
      workKind: run.workKind,
      lastWorkUrl: run.lastWorkUrl ? redactUrl(run.lastWorkUrl) : void 0,
      cooldownUntil: run.cooldownUntil,
      lastProcessedAssistantKey: run.lastProcessedAssistantKey ? summarizeString(run.lastProcessedAssistantKey) : void 0,
      replyBaselineAssistantKey: run.replyBaselineAssistantKey ? summarizeString(run.replyBaselineAssistantKey) : void 0,
      startedAt: run.startedAt,
      updatedAt: run.updatedAt,
      logTail: run.log.slice(-12).map((entry) => ({
        at: entry.at,
        kind: entry.kind,
        text: summarizeString(entry.text)
      }))
    };
  }
  function sanitizeMarker(marker) {
    if (!marker) return null;
    return {
      status: marker.status,
      version: marker.version,
      phase: marker.phase,
      repo: marker.repo ? summarizeString(marker.repo) : void 0,
      item: marker.item ? summarizeString(marker.item) : void 0,
      note: marker.note ? summarizeString(marker.note) : void 0,
      url: marker.url ? redactUrl(marker.url) : void 0,
      ci: marker.ci,
      checks: marker.checks ? summarizeString(marker.checks) : void 0,
      pr: marker.pr ? redactUrl(marker.pr) : void 0,
      issue: marker.issue ? redactUrl(marker.issue) : void 0,
      actions: marker.actions ? redactUrl(marker.actions) : void 0,
      branch: marker.branch ? summarizeString(marker.branch) : void 0
    };
  }
  function sanitizeControllerEvent(event) {
    const out = { kind: event.kind };
    if (event.event) {
      out["event"] = {
        type: event.event.type,
        detail: machineEventDetail(event.event)
      };
    }
    if (event.effect) {
      out["effect"] = {
        do: event.effect.do,
        kind: "kind" in event.effect ? event.effect.kind : void 0,
        ms: "ms" in event.effect ? event.effect.ms : void 0,
        text: "text" in event.effect && event.effect.text ? summarizeString(event.effect.text) : void 0
      };
    }
    if (event.detail) out["detail"] = summarizeDetail(event.detail);
    return out;
  }
  function machineEventDetail(event) {
    if ("marker" in event) {
      return {
        marker: sanitizeMarker(event.marker),
        assistantKey: event.assistantKey ? summarizeString(event.assistantKey) : void 0,
        text: summarizeString(event.text)
      };
    }
    if ("text" in event && typeof event.text === "string")
      return { text: summarizeString(event.text) };
    if ("idea" in event) {
      return {
        idea: summarizeString(event.idea),
        repoMode: "repoMode" in event ? event.repoMode : void 0,
        repoName: summarizeString(event.repoName)
      };
    }
    if ("detail" in event) return { detail: summarizeString(event.detail) };
    if ("signal" in event) return { signal: event.signal };
    if ("enabled" in event) return { enabled: event.enabled };
    if ("baselineAssistantKey" in event && event.baselineAssistantKey) {
      return { baselineAssistantKey: summarizeString(event.baselineAssistantKey) };
    }
    return {};
  }
  function summarizeDetail(detail) {
    const out = {};
    for (const [key, value] of Object.entries(detail)) {
      if (typeof value === "string" && /url|route/i.test(key)) out[key] = redactUrl(value);
      else if (typeof value === "string") out[key] = summarizeString(value);
      else if (value === null || typeof value === "number" || typeof value === "boolean")
        out[key] = value;
      else out[key] = summarizeUnknown(value);
    }
    return out;
  }
  function summarizeMutations(mutations) {
    const attributes = /* @__PURE__ */ new Set();
    const targets = [];
    let added = 0;
    let removed = 0;
    let text = 0;
    for (const mutation of mutations) {
      added += mutation.addedNodes.length;
      removed += mutation.removedNodes.length;
      if (mutation.type === "characterData") text += 1;
      if (mutation.attributeName) attributes.add(mutation.attributeName);
      if (targets.length < 12 && mutation.target instanceof Element) {
        const target = describeElement(mutation.target);
        if (target) targets.push(target);
      }
    }
    return {
      mutations: mutations.length,
      added,
      removed,
      characterData: text,
      attributes: Array.from(attributes).slice(0, 30),
      targets
    };
  }
  function describeElement(element) {
    if (!element) return null;
    return {
      tag: element.tagName.toLowerCase(),
      id: safeDomToken(element.id),
      testId: safeDomToken(element.getAttribute("data-testid") ?? ""),
      role: safeDomToken(element.getAttribute("role") ?? ""),
      type: safeDomToken(element.getAttribute("type") ?? ""),
      ariaLabel: element.getAttribute("aria-label") ? summarizeString(element.getAttribute("aria-label") ?? "") : void 0,
      classCount: element.classList.length
    };
  }
  function safeDomToken(value) {
    if (!value) return void 0;
    return value.length <= 80 && /^[\w:.-]+$/.test(value) ? value : `[hash:${hashText(value)}]`;
  }
  function safeKey(key) {
    return ["Enter", "Escape", "Tab", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(key) ? key : "[other]";
  }
  function safeTimestamp(value) {
    return value.replace(/[:.]/g, "-");
  }

  // src/content/extension-context.ts
  var INVALIDATED_CONTEXT_RE = /extension context invalidated/i;
  function isExtensionContextInvalidated(error) {
    if (error instanceof Error) return INVALIDATED_CONTEXT_RE.test(error.message);
    return typeof error === "string" && INVALIDATED_CONTEXT_RE.test(error);
  }
  function createExtensionContextGuard(onInvalidated) {
    let invalidated = false;
    const invalidate = () => {
      if (invalidated) return;
      invalidated = true;
      onInvalidated();
    };
    return {
      get invalidated() {
        return invalidated;
      },
      invalidate,
      handle(error) {
        if (!isExtensionContextInvalidated(error)) return false;
        invalidate();
        return true;
      }
    };
  }

  // src/content/navigation.ts
  var CONV_RE = /\/c\/([0-9a-f-]{20,})/i;
  var PROJECT_ROUTE_RE = /^\/g\/(g-p-[^/?#]+)(?:\/|$)/i;
  function projectIdFromUrl(href) {
    try { return PROJECT_ROUTE_RE.exec(new URL(href).pathname)?.[1] ?? null; }
    catch { return null; }
  }
  function isProjectChat(href) {
    // A new Project's /project page has a working, native composer (as confirmed
    // by the saved ChatGPT page). It is a valid chat starting point even before
    // ChatGPT allocates a /c/<conversation-id> after the first send.
    return Boolean(projectIdFromUrl(href));
  }
  var POLL_MS = 500;
  function freshConversationUrl(href) {
    const url = new URL(href);
    const project = projectIdFromUrl(href);
    if (!project) throw new Error("Cannot hand off outside a ChatGPT Project");
    return `${url.origin}/g/${encodeURIComponent(project)}`;
  }
  function conversationIdFromUrl(href) {
    return CONV_RE.exec(href)?.[1] ?? null;
  }
  function watchNavigation(onChange) {
    let last = location.href;
    const check = () => {
      if (location.href !== last) {
        last = location.href;
        onChange(last);
      }
    };
    const timer = setInterval(check, POLL_MS);
    window.addEventListener("popstate", check);
    window.addEventListener("hashchange", check);
    return () => {
      clearInterval(timer);
      window.removeEventListener("popstate", check);
      window.removeEventListener("hashchange", check);
    };
  }

  // src/content/project-walkthrough.ts
  // Highlight recorded native ChatGPT controls; never submit or create a Project for the user.
  var projectWalkthrough = {
    stage: null, target: null, ring: null, hint: null, timer: null,
    start(stage) {
      this.stage = stage;
      if (this.timer === null) this.timer = setInterval(() => this.refresh(), 700);
      this.refresh();
    },
    stop() {
      this.stage = null;
      if (this.timer !== null) clearInterval(this.timer);
      this.timer = null;
      this.ring?.remove(); this.hint?.remove();
      this.ring = null; this.hint = null; this.target = null;
    },
    visible(node) {
      if (!node || !node.isConnected || !node.getClientRects().length) return false;
      const style = getComputedStyle(node);
      return style.visibility !== "hidden" && style.display !== "none";
    },
    findButton(words, root = document) {
      const candidates = root.querySelectorAll("button, a, [role=button]");
      return Array.from(candidates).find((node) => {
        if (node.closest("#cfpt-guide-hint, #cfpt-root, #cfpt-overlay-root, #cfpt-debug-root")) return false;
        if (this.stage === "chat" && !node.closest("main, [role=main], [data-testid=project-page]")) return false;
        const value = [node.getAttribute("aria-label"), node.getAttribute("title"), node.textContent].filter(Boolean).join(" ").trim();
        return words.test(value) && this.visible(node);
      }) ?? null;
    },
    refresh() {
      if (!this.stage) return;
      const project = projectIdFromUrl(location.href);
      if (project) this.stage = "chat";
      if (this.stage === "chat" && isProjectChat(location.href) && query("composer")) { this.stop(); return; }
      const input = document.querySelector("#chatgpt-project-name");
      const dialog = this.visible(input) ? input.closest('[role="dialog"]') ?? input.closest("form") ?? document : null;
      if (!project && dialog) this.stage = input.value.trim() ? "confirm" : "name";
      if (!project && !dialog && (this.stage === "name" || this.stage === "confirm")) this.stage = "project";
      const target = this.stage === "project" ? this.findButton(/new project|create project/i)
        : this.stage === "name" ? input
        : this.stage === "confirm" ? (this.findButton(/^create$|create project/i, dialog) ?? dialog.querySelector('button[type="submit"]'))
        : this.findButton(/new chat|start chat|new conversation/i);
      if (!this.ring) {
        this.ring = document.createElement("div");
        this.ring.id = "cfpt-guide-ring";
        Object.assign(this.ring.style, { position: "fixed", pointerEvents: "none", border: "3px solid #10a37f", borderRadius: "9px", boxShadow: "0 0 0 5px #10a37f38", zIndex: "2147483646", transition: "all 150ms ease" });
        document.documentElement.appendChild(this.ring);
      }
      if (!this.hint) {
        this.hint = document.createElement("div");
        this.hint.id = "cfpt-guide-hint";
        Object.assign(this.hint.style, { position: "fixed", right: "16px", bottom: "42px", maxWidth: "310px", padding: "12px", borderRadius: "10px", font: "13px/1.4 system-ui,sans-serif", color: "#f5f5f5", background: "#202123", border: "1px solid #777", boxShadow: "0 6px 22px #0005", zIndex: "2147483647" });
        const text = document.createElement("span"); text.id = "cfpt-guide-text";
        const close = document.createElement("button"); close.textContent = "Close"; close.type = "button";
        Object.assign(close.style, { color: "#fff", background: "#444", border: "0", padding: "5px 8px", marginLeft: "8px", borderRadius: "5px", cursor: "pointer" });
        close.addEventListener("click", () => this.stop());
        this.hint.append(text, close);
        document.documentElement.appendChild(this.hint);
      }
      const hints = {
        project: "1/4 — Choose New project in ChatGPT's sidebar.",
        name: "2/4 — Enter a name for your ChatGPT Project.",
        confirm: "3/4 — Confirm Create. Your Project will retain chats and files.",
        chat: "4/4 — Optionally add Project files, then start a new chat inside this Project."
      };
      this.hint.querySelector("#cfpt-guide-text").textContent = hints[this.stage];
      this.ring.style.display = this.visible(target) ? "block" : "none";
      if (this.visible(target)) {
        const r = target.getBoundingClientRect();
        Object.assign(this.ring.style, { left: `${r.left-4}px`, top: `${r.top-4}px`, width: `${r.width+8}px`, height: `${r.height+8}px` });
      }
      this.target = target;
    }
  };

  // src/content/page-mode.ts
  var UTILITY_PATH_PREFIXES = ["/library", "/scheduled"];
  function chatGptPageMode(href) {
    let url;
    try {
      url = new URL(href, "https://chatgpt.com");
    } catch {
      return "composer";
    }
    if (url.pathname === "/plugins" || url.pathname.startsWith("/plugins/")) return "plugins";
    // Project overview routes also host the new-chat composer. Do not exclude
    // them here: activation waits for the real editable composer to hydrate.
    if (UTILITY_PATH_PREFIXES.some(
      (prefix) => url.pathname === prefix || url.pathname.startsWith(`${prefix}/`)
    )) {
      return "utility";
    }
    return "composer";
  }

  // src/content/composer.ts
  var NEVER_CANCEL = () => false;
  function normalized(text) {
    return (text ?? "").replace(/\s+/g, "");
  }
  function composerText() {
    const el = query("composer");
    return el?.textContent ?? "";
  }
  function composerIsEmpty() {
    return normalized(composerText()).length === 0;
  }
  function focusComposer(el) {
    el.focus();
    const selection = window.getSelection();
    if (selection) {
      selection.removeAllRanges();
      const range = document.createRange();
      range.selectNodeContents(el);
      range.collapse(false);
      selection.addRange(range);
    }
  }
  function clearComposer(el) {
    if (normalized(el.textContent).length === 0) return;
    focusComposer(el);
    document.execCommand("selectAll", false);
    document.execCommand("delete", false);
  }
  // Animation frames never fire in hidden tabs. A short timeout works in both
  // foreground and background (subject to Chrome's timer throttling).
  function settleComposer() {
    return new Promise((resolve2) => setTimeout(resolve2, 50));
  }
  function pasteInsert(el, text) {
    try {
      const data = new DataTransfer();
      data.setData("text/plain", text);
      const event = new ClipboardEvent("paste", {
        clipboardData: data,
        bubbles: true,
        cancelable: true
      });
      el.dispatchEvent(event);
      return true;
    } catch (err) {
      log.debug("pasteInsert unavailable", err);
      return false;
    }
  }
  function execInsert(el, text) {
    try {
      focusComposer(el);
      return document.execCommand("insertText", false, text);
    } catch (err) {
      log.debug("execInsert failed", err);
      return false;
    }
  }
  function domInsert(el, text) {
    try {
      el.textContent = "";
      for (const line of text.split("\n")) {
        const p = document.createElement("p");
        if (line === "") {
          p.appendChild(document.createElement("br"));
        } else {
          p.textContent = line;
        }
        el.appendChild(p);
      }
      el.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText" }));
      return true;
    } catch (err) {
      log.debug("domInsert failed", err);
      return false;
    }
  }
  var STRATEGIES = [
    ["paste", pasteInsert],
    ["execCommand", execInsert],
    ["dom", domInsert]
  ];
  async function insertPrompt(text, isCancelled = NEVER_CANCEL) {
    if (isCancelled()) return { ok: false, error: "insert cancelled" };
    let el;
    try {
      el = await require_("composer", 8e3);
    } catch {
      return { ok: false, error: "composer not found" };
    }
    if (isCancelled()) return { ok: false, error: "insert cancelled" };
    const want = normalized(text).length;
    for (const [name, strategy] of STRATEGIES) {
      if (isCancelled()) return { ok: false, error: "insert cancelled" };
      focusComposer(el);
      clearComposer(el);
      await settleComposer();
      if (isCancelled()) return { ok: false, error: "insert cancelled" };
      if (!strategy(el, text)) continue;
      await settleComposer();
      if (isCancelled()) return { ok: false, error: "insert cancelled" };
      const got = normalized(el.textContent).length;
      if (got >= Math.floor(want * 0.98)) {
        log.debug(`insertPrompt ok via ${name} (${got}/${want} chars)`);
        return { ok: true, strategy: name };
      }
      log.debug(`insertPrompt via ${name} incomplete (${got}/${want} chars)`);
    }
    return { ok: false, error: "no insertion strategy stuck" };
  }
  function sendButtonReady() {
    const btn = query("sendButton");
    if (!btn) return null;
    if (btn.disabled || btn.getAttribute("aria-disabled") === "true") return null;
    return btn;
  }
  function waitFor(probe, timeoutMs, pollMs = 150, isCancelled = NEVER_CANCEL) {
    return new Promise((resolve2) => {
      const started = Date.now();
      const attempt = () => {
        if (isCancelled()) {
          resolve2(null);
          return;
        }
        const value = probe();
        if (value !== null) {
          resolve2(value);
          return;
        }
        if (Date.now() - started > timeoutMs) {
          resolve2(null);
          return;
        }
        setTimeout(attempt, pollMs);
      };
      attempt();
    });
  }
  async function clickSend(isStreaming, isCancelled = NEVER_CANCEL) {
    for (let attempt = 0; attempt < 2; attempt++) {
      if (isCancelled()) return { ok: false, error: "send cancelled" };
      const btn = await waitFor(sendButtonReady, 8e3, 150, isCancelled);
      if (isCancelled()) return { ok: false, error: "send cancelled" };
      if (!btn) return { ok: false, error: "send button never became ready" };
      btn.click();
      const confirmed = await waitFor(
        () => composerIsEmpty() || isStreaming() ? true : null,
        5e3,
        150,
        isCancelled
      );
      if (isCancelled()) return { ok: false, error: "send cancelled" };
      if (confirmed) return { ok: true };
      log.warn("send click did not take; escaping popovers and retrying once");
      document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
      query("composer")?.focus();
    }
    return { ok: false, error: "send click did not take after retry" };
  }

  // src/content/page-signals.ts
  var RATE_LIMIT_RE = /you(?:'|’)?ve (?:hit|reached) (?:your|the) (?:limit|cap)|too many (?:requests|messages)|reached (?:your|the) message (?:limit|cap)|try again (?:later|after)|usage cap/i;
  var CONVERSATION_FULL_RE = /you(?:'|’)?ve reached the maximum length for this conversation|maximum conversation length|conversation is too long|start a new chat to continue/i;
  function isNativeAlert(node) {
    return !node.closest('#cfpt-root, [data-message-author-role], [hidden], [aria-hidden="true"]');
  }
  function alertTexts() {
    const alerts = queryAll("pageAlert").filter(isNativeAlert);
    const asideFallbacks = Array.from(document.querySelectorAll("aside")).filter(isNativeAlert).filter(
      (aside) => Array.from(aside.querySelectorAll("button")).some(
        (button) => /^start new chat$/i.test(button.textContent?.trim() ?? "")
      )
    );
    return [.../* @__PURE__ */ new Set([...alerts, ...asideFallbacks])].map((node) => node.innerText ?? node.textContent ?? "").filter(Boolean);
  }
  function scanPageSignals() {
    if (query("loginButton") && !query("composer")) return "logged-out";
    const alerts = alertTexts();
    for (const text of alerts) {
      if (CONVERSATION_FULL_RE.test(text)) return "conversation-full";
      if (RATE_LIMIT_RE.test(text)) return "rate-limit";
    }
    if (query("regenerateButton")) return "network-error";
    return null;
  }

  // src/content/stream-watch.ts
  var TICK_MS = 800;
  var MARKER_FAST_PATH_MS = 1200;
  var SUSPEND_GAP_MS = TICK_MS * 4;
  var StreamWatcher = class {
    constructor(callbacks, settings) {
      this.callbacks = callbacks;
      this.settings = settings;
    }
    callbacks;
    settings;
    state = "idle";
    lastMutationAt = 0;
    settleStartedAt = 0;
    streamStartedAt = 0;
    lastTickAt = 0;
    stuckReported = false;
    replyObserved = false;
    baselineElement = null;
    baselineText = "";
    timer;
    observedMessageKey = "";
    observedMessageText = "";
    start() {
      this.stop();
      this.captureAssistantChange(Date.now(), true);
      this.lastTickAt = Date.now();
      this.timer = setInterval(() => this.tick(), TICK_MS);
    }
    stop() {
      if (this.timer !== void 0) clearInterval(this.timer);
      this.timer = void 0;
      this.reset();
    }
    captureAssistantChange(now, initialize = false) {
      const message = lastAssistantMessage();
      const key = message?.key ?? "";
      const text = message?.text ?? "";
      if (initialize || key !== this.observedMessageKey || text !== this.observedMessageText) {
        this.observedMessageKey = key;
        this.observedMessageText = text;
        this.lastMutationAt = now;
      }
    }
    /** Arm before clicking Send so a missing stop button cannot strand the reply lifecycle. */
    expectReply() {
      const message = lastAssistantMessage();
      this.baselineElement = message?.el ?? null;
      this.baselineText = message?.text ?? "";
      this.state = "waiting";
      this.streamStartedAt = 0;
      this.lastMutationAt = Date.now();
      this.settleStartedAt = 0;
      this.stuckReported = false;
      this.replyObserved = false;
      this.captureAssistantChange(Date.now(), true);
    }
    /** Sending failed, so the armed reply must not consume a later unrelated assistant turn. */
    cancelExpectedReply() {
      this.reset();
    }
    isStreaming() {
      return activeStopButton() !== null;
    }
    /** Background resume must not discard a reply's already-observed quiet time. */
    recoverFromWake() {
      this.tick();
    }
    tick() {
      const now = Date.now();
      // Hidden-tab work is still monitored; cap costly transcript scans while
      // Chrome is busy decoding video in a different window. Network completion
      // and background alarm wakes remain event-driven and unthrottled.
      if (document.hidden && this.lastTickAt > 0 && now - this.lastTickAt < 2400) return;
      this.captureAssistantChange(now);
      const stopVisible = this.isStreaming();
      if (this.lastTickAt > 0 && now - this.lastTickAt > SUSPEND_GAP_MS) {
        // Hidden-tab throttling can make *every* tick exceed this gap. Do not
        // restart settling on each wake, or the reply can never be consumed.
        // Only rebase the stuck-stream watchdog while generation is visible.
        if (stopVisible && this.replyObserved) this.streamStartedAt = now;
      }
      this.lastTickAt = now;
      switch (this.state) {
        case "idle":
          this.tickIdle(now, stopVisible);
          break;
        case "waiting":
          this.tickWaiting(now, stopVisible);
          break;
        case "streaming":
          this.tickStreaming(now, stopVisible);
          break;
        case "settling":
          this.tickSettling(now, stopVisible);
          break;
      }
    }
    tickIdle(now, stopVisible) {
      if (stopVisible) this.observeReplyStart(now, true);
    }
    tickWaiting(now, stopVisible) {
      if (stopVisible || this.assistantTurnChanged()) {
        this.observeReplyStart(now, stopVisible);
      }
    }
    tickStreaming(now, stopVisible) {
      this.checkStuck(now);
      if (!stopVisible) this.enterSettling(now);
    }
    tickSettling(now, stopVisible) {
      this.checkStuck(now);
      if (stopVisible) {
        if (this.replyObserved && this.streamStartedAt === 0) this.streamStartedAt = now;
        this.state = "streaming";
        return;
      }
      const quietSince = Math.max(this.lastMutationAt, this.settleStartedAt);
      const quietFor = now - quietSince;
      const threshold = toolCallIndicatorVisible() ? this.settings.toolQuietMs : this.settings.quietMs;
      const message = lastAssistantMessage();
      // A silent or stale assistant surface is not proof that the current reply finished.
      const freshText = message?.text?.trim() && this.assistantTurnChanged();
      // An explicit non-complete turn must never trigger a next send, even
      // when a footer has appeared and the native Stop button is absent.
      if (message?.turnState && !message.complete) return;
      const markerReady = freshText && quietFor > MARKER_FAST_PATH_MS && parseMarker(message.text) !== null;
      // A genuinely completed ChatGPT turn is stronger than an absent network
      // event; preserve a short quiet period to avoid racing DOM hydration.
      const turnReady = freshText && message.complete && !toolCallIndicatorVisible() &&
        quietFor > MARKER_FAST_PATH_MS;
      if (freshText && (turnReady || markerReady || quietFor > threshold)) this.complete(message.text, markerReady || turnReady);
    }
    complete(text, markerReady) {
      log.debug(`reply complete (${markerReady ? "marker fast-path" : "quiescence"})`);
      this.reset();
      this.callbacks.onComplete(text);
    }
    assistantTurnChanged() {
      const message = lastAssistantMessage();
      if (!message) return false;
      if (!this.baselineElement) return true;
      return message.el !== this.baselineElement || message.text !== this.baselineText;
    }
    observeReplyStart(now, stopVisible) {
      if (!this.replyObserved) {
        this.replyObserved = true;
        this.streamStartedAt = now;
        this.stuckReported = false;
        this.callbacks.onStart();
      }
      if (stopVisible) {
        this.state = "streaming";
        return;
      }
      this.enterSettling(now);
    }
    enterSettling(now) {
      this.state = "settling";
      this.settleStartedAt = now;
      this.lastMutationAt = now;
    }
    recoverTiming(now, stopVisible) {
      if (this.state === "idle") return;
      // A background timer gap does not mean the last assistant text changed.
      // Keep settling timestamps intact; only rebase the watchdog when the
      // browser is visibly generating and the gap could include suspension.
      log.debug("stream watcher checked after a timer gap; retaining reply quiet time");
      if (stopVisible && this.replyObserved) {
        this.stuckReported = false;
        this.streamStartedAt = now;
        this.state = "streaming";
      }
    }
    checkStuck(now) {
      if (!this.stuckReported && this.replyObserved && this.streamStartedAt > 0 && now - this.streamStartedAt > this.settings.maxStreamMinutes * 6e4) {
        this.stuckReported = true;
        this.callbacks.onStuck();
      }
    }
    reset() {
      this.state = "idle";
      this.lastMutationAt = 0;
      this.settleStartedAt = 0;
      this.streamStartedAt = 0;
      this.lastTickAt = 0;
      this.stuckReported = false;
      this.replyObserved = false;
      this.baselineElement = null;
      this.baselineText = "";
      this.observedMessageKey = "";
      this.observedMessageText = "";
    }
  };

  // src/content/run-controller.ts
  var RUNTIME_CHECK_MS = 2e3;
  var COMPOSER_BUSY_RETRIES = 3;
  var COMPOSER_BUSY_WAIT_MS = 5e3;
  var COMPOSER_RESTORE_RETRIES = 10;
  var COMPOSER_RESTORE_WAIT_MS = 500;
  var INTERRUPTED_RECOVERY_MS = 2500;
  var RunController = class {
    state;
    settings;
    watcher;
    cooldownTimer;
    runtimeTimer;
    networkSettleTimer;
    reloadRecoveryTimer;
    networkCompletedCurrentTurn = false;
    lastIdleHasHistory = false;
    idleMarkerSignature = "";
    // Network abort/stop events are transport hints, not evidence the user cancelled.
    pendingConversationRequests = /* @__PURE__ */ new Set();
    transportRecheckTimer;
    transportUncertain = false;
    transportUncertainUntil = 0;
    transportUncertainSince = 0;
    transportRecoveryAttempted = false;
    unsubscribeChatState;
    lastSignal = null;
    observedAssistantKey;
    observedAssistantText = "";
    observedAssistantSince = 0;
    onChange;
    onShowCompletion;
    onConversationHandoff;
    onContextInvalidated;
    onDiagnosticEvent;
    withComposerAccess;
    persistQueue = Promise.resolve();
    disposed = false;
    constructor(initial, settings, hooks) {
      this.state = initial;
      this.settings = settings;
      this.onChange = hooks.onChange;
      this.onShowCompletion = hooks.onShowCompletion;
      this.onConversationHandoff = hooks.onConversationHandoff ?? (() => void 0);
      this.onContextInvalidated = hooks.onContextInvalidated ?? (() => void 0);
      this.onDiagnosticEvent = hooks.onDiagnosticEvent ?? (() => void 0);
      this.withComposerAccess = hooks.withComposerAccess ?? (async (task) => task());
      this.watcher = new StreamWatcher(
        {
          onStart: () => {
            this.onDiagnosticEvent({ kind: "watcher", detail: { event: "start" } });
            if (this.state.status === "sending" || this.state.status === "streaming") {
              this.dispatch({ type: "STREAM_STARTED" });
            }
          },
          onComplete: (text) => {
            if (this.detectMaxLength()) return;
            this.onDiagnosticEvent({
              kind: "watcher",
              detail: { event: "complete", textLength: text.length }
            });
            const latest = lastAssistantMessage();
            if (latest?.turnState && !latest.complete) return;
            const explicitDone = latest?.complete && parseMarker(text) &&
              lastMessageRole() === "assistant";
            if ((!explicitDone && this.pendingConversationRequests.size > 0) || toolCallIndicatorVisible() ||
                this.watcher.isStreaming() || !explicitDone && this.transportUncertain &&
                (Date.now() < this.transportUncertainUntil || !parseMarker(text))) {
              // A quiet DOM is not proof the fetch or tool execution ended.
              return;
            }
            if (!this.networkCompletedCurrentTurn && text.trim()) this.consumeCompletedReply(text);
            else if (!text.trim() && !this.networkCompletedCurrentTurn) {
              log.warn("Reply watcher settled without assistant text; awaiting reliable response before continuing");
            }
          },
          onStuck: () => {
            if (this.detectMaxLength()) return;
            this.onDiagnosticEvent({ kind: "watcher", detail: { event: "stuck" } });
            if (this.state.status === "streaming") {
              this.onUncertainTransport("Long-running reply; checking activity without stopping it");
            }
          }
        },
        settings
      );
      this.lastIdleHasHistory = conversationHasHistory();
      this.watcher.start();
      this.unsubscribeChatState = subscribeChatState((event) => this.onChatState(event));
      document.addEventListener("visibilitychange", this.onVisibilityResume);
      document.addEventListener("click", this.onNativeStopClick, true);
      window.addEventListener("pageshow", this.onPageShow);
      this.runtimeTimer = setInterval(() => this.checkRuntime(), RUNTIME_CHECK_MS);
      this.repairCooldown();
      this.scheduleInterruptedRecovery();
    }
    dispose() {
      this.disposed = true;
      document.removeEventListener("visibilitychange", this.onVisibilityResume);
      document.removeEventListener("click", this.onNativeStopClick, true);
      window.removeEventListener("pageshow", this.onPageShow);
      this.watcher.stop();
      this.unsubscribeChatState();
      this.clearNetworkSettleTimer();
      this.clearTransportRecheckTimer();
      this.clearReloadRecoveryTimer();
      this.clearCooldownTimer();
      if (this.runtimeTimer !== void 0) clearInterval(this.runtimeTimer);
      this.runtimeTimer = void 0;
    }
    /** A brand-new chat gets its real /c/<uuid> id after the first reply; adopt it in place. */
    adoptConversationId(conversationId) {
      this.state = { ...this.state, conversationId };
      void this.persistState(this.state);
    }
    /** Serialize storage writes and append one final snapshot before navigation/disposal. */
    async flushState() {
      await this.persistState(this.state);
    }
    persistState(state) {
      this.persistQueue = this.persistQueue.then(() => saveRun(state)).catch((err) => this.handleChromeFailure("state save failed", err));
      return this.persistQueue;
    }
    dispatch(event) {
      if (this.disposed) return;
      if ((event.type === "USER_START" || event.type === "USER_ATTACH_EXISTING" || event.type === "USER_RESUME" || event.type === "HANDOFF_READY") &&
        (!isProjectChat(location.href) || this.state.projectId && this.state.projectId !== projectIdFromUrl(location.href))) {
        this.onDiagnosticEvent({ kind: "project-guard", detail: { blocked: event.type } });
        return;
      }
      if (event.type === "USER_START" || event.type === "USER_ATTACH_EXISTING") this.state.projectId = projectIdFromUrl(location.href);
      let effectiveEvent = event;
      if (event.type === "USER_ATTACH_EXISTING") {
        const assistant = lastAssistantMessage();
        const role = lastMessageRole();
        effectiveEvent = {
          ...event,
          snapshot: {
            hasHistory: conversationHasHistory(),
            role,
            busy: this.watcher.isStreaming() || toolCallIndicatorVisible(),
            userText: lastUserMessageText(),
            marker: role === "assistant" ? parseMarker(assistant?.text ?? "") : null
          }
        };
      }
      if (event.type === "USER_RESUME" && !event.lastUserText) {
        const lastUserText = lastUserMessageText();
        if (lastUserText) effectiveEvent = { ...event, lastUserText };
      }
      const previous = this.state;
      this.onDiagnosticEvent({ kind: "machine-event", event: effectiveEvent });
      const { state, effects } = reduce(this.state, effectiveEvent, this.settings);
      if (state === this.state) return;
      this.state = state;
      this.onDiagnosticEvent({
        kind: "state-transition",
        event: effectiveEvent,
        detail: {
          fromPhase: previous.phase,
          fromStatus: previous.status,
          toPhase: state.phase,
          toStatus: state.status,
          effects: effects.map((effect) => effect.do)
        }
      });
      if (previous.status === "cooldown" && state.status !== "cooldown") {
        this.clearCooldownTimer();
      }
      void this.persistState(state);
      this.onChange(state);
      for (const effect of effects) void this.execute(effect);
    }
    /** Re-derive the machine's position from the live DOM (resume, reload, manual resume). */
    reconcile() {
      this.reconcileLiveState(Date.now());
    }
    onVisibilityResume = () => {
      if (document.visibilityState === "visible") this.recoverAfterWake();
    };
    onPageShow = () => {
      this.recoverAfterWake();
    };
    onNativeStopClick = (event) => {
      if (!event.isTrusted || !(event.target instanceof Element)) return;
      const stop = activeStopButton();
      if (!stop || !stop.contains(event.target) || !["sending", "streaming"].includes(this.state.status)) return;
      this.clearTransportRecheckTimer();
      this.pendingConversationRequests.clear();
      // A genuine manual Stop must not be auto-resumed after a timeout.
      this.dispatch({ type: "STREAM_INTERRUPTED", reason: "Stopped manually in ChatGPT" });
    };
    recoverAfterWake() {
      if (this.disposed) return;
      this.watcher.recoverFromWake();
      if (isActive(this.state) || this.state.status === "awaiting_user") {
        this.reconcileLiveState(Date.now());
        this.recoverUnansweredNativeTurn();
      }
    }
    onChatState(event) {
      if (this.disposed) return;
      this.onDiagnosticEvent({
        kind: "network-lifecycle",
        detail: {
          event: event.event,
          requestId: event.requestId ?? "",
          status: event.status ?? "",
          markerStatus: event.marker?.status ?? "",
          reason: event.reason ?? ""
        }
      });
      switch (event.event) {
        case "generation-start":
          if (event.requestId) this.pendingConversationRequests.add(event.requestId);
          this.transportUncertain = false;
          this.transportUncertainUntil = 0;
          this.transportUncertainSince = 0;
          this.transportRecoveryAttempted = false;
          this.clearTransportRecheckTimer();
          this.clearNetworkSettleTimer();
          this.clearReloadRecoveryTimer();
          this.networkCompletedCurrentTurn = false;
          if (this.state.status === "sending" || this.state.status === "streaming" || this.state.status === "cooldown" || this.state.status === "awaiting_user" || this.state.status === "paused" && this.state.lastLifecycleSignal === "generation-interrupted") {
            this.dispatch({ type: "STREAM_STARTED" });
          }
          return;
        case "generation-interrupted":
          // The page may POST stop_conversation for internal stream transitions.
          // Only a trusted user Stop click above establishes intentional cancellation.
          if (this.maybeContinueGitHubPermission()) return;
          this.onUncertainTransport("Stop request observed; verifying conversation state");
          return;
        case "generation-complete": {
          if (event.requestId) this.pendingConversationRequests.delete(event.requestId);
          this.transportUncertain = false;
          this.transportUncertainUntil = 0;
          this.transportUncertainSince = 0;
          this.transportRecoveryAttempted = false;
          this.clearTransportRecheckTimer();
          this.clearNetworkSettleTimer();
          if (this.detectMaxLength()) return;
          if (this.state.status !== "sending" && this.state.status !== "streaming") {
            // Native replies were previously dropped here. Status collection is
            // read-only and must never trigger a send or a machine transition.
            const reported = event.marker?.text ? parseMarker(event.marker.text) : null;
            if (reported && (!this.state.repo || !reported.repo ||
                reported.repo.toLowerCase() === this.state.repo.toLowerCase())) {
              this.state.lastMarker = reported;
              rememberReportedWork(this.state, reported, event.marker.text);
              if (reported.repo && !this.state.repoName) this.state.repoName = reported.repo;
              this.persistState(this.state);
              this.onChange(this.state);
            }
            return;
          }
          const markerText = event.marker?.text ?? "";
          if (!markerText.trim()) {
            this.scheduleNetworkSettleFallback(event.requestId ?? "complete");
            return;
          }
          this.networkCompletedCurrentTurn = true;
          this.dispatch({
            type: "REPLY_COMPLETE",
            marker: markerText ? parseMarker(markerText) : null,
            text: markerText,
            assistantKey: `network:${event.requestId ?? "complete"}`
          });
          return;
        }
        case "stream-status":
          if (event.status === "COMPLETE" && (this.state.status === "sending" || this.state.status === "streaming")) {
            this.scheduleNetworkSettleFallback(event.requestId ?? "status");
          }
          return;
        case "generation-aborted":
          if (event.requestId) this.pendingConversationRequests.delete(event.requestId);
          this.clearNetworkSettleTimer();
          if (this.maybeContinueGitHubPermission()) return;
          // AbortError, page stream rotation, and proxy disconnects are not a
          // user cancellation. Inspect the DOM instead of pausing/re-sending.
          this.onUncertainTransport("Response connection closed; checking for a completed reply");
          return;
      }
    }
    onUncertainTransport(message) {
      if (!["sending", "streaming"].includes(this.state.status)) return;
      if (!this.transportUncertain) {
        this.transportUncertainSince = Date.now();
        this.transportUncertainUntil = this.transportUncertainSince + Math.max(this.settings.quietMs, 12e3);
        this.onDiagnosticEvent({ kind: "transport-recovery", detail: { message } });
        this.state.lastLifecycleSignal = "transport-rechecking";
        note({ state: this.state, now: Date.now() }, "info", message);
        void this.persistState(this.state);
        this.onChange(this.state);
      }
      this.transportUncertain = true;
      // The cloned response reader can abort after ChatGPT has rendered a full
      // status marker. Evaluate that visible reply now instead of waiting for a
      // second transport event which may never arrive.
      this.reconcileLiveState(Date.now());
      this.scheduleTransportRecheck();
    }
    scheduleTransportRecheck() {
      if (this.transportRecheckTimer !== void 0 || this.disposed) return;
      this.transportRecheckTimer = setTimeout(() => {
        this.transportRecheckTimer = void 0;
        if (this.disposed || !["sending", "streaming"].includes(this.state.status)) return;
        // Still working? Keep waiting. A network event alone must never send,
        // pause, or complete a turn while the reply/tool request is active.
        this.reconcileLiveState(Date.now());
      }, Math.max(2e3, this.settings.quietMs));
    }
    clearTransportRecheckTimer() {
      if (this.transportRecheckTimer !== void 0) clearTimeout(this.transportRecheckTimer);
      this.transportRecheckTimer = void 0;
    }
    scheduleNetworkSettleFallback(requestId) {
      if (this.networkSettleTimer !== void 0) return;
      this.networkSettleTimer = setTimeout(
        () => {
          this.networkSettleTimer = void 0;
          if (this.disposed) return;
          if (this.state.status !== "sending" && this.state.status !== "streaming") return;
          if (this.detectMaxLength()) return;
          this.reconcileLiveState(Date.now());
          if (this.state.status !== "sending" && this.state.status !== "streaming") return;
          if (this.pendingConversationRequests.size > 0 || this.watcher.isStreaming() ||
              toolCallIndicatorVisible() || this.transportUncertain &&
              (Date.now() < this.transportUncertainUntil || !parseMarker(lastAssistantMessage()?.text ?? ""))) {
            this.scheduleTransportRecheck();
            return;
          }
          const assistant = lastAssistantMessage();
          if (assistant?.text?.trim() && this.isFreshAssistant(assistant)) {
            this.consumeCompletedReply(assistant.text);
            return;
          }
          this.onUncertainTransport("Waiting for ChatGPT to render the completed reply");
        },
        Math.max(this.settings.quietMs, 1500)
      );
    }
    clearNetworkSettleTimer() {
      if (this.networkSettleTimer !== void 0) clearTimeout(this.networkSettleTimer);
      this.networkSettleTimer = void 0;
    }
    scheduleInterruptedRecovery() {
      if (this.state.status !== "paused" && this.state.status !== "streaming" || this.state.lastLifecycleSignal !== "generation-interrupted") {
        return;
      }
      this.clearReloadRecoveryTimer();
      this.reloadRecoveryTimer = setTimeout(() => {
        this.reloadRecoveryTimer = void 0;
        this.recoverInterruptedState();
      }, INTERRUPTED_RECOVERY_MS);
    }
    recoverInterruptedState() {
      if (this.disposed || this.state.status !== "paused" && this.state.status !== "streaming" || this.state.lastLifecycleSignal !== "generation-interrupted" || this.watcher.isStreaming() || toolCallIndicatorVisible()) {
        return;
      }
      if (this.detectMaxLength()) return;
      const role = lastMessageRole();
      const assistant = role === "assistant" ? lastAssistantMessage() : null;
      if (assistant && this.isFreshAssistant(assistant)) {
        if (this.state.status === "paused") this.dispatch({ type: "STREAM_STARTED" });
        this.reconcileLiveState(Date.now());
        return;
      }
      this.onDiagnosticEvent({
        kind: "recovery",
        detail: { event: "interrupted-continuation" }
      });
      if (this.state.status === "paused") this.dispatch({ type: "USER_RESUME" });
      else this.dispatch({ type: "RECOVERY_CONTINUE" });
    }
    clearReloadRecoveryTimer() {
      if (this.reloadRecoveryTimer !== void 0) clearTimeout(this.reloadRecoveryTimer);
      this.reloadRecoveryTimer = void 0;
    }
    lastBackgroundRuntimeCheck = 0;
    checkRuntime() {
      if (this.disposed) return;
      const now = Date.now();
      // Status discovery scans the transcript. Run it less often while hidden;
      // the reply watcher and network events still handle completion, and
      // queued sends/cooldowns have their own timers.
      if (document.hidden && now - this.lastBackgroundRuntimeCheck < 4e3) return;
      this.lastBackgroundRuntimeCheck = now;
      const liveStatus = recentConversationStatus();
      const marker = liveStatus?.marker;
      const hasHistory = conversationHasHistory();
      const signature = marker ? [marker.raw, marker.repo, marker.item, marker.note, marker.branch,
        marker.issue, marker.pr, marker.url, marker.ci, marker.checks, marker.actions].join("|") : "";
      const repoMatches = Boolean(marker && (!this.state.repo || !marker.repo ||
        marker.repo.toLowerCase() === this.state.repo.toLowerCase()));
      const isGenerating = this.state.status === "sending" || this.state.status === "streaming" ||
        this.state.status === "inserting" || this.watcher.isStreaming();
      // During generation only preview the in-flight message; never consume it as
      // a completed reply or alter the machine's continuation state.
      if (isGenerating) {
        const preview = statusPreview(this.state);
        const previewSignature = preview ? [preview.raw, preview.ci, preview.pr, preview.actions].join("|") : "";
        if (previewSignature !== this.lastStatusPreviewSignature) {
          this.lastStatusPreviewSignature = previewSignature;
          this.onChange(this.state);
        }
      } else {
        this.lastStatusPreviewSignature = "";
        if (repoMatches && signature !== this.idleMarkerSignature) {
          this.state.lastMarker = marker;
          rememberReportedWork(this.state, marker, liveStatus.text);
          if (marker.repo && !this.state.repoName) this.state.repoName = marker.repo;
          this.persistState(this.state);
          this.onChange(this.state);
        }
      }
      if (signature !== this.idleMarkerSignature || hasHistory !== this.lastIdleHasHistory) {
        this.lastIdleHasHistory = hasHistory;
        // In-flight previews are not confirmed. Rescan and persist after settling.
        if (!isGenerating) this.idleMarkerSignature = signature;
        if (!isGenerating && this.state.status === "idle" && repoMatches && marker.repo && this.state.repo && this.state.projectId &&
            isProjectChat(location.href) && !this.state.idea.trim() &&
            marker.repo.toLowerCase() === this.state.repo.toLowerCase()) {
          // Attachment is a state-machine operation, not a side-effect of showing status.
          this.dispatch({ type: "USER_ATTACH_EXISTING", repoName: this.state.repo });
        } else if (this.state.status === "idle") this.onChange(this.state);
      }
      if (this.state.status === "idle") return;
      if (this.maybeContinueGitHubPermission()) return;
      if (this.state.status === "paused") {
        if (this.state.lastLifecycleSignal === "generation-interrupted" && !this.state.handoffStarted && scanPageSignals() === "conversation-full") {
          this.detectMaxLength();
        }
        return;
      }
      if (!isActive(this.state) && this.state.status !== "awaiting_user") return;
      this.pollSignals();
      this.reconcileLiveState(Date.now());
      this.recoverOrphanedTransportTurn();
      this.recoverUnansweredNativeTurn();
    }
    recoverOrphanedTransportTurn() {
      // A transport abort is inconclusive. Only once the page has been idle for
      // two minutes, with no pending request/tool and no assistant reply, issue
      // ONE short status sync rather than re-sending the original user request.
      if (!this.transportUncertain || this.transportRecoveryAttempted || !this.transportUncertainSince ||
          Date.now() - this.transportUncertainSince < 12e4 || this.state.status !== "streaming" ||
          this.state.attachPendingSince || this.pendingConversationRequests.size > 0 ||
          this.watcher.isStreaming() || toolCallIndicatorVisible() ||
          !["user", "assistant"].includes(lastMessageRole())) return;
      this.transportRecoveryAttempted = true;
      this.transportUncertain = false;
      this.clearTransportRecheckTimer();
      this.dispatch({ type: "TRANSPORT_RECOVERY" });
    }
    recoverUnansweredNativeTurn() {
      const since = this.state.attachPendingSince;
      // Protect ongoing native replies, tool calls, and drafts. A no-reply gap of 90s
      // triggers a STATUS CHECK, never resubmission of the original user message.
      if (!since || this.state.status !== "streaming" || Date.now() - since < 90e3 || this.pendingConversationRequests.size > 0 ||
          this.watcher.isStreaming() || toolCallIndicatorVisible() ||
          !["user", null].includes(lastMessageRole())) return;
      this.dispatch({ type: "NATIVE_REPLY_TIMEOUT" });
    }
    maybeContinueGitHubPermission() {
      const state = this.state;
      const recoverablePhase = state.phase === "planning" || state.phase === "developing" || state.phase === "plan_ready";
      const recoverableStatus = state.status === "sending" || state.status === "streaming" || state.status === "paused" && state.lastLifecycleSignal === "generation-interrupted";
      if (!recoverablePhase || !recoverableStatus) return false;
      const button = queryGuideTarget("githubPermissionContinueButton");
      if (!button || button.getAttribute("aria-disabled") === "true") return false;
      if (button instanceof HTMLButtonElement && button.disabled) return false;
      this.clearReloadRecoveryTimer();
      this.onDiagnosticEvent({
        kind: "permission-recovery",
        detail: { event: "continue-clicked" }
      });
      button.click();
      this.dispatch({ type: "PERMISSION_CONTINUED" });
      return true;
    }
    detectMaxLength() {
      if (scanPageSignals() !== "conversation-full") return false;
      if (!this.state.handoffStarted) {
        this.dispatch({ type: "PAGE_SIGNAL", signal: "conversation-full" });
      }
      return true;
    }
    pollSignals() {
      if (!isActive(this.state) && this.state.status !== "awaiting_user") return;
      const signal = scanPageSignals();
      if (!signal) {
        this.lastSignal = null;
        return;
      }
      if (signal === this.lastSignal) return;
      this.lastSignal = signal;
      this.dispatch({ type: "PAGE_SIGNAL", signal });
    }
    reconcileLiveState(now) {
      if (this.networkCompletedCurrentTurn && this.state.status === "awaiting_user") return;
      const liveAssistant = lastAssistantMessage();
      this.onDiagnosticEvent({
        kind: "reconcile",
        detail: {
          status: this.state.status,
          phase: this.state.phase,
          watcherStreaming: this.watcher.isStreaming(),
          lastRole: lastMessageRole() ?? "none",
          assistantKey: liveAssistant?.key ?? "",
          assistantLength: liveAssistant?.text.length ?? 0,
          toolVisible: toolCallIndicatorVisible()
        }
      });
      if (this.state.status === "cooldown") {
        this.repairCooldown();
        return;
      }
      const canObserveReply = this.state.status === "sending" || this.state.status === "streaming" || this.state.status === "awaiting_user";
      if (!canObserveReply) {
        this.resetObservedAssistant();
        return;
      }
      // A partially rendered native turn can contain a status footer while
      // ChatGPT is still generating. Its explicit turn state takes precedence.
      if (liveAssistant?.turnState && !liveAssistant.complete) {
        this.resetObservedAssistant();
        return;
      }
      const explicitlyComplete = liveAssistant?.complete &&
        Boolean(parseMarker(liveAssistant.text)) && lastMessageRole() === "assistant";
      if (this.watcher.isStreaming() ||
          toolCallIndicatorVisible() || !explicitlyComplete && this.pendingConversationRequests.size > 0 ||
          !explicitlyComplete && this.transportUncertain && now < this.transportUncertainUntil) {
        this.resetObservedAssistant();
        if (this.state.status === "sending" || this.state.status === "streaming") {
          this.dispatch({ type: "STREAM_STARTED" });
        }
        return;
      }
      if (lastMessageRole() !== "assistant") {
        this.resetObservedAssistant();
        return;
      }
      const message = lastAssistantMessage();
      if (!message || !this.isFreshAssistant(message)) {
        this.resetObservedAssistant();
        return;
      }
      const marker = parseMarker(message.text);
      // After a broken transport, an unfinished assistant paragraph can remain
      // motionless for minutes while the backend is still working. Do not call
      // that a completed reply without a status footer or network completion.
      if (this.transportUncertain && !marker) {
        this.resetObservedAssistant();
        return;
      }
      if (marker) {
        // An explicitly completed turn may bypass a stale cloned network reader,
        // but not an active native Stop control, tool, or repository guard.
        if (message.complete) {
          this.resetObservedAssistant();
          this.consumeCompletedReply(message.text);
          return;
        }
        // A status footer can be rendered before fetch/readable-stream completion.
        // A quiet, unchanged assistant turn is required for native attachment and
        // for aborted clone readers so a partial marker never drives another send.
        if (!this.networkCompletedCurrentTurn &&
            (this.state.lastLifecycleSignal === "native-conversation-attached" || this.transportUncertain)) {
          if (this.observedAssistantKey !== message.key || this.observedAssistantText !== message.text) {
            this.observedAssistantKey = message.key;
            this.observedAssistantText = message.text;
            this.observedAssistantSince = now;
            return;
          }
          if (now - this.observedAssistantSince < Math.max(1200, this.settings.quietMs)) return;
        }
        this.resetObservedAssistant();
        this.dispatch({
          type: "REPLY_COMPLETE",
          marker,
          text: message.text,
          assistantKey: message.key
        });
        return;
      }
      if (this.state.status === "awaiting_user") {
        this.resetObservedAssistant();
        return;
      }
      if (this.observedAssistantKey !== message.key || this.observedAssistantText !== message.text) {
        this.observedAssistantKey = message.key;
        this.observedAssistantText = message.text;
        this.observedAssistantSince = now;
        return;
      }
      const quietMs = toolCallIndicatorVisible() ? this.settings.toolQuietMs : this.settings.quietMs;
      if (now - this.observedAssistantSince >= quietMs) {
        this.resetObservedAssistant();
        this.dispatch({
          type: "REPLY_COMPLETE",
          marker: null,
          text: message.text,
          assistantKey: message.key
        });
      }
    }
    consumeCompletedReply(text) {
      // The native turn is the authority for whether this answer finished.
      // A cloned fetch reader can remain pending indefinitely after the
      // on-page assistant turn reaches "complete". Retire only these stale
      // request hints after checking the latest answer and native Stop state.
      const rendered = lastAssistantMessage();
      if (rendered?.complete && lastMessageRole() === "assistant" &&
          !this.watcher.isStreaming() && !toolCallIndicatorVisible()) {
        this.pendingConversationRequests.clear();
        this.clearNetworkSettleTimer();
      }
      this.transportUncertain = false;
      this.transportUncertainUntil = 0;
      this.transportUncertainSince = 0;
      this.clearTransportRecheckTimer();
      const live = lastAssistantMessage();
      const assistantKey = live?.text === text ? live.key : void 0;
      this.resetObservedAssistant();
      this.dispatch({
        type: "REPLY_COMPLETE",
        marker: parseMarker(text),
        text,
        ...assistantKey ? { assistantKey } : {}
      });
    }
    isFreshAssistant(message) {
      return message.key !== this.state.lastProcessedAssistantKey && message.key !== this.state.replyBaselineAssistantKey;
    }
    resetObservedAssistant() {
      this.observedAssistantKey = void 0;
      this.observedAssistantText = "";
      this.observedAssistantSince = 0;
    }
    async execute(effect) {
      this.onDiagnosticEvent({ kind: "effect", effect });
      switch (effect.do) {
        case "insertAndSend": {
          await this.insertAndSend(effect.kind, effect.text);
          break;
        }
        case "startCooldown": {
          this.scheduleCooldown(effect.ms);
          break;
        }
        case "notify": {
          if (!this.settings.notificationsEnabled) break;
          this.sendToBackground({ type: "notify", title: effect.title, message: effect.message });
          break;
        }
        case "badge": {
          this.sendToBackground({ type: "badge", text: effect.text });
          break;
        }
        case "showCompletion": {
          this.onShowCompletion();
          break;
        }
        case "handoffConversation": {
          await this.onConversationHandoff({ ...this.state });
          break;
        }
        case "reconcile": {
          this.reconcile();
          break;
        }
      }
    }
    repairCooldown() {
      if (this.state.status !== "cooldown") return;
      const remaining = cooldownRemainingMs(this.state);
      if (remaining <= 0) {
        this.clearCooldownTimer();
        this.dispatch({ type: "COOLDOWN_ELAPSED" });
        return;
      }
      if (this.cooldownTimer === void 0) this.scheduleCooldown(remaining);
    }
    scheduleCooldown(ms) {
      if (this.cooldownTimer !== void 0 || this.disposed) return;
      this.cooldownTimer = setTimeout(
        () => {
          this.cooldownTimer = void 0;
          this.dispatch({ type: "COOLDOWN_ELAPSED" });
        },
        Math.max(0, ms)
      );
    }
    clearCooldownTimer() {
      if (this.cooldownTimer !== void 0) clearTimeout(this.cooldownTimer);
      this.cooldownTimer = void 0;
    }
    buildPrompt(kind, text) {
      const repo = this.state.repo ?? this.state.repoName;
      switch (kind) {
        case "plan":
          return buildPlanPrompt({
            idea: this.state.idea,
            repo,
            templateRepo: this.settings.templateRepo
          });
        case "develop":
          return buildDevelopPrompt(this.settings, repo);
        case "continue":
          return buildContinuePrompt(this.settings, false, repo);
        case "contract_refresh":
          return buildContinuePrompt(this.settings, true, repo);
        case "nudge":
          return buildNudgePrompt(repo);
        case "context_sync":
          return buildExistingConversationPrompt(repo);
        case "final_audit":
          return buildFinalAuditPrompt(repo);
        case "handoff":
          return buildHandoffPrompt(this.state);
        case "user_text":
        case "queued_user_text":
          return buildUserReply(text ?? "", repo);
      }
    }
    async insertAndSend(kind, text) {
      if (this.disposed) return;
      await this.withComposerAccess(() => this.performInsertAndSend(kind, text));
    }
    async performInsertAndSend(kind, text) {
      const cancelled = () => this.disposed || !["inserting", "sending"].includes(this.state.status);
      if (cancelled() || this.detectMaxLength()) return;
      if (!await this.composerAvailable() || cancelled()) return;
      if (this.detectMaxLength()) return;
      if (this.watcher.isStreaming() || toolCallIndicatorVisible() ||
          this.pendingConversationRequests.size > 0 ||
          this.transportUncertain && Date.now() < this.transportUncertainUntil) {
        // A native turn may have started after the initial state snapshot.
        this.dispatch({ type: "STREAM_STARTED" });
        return;
      }
      if (!await this.composerDraftSafe(kind) || cancelled()) return;
      const inserted = await insertPrompt(this.buildPrompt(kind, text), cancelled);
      if (cancelled()) return;
      if (!inserted.ok) {
        this.dispatch({ type: "INSERT_FAIL", detail: inserted.error ?? "unknown" });
        return;
      }
      this.dispatch({ type: "INSERT_OK" });
      if (cancelled()) return;
      this.armExpectedReply();
      await this.sendInsertedPrompt();
    }
    async composerAvailable() {
      const health = await this.waitForComposerRestore();
      if (this.disposed) return false;
      if (health.missing.length === 0) return true;
      this.dispatch({
        type: "INSERT_FAIL",
        detail: `page structure changed (missing: ${health.missing.join(", ")})`
      });
      return false;
    }
    async composerDraftSafe(kind) {
      const delayed = kind !== "plan" && kind !== "develop" && kind !== "user_text";
      if (!delayed) return true;
      for (let retry = 0; retry <= COMPOSER_BUSY_RETRIES; retry += 1) {
        if (composerIsEmpty()) return true;
        if (retry === COMPOSER_BUSY_RETRIES) {
          this.dispatch({ type: "INSERT_FAIL", detail: "the composer has your draft in it" });
          return false;
        }
        await sleep(COMPOSER_BUSY_WAIT_MS);
        if (this.disposed) return false;
      }
      return false;
    }
    armExpectedReply() {
      const baselineAssistantKey = lastAssistantMessage()?.key;
      this.dispatch(
        baselineAssistantKey ? { type: "REPLY_EXPECTED", baselineAssistantKey } : { type: "REPLY_EXPECTED" }
      );
      this.watcher.expectReply();
    }
    async sendInsertedPrompt() {
      if (this.detectMaxLength()) return;
      const sent = await clickSend(
        () => this.watcher.isStreaming(),
        () => this.disposed || this.state.status !== "sending"
      );
      if (this.disposed || this.state.status !== "sending") return;
      if (this.detectMaxLength()) return;
      if (!sent.ok) {
        this.watcher.cancelExpectedReply();
        this.dispatch({ type: "SEND_FAIL", detail: sent.error ?? "unknown" });
        return;
      }
      this.dispatch({ type: "SEND_OK" });
    }
    async waitForComposerRestore() {
      let health = healthCheck();
      for (let retry = 0; retry < COMPOSER_RESTORE_RETRIES && health.missing.includes("composer"); retry += 1) {
        await sleep(COMPOSER_RESTORE_WAIT_MS);
        if (this.disposed) return health;
        health = healthCheck();
      }
      return health;
    }
    sendToBackground(message) {
      void chrome.runtime.sendMessage(message).catch((err) => this.handleChromeFailure("background message failed", err, true));
    }
    handleChromeFailure(message, error, debug = false) {
      if (isExtensionContextInvalidated(error)) {
        this.dispose();
        this.onContextInvalidated();
        return;
      }
      if (debug) log.debug(message, error);
      else log.warn(message, error);
    }
  };
  function sleep(ms) {
    return new Promise((resolve2) => setTimeout(resolve2, ms));
  }

  // src/content/ui/native-composer.ts
  function themeValue(styles, names) {
    for (const name of names) {
      for (const style of styles) {
        const value = style.getPropertyValue(name).trim();
        if (value) return value;
      }
    }
    return "";
  }
  function isTransparentColor(value) {
    const normalized2 = value.replace(/\s+/g, "").toLowerCase();
    return !normalized2 || normalized2 === "transparent" || normalized2 === "rgba(0,0,0,0)" || normalized2 === "rgb(0 0 0/0)";
  }
  function effectiveBackground(element) {
    let current = element;
    while (current) {
      const value = getComputedStyle(current).backgroundColor;
      if (!isTransparentColor(value)) return value;
      current = current.parentElement;
    }
    return "";
  }
  var NativeComposerHost = class {
    constructor(overlayHost, focusIntegratedSurface) {
      this.overlayHost = overlayHost;
      this.focusIntegratedSurface = focusIntegratedSurface;
    }
    overlayHost;
    focusIntegratedSurface;
    snapshot = null;
    automationDepth = 0;
    surface() {
      const form = this.form();
      const surface = form?.querySelector('[data-composer-body], [data-composer-surface="true"]') ?? query("composerSurface");
      return surface instanceof HTMLElement ? surface : null;
    }
    form() {
      const current = activeComposerForm();
      const form = current ?? (this.snapshot?.form?.isConnected ? this.snapshot.form : null);
      return form instanceof HTMLFormElement ? form : null;
    }
    mountOverlay() {
      const surface = this.surface();
      const slot = surface?.parentElement;
      if (surface && slot) {
        if (this.overlayHost.parentElement !== slot || this.overlayHost.previousElementSibling !== surface) {
          surface.insertAdjacentElement("afterend", this.overlayHost);
        }
        return;
      }
      if (!this.overlayHost.isConnected) this.form()?.appendChild(this.overlayHost);
    }
    activate() {
      const surface = this.surface();
      const form = this.form();
      const parent = surface?.parentElement;
      if (!surface || !form || !parent) return;
      this.mountOverlay();
      if (this.snapshot?.surface === surface) {
        this.guard(this.automationDepth === 0);
        return;
      }
      this.restore(false);
      this.moveFocusOutside(surface);
      this.snapshot = this.capture(form, surface);
      surface.style.position = "absolute";
      surface.style.inset = "0 auto auto 0";
      surface.style.width = "1px";
      surface.style.height = "1px";
      surface.style.overflow = "hidden";
      surface.style.clipPath = "inset(50%)";
      surface.style.opacity = "0";
      surface.style.pointerEvents = "none";
      surface.dataset["cfptNativeHidden"] = "true";
      form.dataset["cfptTakeover"] = "true";
      this.guard(this.automationDepth === 0);
    }
    async withAutomationAccess(task) {
      this.automationDepth += 1;
      this.guard(false);
      try {
        return await task();
      } finally {
        this.automationDepth = Math.max(0, this.automationDepth - 1);
        this.guard(this.automationDepth === 0);
        if (this.automationDepth === 0 && this.snapshot) {
          queueMicrotask(() => this.focusIntegratedSurface());
        }
      }
    }
    isGuardedPath(path) {
      return this.automationDepth === 0 && this.snapshot !== null && path.includes(this.snapshot.surface);
    }
    isGuardedTarget(target) {
      return this.automationDepth === 0 && this.snapshot !== null && target instanceof Node && this.snapshot.surface.contains(target);
    }
    restore(focusNative = true) {
      const snapshot = this.snapshot;
      if (!snapshot) return;
      snapshot.surface.style.position = snapshot.position;
      snapshot.surface.style.inset = snapshot.inset;
      snapshot.surface.style.width = snapshot.width;
      snapshot.surface.style.height = snapshot.height;
      snapshot.surface.style.overflow = snapshot.overflow;
      snapshot.surface.style.clipPath = snapshot.clipPath;
      snapshot.surface.style.opacity = snapshot.opacity;
      snapshot.surface.style.pointerEvents = snapshot.pointerEvents;
      snapshot.surface.style.visibility = snapshot.visibility;
      snapshot.surface.inert = snapshot.inert;
      this.restoreComposerAttributes(snapshot);
      this.restoreAttribute(snapshot.surface, "aria-hidden", snapshot.ariaHidden);
      delete snapshot.surface.dataset["cfptNativeHidden"];
      delete snapshot.surface.dataset["cfptNativeGuarded"];
      delete snapshot.form.dataset["cfptTakeover"];
      this.snapshot = null;
      if (!focusNative) return;
      queueMicrotask(() => {
        const composer = query("composer");
        if (composer instanceof HTMLElement) composer.focus({ preventScroll: true });
      });
    }
    syncTheme() {
      const surface = this.surface();
      if (!surface) return;
      const form = this.form();
      const submitCandidate = query("sendButton");
      const submit = submitCandidate instanceof HTMLElement ? submitCandidate : null;
      const elements = [surface, form, submit, document.body, document.documentElement].filter(
        (element) => element instanceof HTMLElement
      );
      const styles = elements.map((element) => getComputedStyle(element));
      const surfaceStyle = styles[0];
      if (!surfaceStyle) return;
      const read = (...names) => themeValue(styles, names);
      const accent = this.resolveAccent(read, submit);
      this.setThemeVar(
        "--cfpt-native-surface",
        read(
          "--composer-surface-primary",
          "--main-surface-primary",
          "--color-background-composer-surface",
          "--color-surface"
        ) || effectiveBackground(surface)
      );
      this.setThemeVar(
        "--cfpt-native-text",
        read("--text-primary", "--color-text-primary", "--color-text") || surfaceStyle.color
      );
      this.setThemeVar("--cfpt-native-radius", surfaceStyle.borderRadius);
      this.setThemeVar("--cfpt-accent", accent);
      this.setThemeVar(
        "--cfpt-focus",
        read("--app-color-border-focus", "--focus-ring", "--color-border-focus") || accent
      );
      this.setThemeVar(
        "--cfpt-field-surface",
        read(
          "--composer-surface-secondary",
          "--main-surface-secondary",
          "--color-surface-secondary",
          "--app-color-background-surface-under"
        )
      );
      this.setThemeVar(
        "--cfpt-border",
        read("--border-light", "--color-border", "--app-color-border")
      );
      this.setThemeVar(
        "--cfpt-border-strong",
        read("--border-medium", "--color-border-strong", "--app-color-border-heavy")
      );
      this.setThemeVar(
        "--cfpt-muted",
        read("--text-secondary", "--color-text-secondary", "--app-color-text-secondary")
      );
      if (surfaceStyle.colorScheme) this.overlayHost.style.colorScheme = surfaceStyle.colorScheme;
    }
    capture(form, surface) {
      const composerCandidate = query("composer");
      const composer = composerCandidate instanceof HTMLElement && surface.contains(composerCandidate) ? composerCandidate : null;
      return {
        form,
        surface,
        composer,
        composerContentEditable: composer?.getAttribute("contenteditable") ?? null,
        composerTabIndex: composer?.getAttribute("tabindex") ?? null,
        composerAriaDisabled: composer?.getAttribute("aria-disabled") ?? null,
        position: surface.style.position,
        inset: surface.style.inset,
        width: surface.style.width,
        height: surface.style.height,
        overflow: surface.style.overflow,
        clipPath: surface.style.clipPath,
        opacity: surface.style.opacity,
        pointerEvents: surface.style.pointerEvents,
        visibility: surface.style.visibility,
        inert: surface.inert === true,
        ariaHidden: surface.getAttribute("aria-hidden")
      };
    }
    guard(guarded) {
      const snapshot = this.snapshot;
      if (!snapshot) return;
      snapshot.surface.inert = guarded;
      snapshot.surface.style.visibility = guarded ? "hidden" : snapshot.visibility;
      snapshot.surface.dataset["cfptNativeGuarded"] = String(guarded);
      snapshot.surface.setAttribute("aria-hidden", "true");
      this.setComposerEditable(snapshot, !guarded);
      if (guarded && snapshot.surface.contains(document.activeElement)) {
        this.focusIntegratedSurface();
      }
    }
    setComposerEditable(snapshot, editable) {
      const composer = snapshot.composer;
      if (!composer) return;
      if (!editable) {
        composer.setAttribute("contenteditable", "false");
        composer.setAttribute("tabindex", "-1");
        composer.setAttribute("aria-disabled", "true");
        return;
      }
      this.restoreComposerAttributes(snapshot);
    }
    restoreComposerAttributes(snapshot) {
      const composer = snapshot.composer;
      if (!composer) return;
      this.restoreAttribute(composer, "contenteditable", snapshot.composerContentEditable);
      this.restoreAttribute(composer, "tabindex", snapshot.composerTabIndex);
      this.restoreAttribute(composer, "aria-disabled", snapshot.composerAriaDisabled);
    }
    restoreAttribute(element, name, value) {
      if (value === null) element.removeAttribute(name);
      else element.setAttribute(name, value);
    }
    moveFocusOutside(surface) {
      const active = document.activeElement;
      if (!(active instanceof HTMLElement) || !surface.contains(active)) return;
      this.focusIntegratedSurface();
      if (surface.contains(document.activeElement)) active.blur();
    }
    resolveAccent(read, submit) {
      return read(
        "--theme-submit-btn-bg",
        "--theme-submit-button-bg",
        "--accent-primary",
        "--accent-color",
        "--color-accent",
        "--color-text-composer-reference",
        "--app-color-border-focus",
        "--app-color-accent-blue",
        "--accent-blue"
      ) || (submit && !isTransparentColor(getComputedStyle(submit).backgroundColor) ? getComputedStyle(submit).backgroundColor : "");
    }
    setThemeVar(name, value) {
      // Avoid invalidating layout for an unchanged theme token.
      if (value) {
        if (this.overlayHost.style.getPropertyValue(name) !== value) this.overlayHost.style.setProperty(name, value);
      } else if (this.overlayHost.style.getPropertyValue(name)) this.overlayHost.style.removeProperty(name);
    }
  };

  // src/content/ui/styles.ts
  var PANEL_CSS = `
:host([data-cfpt-background="true"]) * {
  animation: none !important;
  transition: none !important;
}
:host {
  all: initial;
  color-scheme: inherit;
  font-family: inherit;
  --cfpt-surface: var(
    --cfpt-native-surface,
    var(
      --composer-surface-primary,
      var(
        --main-surface-primary,
        var(--color-background-composer-surface, var(--color-surface, Canvas))
      )
    )
  );
  --cfpt-text: var(
    --cfpt-native-text,
    var(--text-primary, var(--color-text-primary, var(--color-text, CanvasText)))
  );
  --cfpt-muted: var(
    --cfpt-native-muted,
    var(
      --text-secondary,
      var(--color-text-secondary, color-mix(in srgb, var(--cfpt-text) 62%, transparent))
    )
  );
  --cfpt-border: var(
    --cfpt-native-border,
    var(--border-light, var(--color-border, color-mix(in srgb, var(--cfpt-text) 18%, transparent)))
  );
  --cfpt-border-strong: var(
    --cfpt-native-border-strong,
    var(
      --border-medium,
      var(--color-border-strong, color-mix(in srgb, var(--cfpt-text) 28%, transparent))
    )
  );
  --cfpt-field-surface: var(
    --cfpt-native-field-surface,
    var(
      --composer-surface-secondary,
      var(
        --main-surface-secondary,
        var(
          --color-surface-secondary,
          color-mix(in srgb, var(--cfpt-surface) 88%, var(--cfpt-text) 12%)
        )
      )
    )
  );
  --cfpt-hover: var(
    --color-surface-tertiary,
    color-mix(in srgb, var(--cfpt-accent) 8%, var(--cfpt-surface))
  );
  --cfpt-accent: var(
    --theme-submit-btn-bg,
    var(
      --theme-submit-button-bg,
      var(
        --accent-primary,
        var(
          --accent-color,
          var(
            --color-accent,
            var(
              --color-text-composer-reference,
              var(
                --app-color-border-focus,
                var(--app-color-accent-blue, var(--accent-blue, #3a83f7))
              )
            )
          )
        )
      )
    )
  );
  --cfpt-focus: var(
    --cfpt-native-focus,
    var(--app-color-border-focus, var(--color-border-focus, var(--cfpt-accent)))
  );
  --cfpt-radius: var(--cfpt-native-radius, var(--composer-border-radius, 26px));
}
:host([data-cfpt-host="launcher"]) {
  position: relative;
  display: inline-flex;
  flex: 0 0 auto;
  width: 36px;
  height: 36px;
  align-items: center;
  justify-content: center;
  align-self: center;
  margin: 0;
  padding: 0;
  pointer-events: auto;
  z-index: 2147482000;
}
:host([data-cfpt-host="launcher"][data-fallback="true"]) {
  position: absolute;
  inset-inline-start: 52px;
  bottom: 8px;
}
:host([data-cfpt-host="overlay"]) {
  position: absolute;
  inset: 0;
  display: block;
  width: 100%;
  height: 100%;
  pointer-events: none;
  z-index: 20;
}
:host([data-cfpt-host="overlay"][data-expanded="true"]) {
  position: relative;
  inset: auto;
  display: block;
  width: 100%;
  height: auto;
  min-width: 0;
  pointer-events: auto;
}
* {
  box-sizing: border-box;
  font-family: inherit;
}
button, textarea, input, select { font: inherit; }
.cfpt-hidden { display: none !important; }
.cfpt-btn:disabled { opacity: .5; cursor: not-allowed; }
.cfpt-launcher {
  width: 36px;
  height: 36px;
  display: grid;
  place-items: center;
  border: 0;
  border-radius: 999px;
  padding: 0;
  margin: 0;
  background: transparent;
  color: var(--cfpt-muted);
  cursor: pointer;
  transition: background 120ms ease, color 120ms ease, transform 120ms ease, box-shadow 120ms ease;
}
.cfpt-launcher:hover { background: var(--cfpt-hover); color: var(--cfpt-text); }
.cfpt-launcher:active { transform: scale(0.95); }
.cfpt-launcher:focus-visible { outline: 2px solid var(--cfpt-accent); outline-offset: 2px; }
.cfpt-launcher-tooltip {
  position: absolute;
  left: 50%;
  bottom: calc(100% + 8px);
  z-index: 4;
  padding: 5px 8px;
  border: 1px solid color-mix(in srgb, var(--cfpt-border) 70%, transparent);
  border-radius: 8px;
  background: color-mix(in srgb, var(--cfpt-text) 94%, transparent);
  color: var(--cfpt-surface);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.18);
  font-size: 12px;
  font-weight: 500;
  line-height: 1.2;
  white-space: nowrap;
  pointer-events: none;
  opacity: 0;
  visibility: hidden;
  transform: translate(-50%, 2px);
  transition: opacity 100ms ease, transform 100ms ease, visibility 100ms ease;
}
.cfpt-launcher:hover + .cfpt-launcher-tooltip,
.cfpt-launcher:focus-visible + .cfpt-launcher-tooltip {
  opacity: 1;
  visibility: visible;
  transform: translate(-50%, 0);
}
.cfpt-airplane { width: 18px; height: 18px; display: block; fill: currentColor; }
.cfpt-launcher[data-state="run"] {
  color: var(--cfpt-accent);
  animation: cfpt-launcher-pulse 1.6s ease-in-out infinite;
}
.cfpt-launcher[data-state="attention"] { color: #d97706; }
.cfpt-launcher[data-state="error"] { color: #dc2626; }
.cfpt-launcher[data-state="done"] { color: #2563eb; }
:host([data-highlighted="true"]) .cfpt-launcher {
  color: var(--cfpt-accent);
  animation: cfpt-onboarding-pulse 1.15s ease-in-out infinite;
}
@keyframes cfpt-launcher-pulse {
  0%, 100% { box-shadow: 0 0 0 0 color-mix(in srgb, var(--cfpt-accent) 35%, transparent); }
  50% { box-shadow: 0 0 0 6px transparent; }
}
@keyframes cfpt-onboarding-pulse {
  0%, 100% {
    transform: scale(1);
    box-shadow: 0 0 0 3px color-mix(in srgb, var(--cfpt-accent) 28%, transparent);
  }
  50% {
    transform: scale(1.08);
    box-shadow: 0 0 0 8px color-mix(in srgb, var(--cfpt-accent) 8%, transparent);
  }
}
.cfpt-takeover-backdrop {
  position: relative;
  width: 100%;
  height: auto;
  pointer-events: auto;
  background: transparent;
}
.cfpt-panel {
  position: relative;
  width: 100%;
  min-width: 0;
  pointer-events: auto;
  display: flex;
  flex-direction: column;
  max-height: min(64vh, 640px);
  color: var(--cfpt-text);
  background: var(--cfpt-surface);
  border: 1px solid var(--cfpt-border-strong);
  border-radius: var(--cfpt-radius);
  box-shadow:
    0 0 0 1px color-mix(in srgb, var(--cfpt-accent) 18%, transparent),
    0 1px 2px rgba(0, 0, 0, 0.08);
  overflow: hidden;
}
.cfpt-panel-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  min-height: 46px;
  padding: 8px 10px 7px 15px;
  background: color-mix(in srgb, var(--cfpt-accent) 7%, var(--cfpt-surface));
  border-bottom: 1px solid var(--cfpt-border);
}
.cfpt-panel-head strong {
  font-size: 13px;
  letter-spacing: 0.01em;
  color: var(--cfpt-text);
}
.cfpt-panel-close {
  min-width: 72px;
  height: 32px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 7px;
  border: 1px solid color-mix(in srgb, var(--cfpt-accent) 45%, var(--cfpt-border));
  border-radius: 999px;
  padding: 0 10px;
  background: color-mix(in srgb, var(--cfpt-accent) 10%, var(--cfpt-surface));
  color: var(--cfpt-accent);
  cursor: pointer;
  font-size: 12px;
  font-weight: 650;
  line-height: 1;
}
.cfpt-panel-close .cfpt-airplane { width: 15px; height: 15px; }
.cfpt-panel-close:hover {
  background: color-mix(in srgb, var(--cfpt-accent) 16%, var(--cfpt-surface));
}
.cfpt-panel-close:focus-visible {
  outline: 2px solid var(--cfpt-focus);
  outline-offset: 2px;
}
.cfpt-body {
  flex: 1 1 auto;
  min-height: 0;
  padding: 14px 16px 16px;
  overflow-y: auto;
  font-size: 13px;
  line-height: 1.45;
}
.cfpt-body h3 { margin: 0 0 8px; color: var(--cfpt-text); font-size: 14px; }
.cfpt-warn {
  background: color-mix(in srgb, #d97706 18%, var(--cfpt-surface));
  color: var(--cfpt-text);
  border: 1px solid color-mix(in srgb, #d97706 38%, transparent);
  padding: 8px 10px;
  border-radius: 10px;
  font-size: 12px;
  margin-bottom: 10px;
}
.cfpt-message-preview {
  margin: 6px 0 0;
  white-space: pre-wrap;
  overflow-wrap: anywhere;
  color: var(--cfpt-text);
}
.cfpt-note { color: var(--cfpt-muted); font-size: 12px; margin: 8px 0; }
.cfpt-field { margin-bottom: 12px; }
.cfpt-field label {
  display: block;
  margin-bottom: 5px;
  color: color-mix(in srgb, var(--cfpt-text) 78%, var(--cfpt-muted));
  font-size: 12px;
  font-weight: 600;
}
textarea, input[type="text"] {
  width: 100%;
  background: var(--cfpt-field-surface);
  color: var(--cfpt-text);
  border: 1px solid var(--cfpt-border-strong);
  border-radius: 12px;
  padding: 10px 12px;
  font-size: 13px;
  caret-color: var(--cfpt-accent);
  resize: vertical;
  transition: border-color 120ms ease, box-shadow 120ms ease, background 120ms ease;
}
textarea:hover, input[type="text"]:hover {
  border-color: color-mix(in srgb, var(--cfpt-accent) 38%, var(--cfpt-border-strong));
}
textarea:focus, input:focus, select:focus {
  outline: none;
  border-color: var(--cfpt-focus);
  box-shadow:
    0 0 0 1px var(--cfpt-focus),
    0 0 0 4px color-mix(in srgb, var(--cfpt-accent) 14%, transparent);
}
.cfpt-radio-row { display: flex; flex-wrap: wrap; gap: 14px; margin-bottom: 9px; font-size: 13px; }
.cfpt-radio-row label { display: flex; align-items: center; gap: 5px; cursor: pointer; }
.cfpt-btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border: 1px solid var(--cfpt-border-strong);
  border-radius: 10px;
  padding: 8px 14px;
  font-size: 13px;
  font-weight: 650;
  line-height: 1.2;
  cursor: pointer;
  background: var(--cfpt-field-surface);
  color: var(--cfpt-text);
  margin-right: 8px;
  margin-top: 6px;
  text-decoration: none;
}
.cfpt-btn:hover {
  border-color: color-mix(in srgb, var(--cfpt-accent) 38%, var(--cfpt-border-strong));
  background: color-mix(in srgb, var(--cfpt-accent) 7%, var(--cfpt-field-surface));
}
.cfpt-btn:focus-visible { outline: 2px solid var(--cfpt-focus); outline-offset: 2px; }
.cfpt-btn-primary {
  background: var(--cfpt-accent);
  color: var(--color-text-on-accent, #fff);
  border-color: var(--cfpt-accent);
}
.cfpt-btn-danger {
  background: color-mix(in srgb, #dc2626 18%, var(--cfpt-surface));
  color: #dc2626;
  border-color: color-mix(in srgb, #dc2626 30%, transparent);
}
.cfpt-status-line { display: flex; align-items: center; gap: 8px; margin-bottom: 8px; }
.cfpt-spinner {
  width: 12px;
  height: 12px;
  border: 2px solid var(--cfpt-border);
  border-top-color: var(--cfpt-accent);
  border-radius: 50%;
  animation: cfpt-spin 0.9s linear infinite;
}
@keyframes cfpt-spin { to { transform: rotate(360deg); } }
/* The overlay is a sibling of ChatGPT's native composer; its full width matches that composer. */
.cfpt-compact-bar {
  display: none;
  align-items: center;
  gap: 12px;
  width: 100%;
  min-height: 72px;
  padding: 10px 12px;
  cursor: default;
  user-select: none;
}
.cfpt-compact-state {
  width: 34px;
  height: 34px;
  display: grid;
  place-items: center;
  flex: 0 0 auto;
  border-radius: 11px;
  color: var(--cfpt-accent);
  background: color-mix(in srgb, var(--cfpt-accent) 12%, transparent);
}
.cfpt-compact-state svg { width: 19px; height: 19px; }
.cfpt-compact-state[data-status="paused"],
.cfpt-compact-state[data-status="error"],
.cfpt-compact-state[data-status="awaiting_user"] {
  color: #d97706;
  background: color-mix(in srgb, #d97706 12%, transparent);
}
.cfpt-compact-state[data-status="complete"] {
  color: #059669;
  background: color-mix(in srgb, #059669 12%, transparent);
}
.cfpt-compact-state[data-status="streaming"] svg,
.cfpt-compact-state[data-status="sending"] svg,
.cfpt-compact-state[data-status="inserting"] svg { animation: cfpt-spin 1.8s linear infinite; }
.cfpt-compact-info { min-width: 0; flex: 1; display: flex; flex-direction: column; gap: 3px; }
.cfpt-compact-heading { display: flex; align-items: baseline; gap: 8px; min-width: 0; }
.cfpt-compact-copy {
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  color: var(--cfpt-text);
  font-size: 13px;
  font-weight: 650;
}
.cfpt-compact-phase { font-size: 11px; color: var(--cfpt-muted); white-space: nowrap; }
.cfpt-compact-detail, .cfpt-compact-meta {
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  color: var(--cfpt-muted);
  font-size: 11px;
  line-height: 1.25;
}
.cfpt-compact-meta { display: flex; gap: 9px; align-items: center; }
.cfpt-status-fields { display: grid; gap: 4px; margin: 9px 0; }
.cfpt-status-row { display: grid; grid-template-columns: minmax(135px, 37%) minmax(0, 1fr); gap: 8px; font-size: 12px; overflow-wrap: anywhere; }
.cfpt-status-key { font-weight: 600; color: var(--cfpt-muted); }
.cfpt-compact-work-link { color: var(--cfpt-accent); text-decoration: none; flex: 0 0 auto; }
.cfpt-compact-work-link:hover { text-decoration: underline; }
.cfpt-compact-actions { display: flex; gap: 6px; flex: 0 0 auto; }
.cfpt-compact-action, .cfpt-panel-minimize {
  width: 32px;
  height: 32px;
  display: inline-grid;
  place-items: center;
  border: 1px solid var(--cfpt-border);
  border-radius: 10px;
  background: var(--cfpt-field-surface);
  color: var(--cfpt-text);
  cursor: pointer;
  padding: 0;
}
.cfpt-compact-action svg, .cfpt-panel-minimize svg { width: 17px; height: 17px; stroke: currentColor; stroke-width: 2; stroke-linecap: round; stroke-linejoin: round; fill: none; }
.cfpt-compact-action:hover, .cfpt-panel-minimize:hover { background: var(--cfpt-hover); }
.cfpt-panel-head-actions { display: flex; align-items: center; gap: 6px; }
/* Distinct status surface: always contrasts with the native composer instead of blending in. */
.cfpt-panel.cfpt-compact {
  width: 100%; min-width: 0; margin: 0; max-height: none;
  border-radius: 16px;
  color: #f5f5f5;
  background: #111214;
  border: 1px solid #34383e;
  box-shadow: 0 2px 12px rgba(0,0,0,.24), 0 0 0 1px rgba(255,255,255,.025);
}
.cfpt-panel.cfpt-compact .cfpt-compact-copy { color: #f7f7f7; }
.cfpt-panel.cfpt-compact .cfpt-compact-phase,
.cfpt-panel.cfpt-compact .cfpt-compact-meta { color: #aab0b8; }
.cfpt-panel.cfpt-compact .cfpt-compact-detail { color: #d5d9df; }
.cfpt-panel.cfpt-compact .cfpt-compact-state { background: transparent; color: #f59e0b; }
.cfpt-panel.cfpt-compact .cfpt-compact-state[data-status="complete"] { color: #36c98f; }
.cfpt-panel.cfpt-compact .cfpt-compact-action {
  background: transparent; border-color: transparent; color: #d6dbe2;
  border-radius: 8px;
}
.cfpt-panel.cfpt-compact .cfpt-compact-action:hover,
.cfpt-panel.cfpt-compact .cfpt-compact-action:focus-visible { background: #30343b; color: #fff; }
.cfpt-panel.cfpt-compact .cfpt-compact-work-link { color: #f7a847; }
.cfpt-panel.cfpt-compact .cfpt-compact-bar { padding: 10px 15px; min-height: 74px; }
.cfpt-panel.cfpt-compact .cfpt-compact-heading { align-items: center; }
.cfpt-panel.cfpt-compact .cfpt-compact-state { width: 26px; height: 26px; border-radius: 0; }
.cfpt-panel.cfpt-compact .cfpt-compact-state svg { width: 17px; height: 17px; }
.cfpt-panel.cfpt-compact .cfpt-compact-meta { font-size: 10px; }
@media (prefers-color-scheme: light) {
  .cfpt-panel.cfpt-compact { background: #191b1e; border-color: #34383e; }
}
.cfpt-panel.cfpt-compact .cfpt-panel-head, .cfpt-panel.cfpt-compact .cfpt-body { display:none; }
.cfpt-panel.cfpt-compact .cfpt-compact-bar { display:flex; }
.cfpt-compact-action:focus-visible, .cfpt-panel-minimize:focus-visible, .cfpt-compact-work-link:focus-visible { outline:2px solid var(--cfpt-focus); outline-offset:2px; }
@media (max-width: 450px) {
  .cfpt-compact-bar { gap: 8px; padding: 9px 10px; }
  .cfpt-compact-phase { display:none; }
  .cfpt-compact-state { width: 29px; height: 29px; }
  .cfpt-compact-action { width: 30px; height: 30px; }
}
.cfpt-counters { color: var(--cfpt-muted); font-size: 12px; margin-bottom: 8px; }
.cfpt-log {
  background: color-mix(in srgb, var(--cfpt-surface) 88%, #000 12%);
  border: 1px solid var(--cfpt-border);
  border-radius: 10px;
  padding: 8px;
  font-size: 11px;
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  max-height: 170px;
  overflow-y: auto;
  white-space: pre-wrap;
  word-break: break-word;
}
.cfpt-log .warn { color: #d97706; }
.cfpt-log .error { color: #dc2626; }
.cfpt-log .marker { color: #059669; }
.cfpt-link { color: #3b82f6; text-decoration: none; }
.cfpt-link:hover { text-decoration: underline; }
.cfpt-icon-close {
  position: absolute;
  top: 7px;
  inset-inline-end: 8px;
  width: 26px;
  height: 26px;
  border: 0;
  border-radius: 999px;
  background: transparent;
  color: var(--cfpt-muted);
  cursor: pointer;
  font-size: 20px;
  line-height: 1;
}
.cfpt-icon-close:hover { background: var(--cfpt-hover); color: var(--cfpt-text); }
.cfpt-check-row { display: flex; align-items: center; gap: 7px; color: var(--cfpt-muted); cursor: pointer; }
.cfpt-check-row input { margin: 0; }
.cfpt-setup-backdrop {
  position: relative;
  width: 100%;
  height: auto;
  display: block;
  padding: 0;
  pointer-events: auto;
  background: transparent;
}
.cfpt-setup-card {
  position: relative;
  width: 100%;
  max-height: min(64vh, 640px);
  overflow-y: auto;
  padding: 18px;
  border: 1px solid var(--cfpt-border-strong);
  border-radius: var(--cfpt-radius);
  background: var(--cfpt-surface);
  color: var(--cfpt-text);
  box-shadow:
    0 0 0 1px color-mix(in srgb, var(--cfpt-accent) 18%, transparent),
    0 1px 2px rgba(0, 0, 0, 0.08);
}
.cfpt-setup-icon {
  width: 36px;
  height: 36px;
  display: grid;
  place-items: center;
  margin-bottom: 10px;
  border-radius: 11px;
  background: color-mix(in srgb, var(--cfpt-accent) 14%, var(--cfpt-surface));
  color: var(--cfpt-accent);
}
.cfpt-setup-icon svg { width: 19px; height: 19px; fill: currentColor; }
.cfpt-setup-card h2 { margin: 0 30px 8px 0; font-size: 18px; line-height: 1.25; }
.cfpt-setup-lead { margin: 0 0 12px; color: var(--cfpt-muted); font-size: 13px; line-height: 1.45; }
.cfpt-setup-steps { margin: 0; padding-left: 20px; font-size: 13px; line-height: 1.5; }
.cfpt-setup-steps li + li { margin-top: 7px; }
.cfpt-setup-steps code {
  padding: 1px 4px;
  border-radius: 5px;
  background: var(--cfpt-hover);
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-size: 11px;
  overflow-wrap: anywhere;
}
.cfpt-setup-footnote { margin: 12px 0 0; color: var(--cfpt-muted); font-size: 11px; line-height: 1.45; }
.cfpt-setup-actions { display: flex; flex-wrap: wrap; justify-content: flex-end; gap: 8px; margin-top: 14px; }
.cfpt-setup-actions .cfpt-btn { margin: 0; }
.cfpt-plan-badge {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  margin-bottom: 10px;
  padding: 4px 8px;
  border-radius: 999px;
  background: color-mix(in srgb, var(--cfpt-accent) 13%, transparent);
  color: var(--cfpt-text);
  font-size: 11px;
  font-weight: 700;
}
@media (max-width: 620px) {
  :host([data-cfpt-host="launcher"]) { width: 34px; height: 34px; }
  .cfpt-launcher { width: 34px; height: 34px; }
  .cfpt-panel { max-height: min(68vh, 620px); }
  .cfpt-body { padding: 13px 14px 15px; }
  .cfpt-btn { padding-inline: 11px; }
  .cfpt-setup-card { padding: 17px; }
}
@media (prefers-reduced-motion: reduce) {
  .cfpt-launcher,
  :host([data-highlighted="true"]) .cfpt-launcher,
  .cfpt-launcher-tooltip,
  .cfpt-spinner { animation: none; transition: none; }
}
`;

  // src/content/ui/view.ts
  var STATUS_LABEL2 = {
    idle: "Idle",
    inserting: "Writing prompt\u2026",
    sending: "Sending\u2026",
    streaming: "ChatGPT is working\u2026",
    cooldown: "Waiting to auto-continue\u2026",
    awaiting_user: "Waiting for you",
    paused: "Paused",
    error: "Paused on a problem",
    complete: "Complete"
  };
  var MARKER_LABEL = {
    CONTINUE: "Continue",
    NEEDS_INPUT: "Needs input",
    PLAN_READY: "Plan ready",
    TESTING: "Testing",
    COMPLETE: "Complete",
    ERROR: "Error"
  };
  var LIFECYCLE_LABEL = {
    "generation-start": "Generation started",
    "generation-complete": "Generation completed",
    "generation-interrupted": "Generation interrupted",
    "permission-continued": "Permission continued",
    "conversation-handoff": "Conversation handoff",
    "conversation-handoff-started": "New conversation started",
    "interruption-resumed": "Interruption resumed",
    "interruption-recovered": "Interruption recovered"
  };
  function humanizeToken(value) {
    const words = value.replace(/[_-]+/g, " ").trim().toLowerCase();
    return words ? words.charAt(0).toUpperCase() + words.slice(1) : "";
  }
  function statusLabel(status) {
    return STATUS_LABEL2[status] ?? humanizeToken(status);
  }
  function markerLabel(status) {
    return MARKER_LABEL[status] ?? humanizeToken(status);
  }
  function lifecycleLabel(signal) {
    return LIFECYCLE_LABEL[signal] ?? humanizeToken(signal);
  }
  function esc(text) {
    const div = document.createElement("div");
    div.textContent = text;
    return div.innerHTML;
  }
  function canQueueNext(state) {
    return state.phase === "planning" || state.phase === "developing";
  }
  function airplaneSvg() {
    return `
    <svg class="cfpt-airplane" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
      <path d="M12 2.5c-.8 0-1.4.6-1.4 1.4v5.3L3 13.8v2l7.6-2.4v4.2l-2.3 1.7v1.4l3.7-1.1 3.7 1.1v-1.4l-2.3-1.7v-4.2l7.6 2.4v-2l-7.6-4.6V3.9c0-.8-.6-1.4-1.4-1.4Z"></path>
    </svg>`;
  }
  function cfptIcon(name) {
    const paths = {
      pause: '<path d="M9 5v14M15 5v14"/>',
      expand: '<path d="m6 15 6-6 6 6"/>',
      minimize: '<path d="m6 9 6 6 6-6"/>',
      loading: '<path d="M12 3a9 9 0 1 0 9 9"/>',
      check: '<path d="m5 12 4 4L19 6"/>',
      alert: '<path d="M12 9v4m0 4h.01M10.2 3.9 2 18a2 2 0 0 0 1.8 3h16.4a2 2 0 0 0 1.8-3L13.8 3.9a2 2 0 0 0-3.6 0Z"/>',
      ready: '<path d="M7 3h10M7 21h10M8 3v5l4 4 4-4V3M8 21v-5l4-4 4 4v5"/>',
    };
    return `<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${paths[name] ?? paths.ready}</svg>`;
  }
  function repositorySetupHtml() {
    return `
    <section class="cfpt-setup-card" role="region" aria-labelledby="cfpt-setup-title">
      <button class="cfpt-icon-close" type="button" data-action="setup-done" aria-label="Close repository setup">\xD7</button>
      <div class="cfpt-setup-icon" aria-hidden="true">${airplaneSvg()}</div>
      <div class="cfpt-plan-badge">One project \xB7 one repository</div>
      <h2 id="cfpt-setup-title">Connect GitHub and a ChatGPT Project</h2>
      <p class="cfpt-setup-lead">The project is the workspace for files and conversations; GitHub keeps the code and CI state.</p>
      <ol class="cfpt-setup-steps">
        <li><a class="cfpt-link" href="https://github.com/new" target="_blank" rel="noreferrer noopener">Create a GitHub repository</a> with a README, default <strong>main</strong> branch, and <strong>Public</strong> visibility. Standard GitHub-hosted Actions minutes are free for public repos. You may change visibility later; private repos have usage quotas.</li>
        <li>On ChatGPT, choose <strong>New project</strong> in the left sidebar, name the project, choose an icon/color, and create it. <button class="cfpt-btn" type="button" data-action="guide-project">Highlight the New project control</button></li>
        <li>On the project page, optionally <strong>Add files / sources</strong>, then select <strong>New chat</strong> inside the Project. <button class="cfpt-btn" type="button" data-action="guide-chat">Highlight New chat</button></li>
        <li>In that project chat, open Chat FreePT, paste the GitHub <strong>owner/repo</strong>, describe your goal, and press <strong>Start planning</strong>.</li>
      </ol>
      <p class="cfpt-setup-footnote">One ChatGPT Project maps to one repository. Chat FreePT checks access and preserves the mapping during conversation handoffs. The project and files remain on ChatGPT.</p>
      <div class="cfpt-setup-actions">
        <button class="cfpt-btn cfpt-btn-primary" type="button" data-action="setup-done">Continue</button>
      </div>
    </section>`;
  }
  function launcherState(state) {
    if (state.status === "error") return "error";
    if (state.status === "awaiting_user") return "attention";
    if (state.status === "complete") return "done";
    if (state.status === "idle") return "idle";
    return "run";
  }
  function panelViewKey(state, passive) {
    return [
      state.phase,
      state.status,
      state.pauseReason ?? "",
      state.repo ?? "",
      state.lastUserText ?? "",
      state.lastMarker?.status ?? "",
      state.lastMarker?.item ?? "",
      state.lastMarker?.note ?? "",
      state.ciStatus ?? "",
      state.ciChecks ?? "",
      state.prUrl ?? "",
      state.issueUrl ?? "",
      state.actionsUrl ?? "",
      state.currentBranch ?? "",
      state.currentItem ?? "",
      state.workSummary ?? "",
      state.lastWorkUrl ?? "",
      String(state.finalAuditPending === true),
      state.lastLifecycleSignal ?? "",
      queuedMessages(state).join(""),
      String(passive),
      String(lastMessageRole() !== null)
    ].join("|");
  }
  function renderPanelShell(body) {
    return `
    <div class="cfpt-panel-head">
      <strong>Chat FreePT</strong>
      <div class="cfpt-panel-head-actions">
        <button class="cfpt-panel-close" type="button" data-action="close" aria-label="Return to the native ChatGPT composer">${airplaneSvg()}<span>Native</span></button>
        <button class="cfpt-panel-minimize" type="button" data-action="compact-collapse" aria-label="Minimize Chat FreePT" title="Minimize">${cfptIcon("minimize")}</button>
      </div>
    </div>
    <div class="cfpt-compact-bar" role="status" aria-live="polite" title="Double-click to expand">
      <span class="cfpt-compact-state" data-ref="compact-icon" aria-hidden="true">${cfptIcon("loading")}</span>
      <span class="cfpt-compact-info">
        <span class="cfpt-compact-heading">
          <span class="cfpt-compact-copy" data-ref="compact-status">Working</span>
          <span class="cfpt-compact-phase" data-ref="compact-phase"></span>
        </span>
        <span class="cfpt-compact-detail" data-ref="compact-detail"></span>
        <span class="cfpt-compact-meta">
          <span data-ref="compact-meta"></span>
          <a class="cfpt-compact-work-link cfpt-hidden" data-ref="compact-work-link" target="_blank" rel="noopener noreferrer"></a>
        </span>
      </span>
      <span class="cfpt-compact-actions">
        <button class="cfpt-compact-action" type="button" data-action="pause" data-ref="compact-pause" aria-label="Pause automation" title="Pause">${cfptIcon("pause")}</button>
        <button class="cfpt-compact-action" type="button" data-action="compact-expand" aria-label="Expand Chat FreePT details" title="Expand">${cfptIcon("expand")}</button>
      </span>
    </div>
    <div class="cfpt-body">${body}</div>
  `;
  }
  function renderPanelBody(state, passive) {
    const health = healthCheck();
    const showHealthWarning = state.status === "error" && state.errorCode === "composer-insert-failed" && health.missing.length > 0;
    const warning = showHealthWarning ? `<div class="cfpt-warn">ChatGPT's page structure changed \u2014 missing: ${esc(
      health.missing.join(", ")
    )}. Auto-run cannot operate until the extension is updated.</div>` : "";
    if (passive) {
      return warning + passiveHtml(state) + conversationContextHtml(state) + checkpointHtml(state);
    }
    return warning + automationControlsHtml(state) + statusBodyHtml(state) + conversationContextHtml(state) + checkpointHtml(state);
  }
  function updatePanelDynamic(panel2, state) {
    const preview = statusPreview(state);
    const reportedFields = statusFields(state, preview);
    const origin = panel2.querySelector('[data-ref="status-origin"]');
    if (origin) origin.textContent = preview ? "Current reply preview; not yet confirmed or independently verified." :
      (state.lastMarker ? "Read from ChatGPT conversation (not independently verified against GitHub)." :
        "Waiting for a Chat FreePT status block in this conversation.");
    for (const [key, value] of Object.entries(reportedFields)) {
      const el = panel2.querySelector(`[data-status-field="${key}"]`);
      if (!el) continue;
      if (["pr", "issue", "actions"].includes(key) && value !== "Not reported" &&
          state.repo && value.toLowerCase().startsWith(`https://github.com/${state.repo.toLowerCase()}/`)) {
        const anchor = el.querySelector("a");
        if (!anchor || anchor.href !== value) {
          const link = document.createElement("a");
          link.className = "cfpt-link";
          link.href = value;
          link.target = "_blank";
          link.rel = "noreferrer noopener";
          link.textContent = value;
          el.replaceChildren(link);
        }
      } else if (el.textContent !== value || el.querySelector("a")) el.textContent = value;
    }
    const queueEl = panel2.querySelector('[data-ref="checkpoint-queue"]');
    if (queueEl) queueEl.textContent = String(queuedMessages(state).length);
    const lifecycleEl = panel2.querySelector('[data-ref="checkpoint-lifecycle"]');
    if (lifecycleEl) lifecycleEl.textContent = state.lastLifecycleSignal ? lifecycleLabel(state.lastLifecycleSignal) : "None";
    // Draft edits are persisted on input, but must not remount a focused control.
    // Reconcile restored/external state only when the field is not being edited.
    if (state.status === "idle") {
      const active = panel2.getRootNode().activeElement;
      for (const [ref, value] of [["reponame", state.repo ?? state.repoName], ["idea", state.idea]]) {
        const field = panel2.querySelector(`[data-ref="${ref}"]`);
        if (field && field !== active && field.value !== value) field.value = value;
      }
    }
    const activity = state.finalAuditPending ? "Final verification" : ({
      idle: conversationHasHistory() ? "Ready to continue" : "Ready to plan",
      inserting: "Preparing response",
      sending: "Sending to ChatGPT",
      streaming: "ChatGPT working",
      cooldown: "Continuing shortly",
      paused: "Paused",
      error: "Needs attention",
      awaiting_user: "Awaiting input",
      complete: "Completed"
    })[state.status] ?? statusLabel(state.status);
    const compactStatus = panel2.querySelector('[data-ref="compact-status"]');
    if (compactStatus) compactStatus.textContent = activity;
    const compactPhase = panel2.querySelector('[data-ref="compact-phase"]');
    if (compactPhase) compactPhase.textContent = phaseLabel(state.phase);
    const compactDetail = panel2.querySelector('[data-ref="compact-detail"]');
    if (compactDetail) compactDetail.textContent = state.workSummary ?? state.currentItem ?? state.pauseReason ??
      (state.lastLifecycleSignal === "native-conversation-attached" ? "Reading existing conversation" : "No active task reported");
    const compactMeta = panel2.querySelector('[data-ref="compact-meta"]');
    if (compactMeta) {
      const parts = [];
      const item = state.lastMarker?.item ?? state.currentItem;
      if (item) parts.push(`Item ${item}`);
      const current = preview ?? state.lastMarker;
      if (current?.status) parts.push(`${markerLabel(current.status)}${preview ? " …" : ""}`);
      if (preview?.ci || state.ciStatus) parts.push(`CI ${ciLabel(preview?.ci ?? state.ciStatus)}`);
      const pr = reportedFields.pr;
      if (pr !== "Not reported") parts.push(`PR #${pr.split("/").pop()}`);
      const depth = queuedMessages(state).length;
      if (depth) parts.push(`Queue ${depth}`);
      if (state.autoSends) parts.push(`${state.autoSends} continues`);
      if (!parts.length) parts.push(state.repo || "Ready");
      compactMeta.textContent = parts.join(" · ");
    }
    const compactIcon = panel2.querySelector('[data-ref="compact-icon"]');
    if (compactIcon) {
      compactIcon.dataset.status = state.status;
      const icon = state.status === "complete" ? "check" :
        ["paused", "error", "awaiting_user"].includes(state.status) ? "alert" :
        ["inserting", "sending", "streaming"].includes(state.status) ? "loading" : "ready";
      if (compactIcon.dataset.icon !== icon) {
        compactIcon.innerHTML = cfptIcon(icon);
        compactIcon.dataset.icon = icon;
      }
    }
    const quickPause = panel2.querySelector('[data-ref="compact-pause"]');
    if (quickPause) quickPause.classList.toggle("cfpt-hidden", !["inserting", "sending", "streaming", "cooldown"].includes(state.status));
    const workLink = panel2.querySelector('[data-ref="compact-work-link"]');
    if (workLink) {
      const url = state.prUrl ?? state.actionsUrl ?? state.lastWorkUrl ?? "";
      const valid = state.repo && url.toLowerCase().startsWith(`https://github.com/${state.repo.toLowerCase()}/`);
      workLink.classList.toggle("cfpt-hidden", !valid);
      if (valid) {
        workLink.href = url;
        workLink.textContent = `${state.prUrl ? "PR" : state.actionsUrl ? "Actions" : state.workKind ?? "GitHub"} ↗`;
      } else {
        workLink.removeAttribute("href");
        workLink.textContent = "";
      }
    }
    const counters = panel2.querySelector('[data-ref="counters"]');
    if (counters) {
      const bits = [`auto-continues: ${state.autoSends}`];
      const queueDepth = queuedMessages(state).length;
      if (queueDepth) bits.push(`queue: ${queueDepth}`);
      if (state.lastMarker?.item) bits.push(`item ${state.lastMarker.item}`);
      if (state.repo) bits.push(state.repo);
      if (state.projectId) bits.push("ChatGPT Project");
      counters.textContent = bits.join(" \xB7 ");
    }
    const logEl = panel2.querySelector('[data-ref="log"]');
    if (logEl) {
      logEl.innerHTML = state.log.slice(-8).map((entry) => {
        const time = new Date(entry.at).toLocaleTimeString();
        return `<div class="${esc(entry.kind)}">${esc(time)} ${esc(entry.text)}</div>`;
      }).join("");
      logEl.scrollTop = logEl.scrollHeight;
    }
    const statusLine = panel2.querySelector('[data-ref="statusline"]');
    if (statusLine) statusLine.textContent = statusLabel(state.status);
  }
  function statusBodyHtml(state) {
    switch (state.status) {
      case "idle":
        return ideaFormHtml(state);
      case "inserting":
      case "sending":
      case "streaming":
      case "cooldown":
        return runningHtml(state);
      case "awaiting_user":
        if (state.phase === "testing") return testingHtml(state);
        return state.phase === "plan_ready" ? planReadyHtml(state) : needsInputHtml(state);
      case "paused":
      case "error":
        return pausedHtml(state);
      case "complete":
        return completeHtml(state);
      default:
        return "";
    }
  }
  function automationControlsHtml(state) {
    const queue = queuedMessages(state);
    const queueControls = canQueueNext(state) || queue.length > 0 ? queueControlsHtml(queue, canQueueNext(state)) : "";
    return `
    <div class="cfpt-field">
      <strong>Continuous mode</strong>
      <p class="cfpt-note">Chat FreePT keeps the project moving automatically. It waits only when ChatGPT needs you, reaches testing, or finishes.</p>
      ${queueControls}
    </div>
  `;
  }
  function ciLabel(value) {
    return ({ NOT_RUN: "Not run", QUEUED: "Queued", RUNNING: "Running", PASSED: "Passed",
      FAILED: "Failed", CANCELLED: "Cancelled", UNKNOWN: "Unknown" })[value] ?? "Not reported";
  }
  function statusPreview(state) {
    if (!["streaming", "sending", "inserting"].includes(state.status) && !activeStopButton()) return null;
    const assistant = recentConversationStatus();
    if (!assistant || assistant.key === state.lastProcessedAssistantKey || assistant.key === state.replyBaselineAssistantKey) return null;
    const marker = assistant.marker;
    return marker && (!marker.repo || !state.repo || marker.repo.toLowerCase() === state.repo.toLowerCase()) ? marker : null;
  }
  function statusFields(state, preview = null) {
    const marker = preview ?? state.lastMarker;
    const isRepoUrl = (url) => typeof url === "string" && state.repo &&
      url.toLowerCase().startsWith(`https://github.com/${state.repo.toLowerCase()}/`);
    return {
      status: marker?.status ? `${markerLabel(marker.status)}${preview ? " (in progress)" : ""}` : "Not reported",
      version: String(marker?.version ?? "Not reported"),
      phase: marker?.phase ?? phaseLabel(state.phase),
      repo: state.repo ?? "Not set",
      item: marker?.item ?? state.currentItem ?? "Not reported",
      note: marker?.note ?? state.workSummary ?? "Not reported",
      branch: marker?.branch ?? state.currentBranch ?? "Not reported",
      issue: isRepoUrl(preview?.issue) ? preview.issue : state.issueUrl ?? "Not reported",
      pr: isRepoUrl(preview?.pr) ? preview.pr : state.prUrl ?? "Not reported",
      ci: ciLabel(preview?.ci ?? state.ciStatus),
      checks: preview?.checks ?? state.ciChecks ?? "Not reported",
      actions: isRepoUrl(preview?.actions) ? preview.actions : state.actionsUrl ?? "Not reported",
      updated: state.statusUpdatedAt ? new Date(state.statusUpdatedAt).toLocaleTimeString() : "Not reported"
    };
  }
  function checkpointHtml(state) {
    if (!state.repo) return "";
    const fields = statusFields(state);
    const lines = [
      ["CHATFREEPT_STATUS", "status"], ["V", "version"], ["PHASE", "phase"],
      ["REPO", "repo"], ["ITEM", "item"], ["NOTE", "note"],
      ["BRANCH", "branch"], ["ISSUE", "issue"], ["PR", "pr"],
      ["CI", "ci"], ["CHECKS", "checks"], ["ACTIONS", "actions"]
    ];
    return `<div class="cfpt-field" data-ref="checkpoint">
      <strong>Live Chat FreePT checkpoint</strong>
      <p class="cfpt-note" data-ref="status-origin">Latest ChatGPT-reported status (not independently verified against GitHub).</p>
      <div class="cfpt-status-fields">${lines.map(([label, key]) =>
        `<div class="cfpt-status-row"><span class="cfpt-status-key">${label}:</span><span data-status-field="${key}">${esc(fields[key])}</span></div>`
      ).join("")}</div>
      <p class="cfpt-note">Reported at <span data-status-field="updated">${esc(fields.updated)}</span> · Queue: <span data-ref="checkpoint-queue">${queuedMessages(state).length}</span> · Last lifecycle: <span data-ref="checkpoint-lifecycle">${esc(state.lastLifecycleSignal ? lifecycleLabel(state.lastLifecycleSignal) : "None")}</span></p>
      <p class="cfpt-note">CI=Passed is a report, not an independent release gate. Missing checks are never green.</p>
    </div>`;
  }
  function queueControlsHtml(queue, allowAdd) {
    const items = queue.map(
      (message, index) => `
        <div class="cfpt-field" data-ref="queue-item" data-index="${index}">
          <p class="cfpt-note"><strong>${index + 1}.</strong> ${esc(message)}</p>
          <button class="cfpt-btn" type="button" data-action="queue-up" data-index="${index}" ${index === 0 ? "disabled" : ""}>Move up</button>
          <button class="cfpt-btn" type="button" data-action="queue-down" data-index="${index}" ${index === queue.length - 1 ? "disabled" : ""}>Move down</button>
          <button class="cfpt-btn" type="button" data-action="queue-remove" data-index="${index}">Remove</button>
        </div>`
    ).join("");
    return `
    <div class="cfpt-field">
      <strong>Message queue \xB7 ${queue.length}</strong>
      <p class="cfpt-note">Queued messages run FIFO before the next automatic continuation.</p>
      ${items}
      ${allowAdd ? '<button class="cfpt-btn" type="button" data-action="showqueue">Add queued message</button>' : ""}
      ${queue.length > 0 ? '<button class="cfpt-btn" type="button" data-action="clearqueue">Clear all</button>' : ""}
      <div class="cfpt-field cfpt-hidden" data-ref="queue-editor">
        <label>Queued user message</label>
        <textarea data-ref="queue-next" rows="3" placeholder="Send this at the next safe turn boundary\u2026"></textarea>
        <button class="cfpt-btn cfpt-btn-primary" type="button" data-action="savequeue">Add to queue</button>
        <button class="cfpt-btn" type="button" data-action="hidequeue">Cancel</button>
      </div>
    </div>`;
  }
  function conversationContextHtml(state) {
    const lastUser = state.lastUserText?.trim();
    if (!lastUser) return "";
    return `
    <div class="cfpt-field" data-ref="conversation-context">
      <strong>Last user message</strong>
      <p class="cfpt-message-preview">${esc(lastUser)}</p>
    </div>
  `;
  }
  function passiveHtml(state) {
    return `
    <h3>Active in another tab</h3>
    <p class="cfpt-note">Another ChatGPT tab currently owns this conversation. This tab is read-only and will take over automatically if the other tab closes or stops responding.</p>
    <p class="cfpt-note">Current state: ${esc(phaseLabel(state.phase))} \xB7 ${esc(
      statusLabel(state.status)
    )}</p>
  `;
  }
  function ideaFormHtml(state) {
    const inProject = isProjectChat(location.href);
    const existingConversation = conversationHasHistory();
    const projectNotice = inProject
      ? `<p class="cfpt-note">ChatGPT Project connected. Repository binding is retained across chats here.</p>`
      : `<div class="cfpt-warn">A ChatGPT Project is required to start automation. Create one with the guided setup, then open a new chat inside it.</div>`;
    const repoField = state.repo ? `<div class="cfpt-field">
         <label>Project repository</label>
         <input type="text" data-ref="reponame" value="${esc(state.repo)}" readonly />
         <p class="cfpt-note">Chat FreePT keeps this repository with the project while it runs.</p>
         <p class="cfpt-note" data-ref="repo-error" role="alert" aria-live="polite"></p>
       </div>` : `<div class="cfpt-field">
         <label>GitHub repository</label>
         <input type="text" data-ref="reponame" value="${esc(state.repoName)}" placeholder="owner/repo or https://github.com/owner/repo" />
         <p class="cfpt-note">Need a new one? <a class="cfpt-link" href="https://github.com/new" target="_blank" rel="noreferrer noopener">Create a public repository with a README and the default main branch</a>, then paste its owner/name or URL here.</p>
         <p class="cfpt-note" data-ref="repo-error" role="alert" aria-live="polite"></p>
       </div>`;
    if (existingConversation) {
      return `
        <h3>Continue this conversation</h3>
        ${projectNotice}
        ${repoField}
        <p class="cfpt-note">Chat FreePT will attach to this conversation as it is, read the existing work and GitHub checkpoint, and continue without starting a new plan. It waits for any reply already in progress.</p>
        <p class="cfpt-note" data-ref="project-error" role="alert" aria-live="polite"></p>
        <button class="cfpt-btn cfpt-btn-primary" type="button" data-action="attach">Continue existing conversation</button>
        <button class="cfpt-btn" type="button" data-action="setup-open">Guided setup</button>
        <p class="cfpt-note">To start an unrelated task, open a new chat in this Project.</p>
      `;
    }
    return `
      <h3>What should ChatGPT build for you?</h3>
      ${projectNotice}
      ${repoField}
      <div class="cfpt-field">
        <textarea data-ref="idea" rows="6" placeholder="Describe the project you want built…">${esc(state.idea)}</textarea>
      </div>
      <p class="cfpt-note" data-ref="idea-error" role="alert" aria-live="polite"></p>
      <p class="cfpt-note" data-ref="project-error" role="alert" aria-live="polite"></p>
      <p class="cfpt-note">GitHub remains the durable work state; ChatGPT retains the conversation history.</p>
      <button class="cfpt-btn" type="button" data-action="setup-open">Guided setup</button>
      <button class="cfpt-btn cfpt-btn-primary" type="button" data-action="start">Start planning</button>
    `;
  }
  function runningHtml(state) {
    const sendNow = state.status === "cooldown" ? '<button class="cfpt-btn" data-action="sendnow">Send now</button>' : "";
    return `
    <div class="cfpt-status-line"><span class="cfpt-spinner"></span>
      <strong data-ref="statusline">${esc(statusLabel(state.status))}</strong>
    </div>
    <div class="cfpt-counters" data-ref="counters"></div>
    <div class="cfpt-log" data-ref="log"></div>
    ${sendNow}
    <button class="cfpt-btn" data-action="pause">Pause</button>
    <button class="cfpt-btn cfpt-btn-danger" data-action="stop">Stop</button>
  `;
  }
  function planReadyHtml(state) {
    return `
    <h3>Master plan ready</h3>
    <p class="cfpt-note">${esc(state.planSummary ?? "The recorded plan is ready.")}</p>
    ${repoLine(state)}
    <p class="cfpt-note">Development starts automatically.</p>
    <button class="cfpt-btn cfpt-btn-danger" data-action="stop">Stop</button>
  `;
  }
  function needsInputHtml(state) {
    return `
    <h3>ChatGPT needs your input</h3>
    <p class="cfpt-note">${esc(state.pauseReason ?? "See the conversation for the question.")}</p>
    <div class="cfpt-field">
      <textarea data-ref="reply" rows="4" placeholder="Type your answer\u2026"></textarea>
    </div>
    <button class="cfpt-btn cfpt-btn-primary" data-action="reply">Send reply</button>
    <button class="cfpt-btn" data-action="resume">I answered in the chat \u2014 resume</button>
    <button class="cfpt-btn cfpt-btn-danger" data-action="stop">Stop</button>
  `;
  }
  function testingHtml(state) {
    return `
    <h3>Ready for testing</h3>
    <p class="cfpt-note">${esc(state.pauseReason ?? "The project is ready for your validation.")}</p>
    ${repoLine(state)}
    <div class="cfpt-field">
      <textarea data-ref="reply" rows="4" placeholder="Add test results or requested changes\u2026"></textarea>
    </div>
    <button class="cfpt-btn cfpt-btn-primary" data-action="reply">Send test result</button>
    <button class="cfpt-btn" data-action="resume">I responded in the chat \u2014 resume</button>
    <button class="cfpt-btn cfpt-btn-danger" data-action="stop">Stop</button>
  `;
  }
  function pausedHtml(state) {
    const handoff = state.errorCode === "conversation-full" ? '<button class="cfpt-btn" data-action="copyhandoff">Copy handoff prompt for a new chat</button>' : "";
    return `
    <h3>${state.status === "error" ? "Paused on a problem" : "Paused"}</h3>
    <p class="cfpt-note">${esc(state.pauseReason ?? "")}</p>
    <div class="cfpt-log" data-ref="log"></div>
    ${handoff}
    <button class="cfpt-btn cfpt-btn-primary" data-action="resume">Resume</button>
    <button class="cfpt-btn cfpt-btn-danger" data-action="stop">Stop</button>
  `;
  }
  function completeHtml(state) {
    return `
    <h3>Development complete</h3>
    ${repoLine(state)}
    <p class="cfpt-note">ChatGPT reports the task is done \u2014 verify it at the repository.</p>
    <button class="cfpt-btn cfpt-btn-primary" data-action="newproject">Another task in this Project</button>
    <button class="cfpt-btn" data-action="guide-project">Create a separate ChatGPT Project</button>
  `;
  }
  function phaseLabel(phase) {
    switch (phase) {
      case "idle":
        return "Ready";
      case "planning":
        return "Planning";
      case "plan_ready":
        return "Plan ready";
      case "developing":
        return "Developing";
      case "testing":
        return "Testing";
      case "complete":
        return "Complete";
      case "stopped":
        return "Stopped";
      default:
        return humanizeToken(phase);
    }
  }
  function repoLine(state) {
    if (!state.repo) return "";
    return `<p class="cfpt-note">Repo: <a class="cfpt-link" href="https://github.com/${esc(
      state.repo
    )}" target="_blank" rel="noreferrer noopener">${esc(state.repo)}</a></p>`;
  }

  // src/content/ui/panel.ts
  var FREEPT_INPUT_EVENTS = [
    "keydown",
    "keyup",
    "beforeinput",
    "input",
    "paste",
    "compositionstart",
    "compositionupdate",
    "compositionend"
  ];
  var ONBOARDING_KEY = "cfpt:onboarding:v1";
  var DEFAULT_ONBOARDING = {
    setupShown: false
  };
  function normalizeOnboarding(value) {
    if (!value || typeof value !== "object") return { ...DEFAULT_ONBOARDING };
    const candidate = value;
    return { setupShown: candidate.setupShown === true };
  }
  var Panel = class {
    constructor(hooks) {
      this.hooks = hooks;
      const launcherParts = this.createLauncher();
      this.host = launcherParts.host;
      this.launcherShadow = launcherParts.shadow;
      this.launcher = launcherParts.button;
      const overlay = this.createOverlay();
      this.overlayHost = overlay.host;
      this.shadow = overlay.shadow;
      this.takeoverBackdropEl = overlay.backdrop;
      this.panelEl = overlay.panel;
      this.setupBackdropEl = overlay.setup;
      this.nativeComposer = new NativeComposerHost(
        this.overlayHost,
        () => this.focusIntegratedSurface()
      );
      this.bindEvents();
      // React streams many DOM mutations per reply. Do not remeasure or
      // remount the composer for unrelated transcript changes. The health
      // timer below detects replacements of a still-connected composer.
      this.mountObserver = new MutationObserver(() => {
        if (!this.disposed && (!this.host.isConnected || !this.overlayHost.isConnected)) this.scheduleMount();
      });
      this.mountObserver.observe(document.documentElement, { childList: true, subtree: true });
      // Some SPA navigations replace the entire React composer without another
      // mutation once hydration settles. Cheap health check: remount only when
      // this launcher is no longer in the active composer.
      this.mountHealthTimer = setInterval(() => {
        if (this.disposed) return;
        // A hidden page needs no visual launcher placement until visible;
        // background auto-sends do not rely on the airplane's DOM location.
        if (document.hidden && this.host.isConnected && this.overlayHost.isConnected) return;
        const form = activeComposerForm();
        if (form && (!form.contains(this.host) || !form.contains(this.overlayHost))) this.scheduleMount();
      }, 1500);
      this.themeObserver = new MutationObserver(() => {
        if (!document.hidden) this.nativeComposer.syncTheme();
      });
      const themeOptions = {
        attributes: true,
        attributeFilter: ["class", "style", "data-theme", "data-color-scheme"]
      };
      this.themeObserver.observe(document.documentElement, themeOptions);
      if (document.body) this.themeObserver.observe(document.body, themeOptions);
      document.addEventListener("visibilitychange", this.syncBackgroundAppearance);
      this.syncBackgroundAppearance();
      this.mount();
      void this.initOnboarding();
    }
    hooks;
    host;
    launcherShadow;
    launcher;
    overlayHost;
    shadow;
    takeoverBackdropEl;
    panelEl;
    setupBackdropEl;
    nativeComposer;
    mountObserver;
    themeObserver;
    mountHealthTimer;
    lastViewKey = "";
    compactExpanded = false;
    compactForced = false;
    lastPanelStatus = "";
    runMiniDismissed = false;
    stopArmed = false;
    mountQueued = false;
    disposed = false;
    lastMountedForm = null;
    syncBackgroundAppearance = () => {
      const hidden = String(document.hidden);
      this.host.dataset["cfptBackground"] = hidden;
      this.overlayHost.dataset["cfptBackground"] = hidden;
      // Recalculate appearance once on foreground return, not on each streamed token.
      if (!document.hidden && this.host.isConnected) this.nativeComposer.syncTheme();
    };
    onboarding = { ...DEFAULT_ONBOARDING };
    lastIntegratedField = null;
    withNativeComposerAccess(task) {
      return this.nativeComposer.withAutomationAccess(task);
    }
    toggle(force) {
      const show = force ?? this.takeoverBackdropEl.classList.contains("cfpt-hidden");
      this.runMiniDismissed = !show;
      this.takeoverBackdropEl.classList.toggle("cfpt-hidden", !show);
      this.panelEl.classList.toggle("cfpt-hidden", !show);
      this.overlayHost.dataset["expanded"] = String(show);
      this.host.dataset["expanded"] = String(show);
      this.launcher.setAttribute("aria-expanded", String(show));
      this.launcher.setAttribute("aria-label", show ? "Close Chat FreePT" : "Open Chat FreePT");
      if (show) {
        this.mount();
        this.nativeComposer.activate();
        queueMicrotask(() => this.focusIntegratedSurface());
      } else {
        this.setupBackdropEl.classList.add("cfpt-hidden");
        this.nativeComposer.restore();
      }
    }
    render(state, passive = false) {
      const visualState = passive ? "attention" : launcherState(state);
      this.host.dataset["state"] = visualState;
      this.host.dataset["status"] = state.status;
      this.host.dataset["phase"] = state.phase;
      this.launcher.dataset["state"] = visualState;
      const viewKey = panelViewKey(state, passive);
      if (viewKey !== this.lastViewKey) {
        const active = this.shadow.activeElement;
        const focusRef = active?.dataset?.["ref"];
        const drafts = new Map();
        for (const field of this.panelEl.querySelectorAll("input[data-ref], textarea[data-ref]")) {
          drafts.set(field.dataset.ref, field.value);
        }
        const cursor = focusRef && (active instanceof HTMLInputElement || active instanceof HTMLTextAreaElement) ? {
          start: active.selectionStart, end: active.selectionEnd, direction: active.selectionDirection
        } : null;
        const queueOpen = !this.panelEl.querySelector('[data-ref="queue-editor"]')?.classList.contains("cfpt-hidden");
        this.lastViewKey = viewKey;
        this.stopArmed = false;
        this.panelEl.innerHTML = renderPanelShell(renderPanelBody(state, passive));
        for (const [ref, value] of drafts) {
          // Keep an actively edited draft mounted through state redraws even before storage flush.
          if ((ref === "reponame" || ref === "idea") && ref !== focusRef) continue;
          const nextField = this.panelEl.querySelector(`[data-ref="${ref}"]`);
          if (nextField && !nextField.readOnly) nextField.value = value;
        }
        if (queueOpen) this.panelEl.querySelector('[data-ref="queue-editor"]')?.classList.remove("cfpt-hidden");
        if (focusRef) {
          const replacement = this.panelEl.querySelector(`[data-ref="${focusRef}"]`);
          if (replacement && !replacement.disabled) {
            replacement.focus({ preventScroll: true });
            if (cursor && replacement.setSelectionRange) replacement.setSelectionRange(cursor.start, cursor.end, cursor.direction);
            this.lastIntegratedField = replacement;
          }
        }
      }
      const running = !passive && ["inserting", "sending", "streaming", "cooldown"].includes(state.status);
      if (!running && state.status !== this.lastPanelStatus) {
        // Surface a new error, question, or completion instead of silently hiding it.
        this.compactExpanded = false;
        this.compactForced = false;
      }
      this.lastPanelStatus = state.status;
      const compact = !passive && (this.compactForced || (running && !this.compactExpanded));
      this.panelEl.classList.toggle("cfpt-compact", compact);
      updatePanelDynamic(this.panelEl, state);
      this.mount();
      if (!passive && compact && !this.runMiniDismissed && this.host.dataset["expanded"] !== "true") this.toggle(true);
      if (state.status === "idle") this.runMiniDismissed = false;
    }
    dispose() {
      this.disposed = true;
      this.mountObserver.disconnect();
      clearInterval(this.mountHealthTimer);
      this.themeObserver.disconnect();
      document.removeEventListener("visibilitychange", this.syncBackgroundAppearance);
      window.removeEventListener("focusin", this.guardNativeFocusCapture, true);
      for (const type of FREEPT_INPUT_EVENTS) {
        window.removeEventListener(type, this.isolateFreePtInputCapture, true);
      }
      this.nativeComposer.restore(false);
      this.host.remove();
      this.overlayHost.remove();
    }
    async acknowledgeSetup() {
      this.setupBackdropEl.classList.add("cfpt-hidden");
      if (this.host.dataset["expanded"] === "true") this.panelEl.classList.remove("cfpt-hidden");
      this.onboarding.setupShown = true;
      this.host.dataset["onboarding"] = "done";
      this.host.dataset["highlighted"] = "false";
      const tooltip = this.launcherShadow.querySelector("#cfpt-launcher-tooltip");
      if (tooltip) tooltip.textContent = "Chat FreePT";
      await this.persistOnboarding();
    }
    showCompletion(_state) {
      this.toggle(true);
    }
    createLauncher() {
      const host = document.createElement("span");
      host.id = "cfpt-root";
      host.dataset["cfptEmbedded"] = "true";
      host.dataset["cfptLauncher"] = "airplane";
      host.dataset["cfptHost"] = "launcher";
      host.dataset["expanded"] = "false";
      host.dataset["onboarding"] = "loading";
      host.dataset["highlighted"] = "false";
      host.dataset["fallback"] = "false";
      const shadow = host.attachShadow({ mode: "closed" });
      appendStyle(shadow);
      const button = document.createElement("button");
      button.type = "button";
      button.className = "cfpt-launcher";
      button.setAttribute("aria-label", "Open Chat FreePT");
      button.setAttribute("aria-expanded", "false");
      button.setAttribute("aria-describedby", "cfpt-launcher-tooltip");
      button.innerHTML = airplaneSvg();
      button.addEventListener("pointerover", (event) => event.stopPropagation());
      button.addEventListener("mouseover", (event) => event.stopPropagation());
      button.addEventListener("pointerdown", (event) => event.stopPropagation());
      button.addEventListener("mousedown", (event) => event.stopPropagation());
      button.addEventListener("click", (event) => {
        event.stopPropagation();
        this.onLauncherClick();
      });
      const tooltip = document.createElement("span");
      tooltip.id = "cfpt-launcher-tooltip";
      tooltip.className = "cfpt-launcher-tooltip";
      tooltip.setAttribute("role", "tooltip");
      tooltip.textContent = "Chat FreePT";
      shadow.append(button, tooltip);
      return { host, shadow, button };
    }
    createOverlay() {
      const host = document.createElement("div");
      host.id = "cfpt-overlay-root";
      host.dataset["cfptHost"] = "overlay";
      host.dataset["expanded"] = "false";
      const shadow = host.attachShadow({ mode: "closed" });
      appendStyle(shadow);
      const backdrop = document.createElement("div");
      backdrop.className = "cfpt-takeover-backdrop cfpt-hidden";
      const panel2 = document.createElement("div");
      panel2.className = "cfpt-panel cfpt-hidden";
      panel2.setAttribute("role", "region");
      panel2.setAttribute("aria-label", "Chat FreePT extended composer");
      backdrop.appendChild(panel2);
      shadow.appendChild(backdrop);
      const setup = document.createElement("div");
      setup.className = "cfpt-setup-backdrop cfpt-hidden";
      shadow.appendChild(setup);
      return { host, shadow, backdrop, panel: panel2, setup };
    }
    bindEvents() {
      this.shadow.addEventListener("click", (event) => {
        this.stopComposerPropagation(event);
        this.onClick(event);
      });
      this.shadow.addEventListener("dblclick", (event) => {
        const target = event.target;
        if (!(target instanceof Element) || !target.closest(".cfpt-compact-bar") || target.closest("button, a")) return;
        event.preventDefault();
        event.stopPropagation();
        this.expandCompact();
      });
      this.shadow.addEventListener("pointerdown", (event) => this.stopComposerPropagation(event));
      this.shadow.addEventListener("mousedown", (event) => this.stopComposerPropagation(event));
      this.shadow.addEventListener("focusin", (event) => {
        this.rememberIntegratedFocus(event);
        this.stopComposerPropagation(event);
      });
      this.shadow.addEventListener("beforeinput", (event) => this.stopComposerPropagation(event));
      this.shadow.addEventListener("input", (event) => this.stopComposerPropagation(event));
      this.shadow.addEventListener("paste", (event) => this.stopComposerPropagation(event));
      this.shadow.addEventListener(
        "compositionstart",
        (event) => this.stopComposerPropagation(event)
      );
      this.shadow.addEventListener(
        "compositionupdate",
        (event) => this.stopComposerPropagation(event)
      );
      this.shadow.addEventListener("compositionend", (event) => this.stopComposerPropagation(event));
      this.shadow.addEventListener("keyup", (event) => this.stopComposerPropagation(event));
      this.shadow.addEventListener("keydown", (event) => {
        this.stopComposerPropagation(event);
        this.onKeyDown(event);
      });
      this.takeoverBackdropEl.addEventListener("click", (event) => {
        if (event.target === this.takeoverBackdropEl) this.toggle(false);
      });
      this.setupBackdropEl.addEventListener("click", (event) => {
        if (event.target === this.setupBackdropEl) void this.acknowledgeSetup();
      });
      window.addEventListener("focusin", this.guardNativeFocusCapture, true);
      for (const type of FREEPT_INPUT_EVENTS) {
        window.addEventListener(type, this.isolateFreePtInputCapture, true);
      }
    }
    isolateFreePtInputCapture = (event) => {
      if (this.host.dataset["expanded"] !== "true") return;
      const path = event.composedPath();
      const fromFreePt = path.includes(this.overlayHost);
      const fromGuardedNative = this.nativeComposer.isGuardedPath(path);
      if (!fromFreePt && !fromGuardedNative) return;
      if (event.type === "paste" && this.redirectPaste(event)) {
        event.stopImmediatePropagation();
        return;
      }
      if (fromFreePt && event.type === "input") {
        const field = this.activeIntegratedTextField();
        if (field) this.persistProjectDraftField(field);
      }
      if (event instanceof KeyboardEvent && event.key === "Escape") this.onKeyDown(event);
      event.stopImmediatePropagation();
    };
    redirectPaste(event) {
      const field = this.activeIntegratedTextField();
      const clipboardData = event.clipboardData;
      if (!field || field.readOnly || field.disabled || !clipboardData) return false;
      event.preventDefault();
      const text = clipboardData.getData("text/plain");
      const start = field.selectionStart ?? field.value.length;
      const end = field.selectionEnd ?? start;
      field.setRangeText(text, start, end, "end");
      this.persistProjectDraftField(field);
      this.lastIntegratedField = field;
      field.focus({ preventScroll: true });
      queueMicrotask(() => field.focus({ preventScroll: true }));
      return true;
    }
    activeIntegratedTextField() {
      const active = this.shadow.activeElement;
      if (active instanceof HTMLInputElement || active instanceof HTMLTextAreaElement) return active;
      return this.lastIntegratedField?.isConnected === true ? this.lastIntegratedField : null;
    }
    rememberIntegratedFocus(event) {
      const target = event.target;
      if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement) {
        this.lastIntegratedField = target;
      }
    }
    persistProjectDraftField(field) {
      const ref = field.dataset["ref"];
      if (ref !== "reponame" && ref !== "idea") return;
      const error = this.panelEl.querySelector(`[data-ref="${ref === "idea" ? "idea-error" : "repo-error"}"]`);
      if (error) error.textContent = "";
      this.hooks.onEvent({
        type: "USER_UPDATE_DRAFT",
        repoName: this.refValue("reponame"),
        idea: this.refValue("idea")
      });
    }
    guardNativeFocusCapture = (event) => {
      if (this.host.dataset["expanded"] !== "true") return;
      if (!this.nativeComposer.isGuardedTarget(event.target)) return;
      event.stopImmediatePropagation();
      const field = this.activeIntegratedTextField();
      if (field) queueMicrotask(() => field.focus({ preventScroll: true }));
    };
    focusIntegratedSurface() {
      const target = this.lastIntegratedField?.isConnected === true ? this.lastIntegratedField : this.panelEl.querySelector(
        '[data-ref="idea"], [data-ref="reply"], [data-ref="queue-next"], [data-ref="reponame"]'
      ) ?? this.setupBackdropEl.querySelector("button, input, textarea") ?? this.panelEl.querySelector("button, input, textarea");
      if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement) {
        this.lastIntegratedField = target;
      }
      target?.focus({ preventScroll: true });
    }
    stopComposerPropagation(event) {
      if (event.composedPath().includes(this.panelEl) || event.composedPath().includes(this.setupBackdropEl)) {
        event.stopPropagation();
      }
    }
    onKeyDown(event) {
      if (!(event instanceof KeyboardEvent) || event.key !== "Escape") return;
      if (!this.setupBackdropEl.classList.contains("cfpt-hidden")) {
        void this.acknowledgeSetup();
        return;
      }
      if (this.host.dataset["expanded"] === "true") this.toggle(false);
    }
    onLauncherClick() {
      if (this.host.dataset["onboarding"] === "tip") {
        this.showSetupPanel();
        return;
      }
      this.toggle();
    }
    async initOnboarding() {
      try {
        const found = await cfptStorage.local.get(ONBOARDING_KEY);
        this.onboarding = normalizeOnboarding(found[ONBOARDING_KEY]);
      } catch {
        this.onboarding = { ...DEFAULT_ONBOARDING };
      }
      if (this.disposed) return;
      if (!this.onboarding.setupShown) this.showLauncherTip();
      else this.host.dataset["onboarding"] = "done";
    }
    async persistOnboarding() {
      try {
        await cfptStorage.local.set({ [ONBOARDING_KEY]: this.onboarding });
      } catch {
      }
    }
    showLauncherTip() {
      this.setupBackdropEl.classList.add("cfpt-hidden");
      this.host.dataset["onboarding"] = "tip";
      this.host.dataset["highlighted"] = "true";
      const tooltip = this.launcherShadow.querySelector("#cfpt-launcher-tooltip");
      if (tooltip) tooltip.textContent = "Chat FreePT \u2014 click to extend this composer";
    }
    showSetupPanel() {
      this.host.dataset["highlighted"] = "false";
      const tooltip = this.launcherShadow.querySelector("#cfpt-launcher-tooltip");
      if (tooltip) tooltip.textContent = "Chat FreePT";
      this.toggle(true);
      this.panelEl.classList.add("cfpt-hidden");
      this.setupBackdropEl.innerHTML = repositorySetupHtml();
      this.setupBackdropEl.classList.remove("cfpt-hidden");
      this.host.dataset["onboarding"] = "setup";
      queueMicrotask(() => {
        this.setupBackdropEl.querySelector("button")?.focus();
      });
    }
    scheduleMount() {
      if (this.disposed || this.mountQueued) return;
      this.mountQueued = true;
      // Batch React's navigation/hydration mutations instead of forcing a
      // layout read at microtask frequency during streaming.
      setTimeout(() => {
        this.mountQueued = false;
        this.mount();
      }, 100);
    }
    mount() {
      if (this.disposed) return;
      const form = this.nativeComposer.form();
      if (!form?.isConnected) return;
      const plus = composerPlusButton(form);
      if (plus?.parentElement) {
        if (plus.nextElementSibling !== this.host) plus.insertAdjacentElement("afterend", this.host);
        this.host.dataset["fallback"] = "false";
      } else {
        // Always attach inside the same form as the active textbox, not an old
        // sidebar or another form retained during React route transitions.
        const anchor = this.nativeComposer.surface() ?? form;
        if (anchor && this.host.parentElement !== anchor) anchor.appendChild(this.host);
        this.host.dataset["fallback"] = "true";
      }
      this.nativeComposer.mountOverlay();
      if (form !== this.lastMountedForm) {
        this.lastMountedForm = form;
        this.nativeComposer.syncTheme();
      }
      if (this.host.dataset["expanded"] === "true") this.nativeComposer.activate();
    }
    expandCompact() {
      this.compactExpanded = true;
      this.compactForced = false;
      this.panelEl.classList.remove("cfpt-compact");
    }
    onClick(event) {
      event.stopPropagation();
      const target = event.target.closest("[data-action]");
      if (!target) return;
      switch (target.dataset["action"]) {
        case "compact-expand":
          this.expandCompact();
          break;
        case "compact-collapse":
          this.compactExpanded = false;
          this.compactForced = true;
          this.panelEl.classList.add("cfpt-compact");
          break;
        case "close":
          this.toggle(false);
          break;
        case "attach":
          void this.attachConversation().catch((error) => log.warn("attach failed", error));
          break;
        case "start":
          void this.startProject().catch((error) => {
            log.warn("start project failed", error);
            const line = this.panelEl.querySelector('[data-ref="project-error"]');
            if (line) line.textContent = "Could not start planning. Open developer diagnostics and report this issue.";
          });
          break;
        case "startdev":
          this.hooks.onEvent({ type: "USER_START_DEVELOPMENT" });
          break;
        case "pause":
          this.hooks.onEvent({ type: "USER_PAUSE" });
          break;
        case "resume":
          this.hooks.onEvent({ type: "USER_RESUME" });
          break;
        case "sendnow":
          this.hooks.onEvent({ type: "COOLDOWN_ELAPSED" });
          break;
        case "reply":
          this.sendReply();
          break;
        case "stop":
          this.stopRun(target);
          break;
        case "newproject":
          this.hooks.onEvent({ type: "USER_NEW_PROJECT" });
          break;
        case "copyhandoff":
          this.copyHandoff(target);
          break;
        case "showqueue":
          this.showQueueEditor();
          break;
        case "hidequeue":
          this.hideQueueEditor();
          break;
        case "savequeue":
          this.saveQueuedMessage();
          break;
        case "queue-up":
          this.hooks.onEvent({
            type: "USER_MOVE_QUEUE",
            index: Number(target.dataset["index"]),
            direction: -1
          });
          break;
        case "queue-down":
          this.hooks.onEvent({
            type: "USER_MOVE_QUEUE",
            index: Number(target.dataset["index"]),
            direction: 1
          });
          break;
        case "queue-remove":
          this.hooks.onEvent({
            type: "USER_REMOVE_QUEUE",
            index: Number(target.dataset["index"])
          });
          break;
        case "clearqueue":
          this.hooks.onEvent({ type: "USER_CLEAR_QUEUE" });
          break;
        case "setup-open":
          this.showSetupPanel();
          break;
        case "setup-done":
          void this.acknowledgeSetup();
          break;
        case "guide-project":
          projectWalkthrough.start("project");
          void this.acknowledgeSetup();
          break;
        case "guide-chat":
          projectWalkthrough.start("chat");
          void this.acknowledgeSetup();
          break;
      }
    }
    async attachConversation() {
      const report = (ref, message) => {
        const el = this.panelEl.querySelector(`[data-ref="${ref}"]`);
        if (el) el.textContent = message;
      };
      for (const ref of ["repo-error", "project-error"]) report(ref, "");
      const repo = normalizeRepositoryInput(this.refValue("reponame"));
      if (!repo) {
        report("repo-error", "Enter a valid owner/repo or GitHub repository URL.");
        this.panelEl.querySelector('[data-ref="reponame"]')?.focus();
        return;
      }
      if (!conversationHasHistory()) {
        report("project-error", "No existing conversation found. Start planning instead.");
        return;
      }
      const projectId = projectIdFromUrl(location.href);
      if (!isProjectChat(location.href)) {
        report("project-error", "Open this conversation inside a ChatGPT Project before enabling autopilot.");
        projectWalkthrough.start(projectId ? "chat" : "project");
        return;
      }
      const reported = normalizeRepositoryInput(recentConversationMarker()?.repo ?? "");
      if (reported && reported.toLowerCase() !== repo.toLowerCase()) {
        report("repo-error", `The latest ChatGPT reply names ${reported}. Verify the repository before attaching.`);
        return;
      }
      try { await bindProjectRepo(projectId, repo); }
      catch (error) {
        report("repo-error", error instanceof Error ? error.message : "Project repository mismatch.");
        return;
      }
      this.hooks.onEvent({ type: "USER_ATTACH_EXISTING", repoName: repo });
    }
    async startProject() {
      const fieldError = (ref, message) => {
        const el = this.panelEl.querySelector(`[data-ref="${ref}"]`);
        if (el) el.textContent = message;
      };
      for (const ref of ["idea-error", "repo-error", "project-error"]) fieldError(ref, "");
      const idea = this.refValue("idea").trim();
      const repo = normalizeRepositoryInput(this.refValue("reponame"));
      if (!idea) {
        fieldError("idea-error", "Describe what ChatGPT should build before starting.");
        this.panelEl.querySelector('[data-ref="idea"]')?.focus();
        return;
      }
      if (!repo) {
        fieldError("repo-error", "Enter a valid GitHub owner/repo or repository URL.");
        this.panelEl.querySelector('[data-ref="reponame"]')?.focus();
        return;
      }
      const projectId = projectIdFromUrl(location.href);
      if (!isProjectChat(location.href)) {
        fieldError("project-error", "Open a new chat inside a ChatGPT Project to start planning. Your details will be kept for that chat.");
        try {
          await saveSetupDraft(idea, repo);
        } catch (error) {
          log.warn("Could not preserve draft during Project setup", error);
          fieldError("project-error", "Open a new chat inside a ChatGPT Project, then enter your details again to start.");
        }
        projectWalkthrough.start(projectId ? "chat" : "project");
        return;
      }
      try {
        await bindProjectRepo(projectId, repo);
      } catch (error) {
        fieldError("repo-error", error instanceof Error ? error.message : "Unable to bind repository to Project.");
        return;
      }
      this.hooks.onEvent({ type: "USER_START", idea, repoMode: "existing", repoName: repo });
    }
    sendReply() {
      const text = this.refValue("reply");
      if (!text.trim()) return;
      this.hooks.onEvent({ type: "USER_REPLY", text });
    }
    showQueueEditor() {
      const editor = this.panelEl.querySelector('[data-ref="queue-editor"]');
      editor?.classList.remove("cfpt-hidden");
      this.panelEl.querySelector('[data-ref="queue-next"]')?.focus();
    }
    hideQueueEditor() {
      this.panelEl.querySelector('[data-ref="queue-editor"]')?.classList.add("cfpt-hidden");
    }
    saveQueuedMessage() {
      const input = this.panelEl.querySelector('[data-ref="queue-next"]');
      const text = input?.value.trim() ?? "";
      if (!text) return;
      this.hooks.onEvent({ type: "USER_QUEUE_NEXT", text });
      if (input) input.value = "";
      this.hideQueueEditor();
    }
    stopRun(target) {
      if (!this.stopArmed) {
        this.stopArmed = true;
        target.textContent = "Confirm stop";
        setTimeout(() => {
          this.stopArmed = false;
          if (target.isConnected) target.textContent = "Stop";
        }, 3e3);
        return;
      }
      this.hooks.onEvent({ type: "USER_STOP" });
    }
    copyHandoff(target) {
      const prompt = this.hooks.getHandoffPrompt();
      void navigator.clipboard.writeText(prompt).then(() => {
        target.textContent = "Copied \u2014 paste it into a new chat";
      });
    }
    refValue(ref) {
      const el = this.panelEl.querySelector(`[data-ref="${ref}"]`);
      return el?.value ?? "";
    }
  };
  function appendStyle(root) {
    const style = document.createElement("style");
    style.textContent = PANEL_CSS;
    root.appendChild(style);
  }

  // src/content/debug-dock.ts
  // Always available on ChatGPT pages, including Project creation and settings.
  var DebugDock = class {
    constructor(recorder, submit) {
      this.recorder = recorder;
      this.submit = submit;
      this.host = document.createElement("div");
      this.host.id = "cfpt-debug-root";
      const shadow = this.host.attachShadow({ mode: "closed" });
      this.shadow = shadow;
      const style = document.createElement("style");
      style.textContent = `:host { position:fixed;right:7px;bottom:6px;z-index:2147483645;font:12px system-ui,sans-serif;color:#e9e9ed }
        button{cursor:pointer;font:inherit;border-radius:7px;border:1px solid #555;background:#38383d;color:inherit;padding:6px 9px}
        .trigger{font-size:9px;line-height:1;padding:5px;opacity:.45;background:#202123;border:0}
        .trigger:hover,.trigger:focus-visible{opacity:1;outline:1px solid #888}
        .pane{display:none;position:absolute;right:0;bottom:26px;min-width:255px;max-width:290px;background:#202123;border:1px solid #52525b;border-radius:9px;box-shadow:0 8px 28px #0006;padding:13px;}
        .pane.open{display:block}.tools{display:flex;gap:6px;flex-wrap:wrap;margin:10px 0}.hint{color:#bcbcc5;font-size:11px;line-height:1.45}
        .title{font-weight:700;font-size:13px}.status{margin-top:7px;font-size:11px}`;
      const trigger = document.createElement("button");
      trigger.type = "button"; trigger.className = "trigger"; trigger.textContent = "dbg";
      trigger.setAttribute("aria-label", "Open developer diagnostics");
      trigger.setAttribute("aria-expanded", "false");
      const pane = document.createElement("section"); pane.className = "pane";
      pane.innerHTML = `<div class="title">Developer diagnostics</div><div class="status" role="status"></div>
        <div class="tools"><button type="button" data-cfpt="start">Record</button><button type="button" data-cfpt="stop">Stop</button><button type="button" data-cfpt="save">Download</button><button type="button" data-cfpt="submit">Report issue</button></div>
        <div class="hint">Record actions, stop, then report. A redacted JSON file downloads and GitHub opens; review the file and attach it before submitting. Nothing is automatically uploaded.</div>`;
      shadow.append(style, trigger, pane);
      trigger.addEventListener("click", (event) => {
        event.stopPropagation();
        const open = pane.classList.toggle("open");
        trigger.setAttribute("aria-expanded", String(open));
        this.update(this.recorder.status);
      });
      pane.addEventListener("click", (event) => {
        event.stopPropagation();
        const action = event.target.closest("button")?.dataset.cfpt;
        if (action === "start") this.recorder.start();
        if (action === "stop") this.recorder.stop();
        if (action === "save" && this.recorder.status.records) this.recorder.exportFile();
        if (action === "submit") this.submit();
        this.update(this.recorder.status);
      });
      this.host.addEventListener("pointerdown", (event) => event.stopPropagation());
      document.documentElement.appendChild(this.host);
      this.update(recorder.status);
    }
    update(status) {
      if (!this.host.isConnected) return;
      const message = status.recording ? `Recording ${status.records} events` : status.records ? `${status.records} events ready` : "Not recording";
      this.shadow.querySelector(".status").textContent = message;
      this.shadow.querySelector('[data-cfpt="start"]').disabled = status.recording;
      this.shadow.querySelector('[data-cfpt="stop"]').disabled = !status.recording;
      this.shadow.querySelector('[data-cfpt="save"]').disabled = !status.records;
      this.shadow.querySelector('[data-cfpt="submit"]').disabled = !status.records;
    }
    dispose() { this.host.remove(); }
  };

  // src/content/index.ts
  var HEARTBEAT_MS = 5e3;
  var TAKEOVER_RETRY_MS = 5e3;
  var ROLLOVER_SESSION_KEY = "cfpt:conversation-rollover:v1";
  var tabNonce = crypto.randomUUID();
  var panel = null;
  var controller = null;
  var currentConvId = "";
  var heartbeatTimer;
  var takeoverTimer;
  var stopNavigation;
  var debugDock = null;
  var diagnostics = new DiagnosticsRecorder({
    getRunState: () => controller?.state ?? null,
    onStatus: (status) => debugDock?.update(status)
  });
  function submitBugReport() {
    if (!diagnostics.status.records) return;
    if (diagnostics.status.recording) diagnostics.stop();
    const report = diagnostics.buildExport();
    diagnostics.exportFile();
    const title = encodeURIComponent("[Diagnostics] Chat FreePT bug report");
    const body = encodeURIComponent(`**Describe the problem:**\n\n**Steps to reproduce:**\n\n**Expected / actual behavior:**\n\n**Diagnostic session:** ${report.sessionId}\n**Events:** ${report.summary.events}\n**Route:** ${report.summary.route}\n\nReview the downloaded JSON file and attach it here before submitting. No file was uploaded automatically.`);
    window.open(`https://github.com/mlookhere/Chat-FreePT/issues/new?title=${title}&body=${body}`, "_blank", "noopener,noreferrer");
  }
  var contextGuard = createExtensionContextGuard(() => shutdownInvalidatedContext());
  function pendingRolloverId() {
    try {
      const value = sessionStorage.getItem(ROLLOVER_SESSION_KEY);
      return value?.startsWith("pending:") ? value : null;
    } catch {
      return null;
    }
  }
  function rememberRollover(conversationId) {
    try {
      sessionStorage.setItem(ROLLOVER_SESSION_KEY, conversationId);
    } catch {
    }
  }
  function clearRollover(conversationId) {
    try {
      if (sessionStorage.getItem(ROLLOVER_SESSION_KEY) === conversationId) {
        sessionStorage.removeItem(ROLLOVER_SESSION_KEY);
      }
    } catch {
    }
  }
  function conversationKeyFromLocation() {
    return conversationIdFromUrl(location.href) ?? pendingRolloverId() ?? `pending:${crypto.randomUUID()}`;
  }
  function backgroundEligible(state) {
    return Boolean(state?.projectId && state.projectId === projectIdFromUrl(location.href) &&
      ["planning", "plan_ready", "developing"].includes(state.phase) &&
      ["inserting", "sending", "streaming", "cooldown"].includes(state.status));
  }
  function syncBackgroundRun(state) {
    if (contextGuard.invalidated) return;
    const active = backgroundEligible(state);
    void chrome.runtime.sendMessage({
      type: "cfpt-run-activity", active,
      conversationId: active ? currentConvId : "",
      nonce: active ? tabNonce : ""
    }).catch((error) => reportAsyncFailure("background run registration failed", error));
  }
  function stopHeartbeat() {
    if (heartbeatTimer !== void 0) clearInterval(heartbeatTimer);
    heartbeatTimer = void 0;
  }
  function stopTakeoverRetry() {
    if (takeoverTimer !== void 0) clearTimeout(takeoverTimer);
    takeoverTimer = void 0;
  }
  function shutdownInvalidatedContext() {
    stopHeartbeat();
    stopTakeoverRetry();
    stopNavigation?.();
    stopNavigation = void 0;
    syncBackgroundRun(null);
    controller?.dispose();
    controller = null;
    panel?.dispose();
    panel = null;
    diagnostics.dispose();
    debugDock?.dispose();
    debugDock = null;
    projectWalkthrough.stop();
  }
  function reportAsyncFailure(message, error) {
    if (contextGuard.handle(error)) return;
    log.warn(message, error);
  }
  async function releaseOwnedLock(conversationId) {
    if (contextGuard.invalidated || !conversationId) return;
    try {
      await releaseTabLock(conversationId, tabNonce);
    } catch (error) {
      reportAsyncFailure("tab lock release failed", error);
    }
  }
  async function disposeControllerPersisted() {
    const ctl = controller;
    controller = null;
    if (!ctl) return;
    ctl.dispose();
    syncBackgroundRun(null);
    await ctl.flushState();
  }
  function startHeartbeat() {
    stopHeartbeat();
    if (contextGuard.invalidated) return;
    heartbeatTimer = setInterval(() => {
      if (contextGuard.invalidated) {
        stopHeartbeat();
        return;
      }
      const conversationId = currentConvId;
      void heartbeatTabLock(conversationId, tabNonce).then((owned) => {
        if (!owned) loseOwnership(conversationId);
      }).catch((error) => reportAsyncFailure("tab lock heartbeat failed", error));
    }, HEARTBEAT_MS);
  }
  async function rolloverConversation(state) {
    if (contextGuard.invalidated || !state.repo || !state.projectId ||
      projectIdFromUrl(location.href) !== state.projectId) return;
    const sourceConversationId = currentConvId;
    const nextConversationId = `pending:${crypto.randomUUID()}`;
    const nextState = prepareConversationHandoff(state, nextConversationId, Date.now());
    try {
      await controller?.flushState();
      await saveRun(nextState);
      rememberRollover(nextConversationId);
      stopHeartbeat();
      stopTakeoverRetry();
      await releaseOwnedLock(sourceConversationId);
      if (contextGuard.invalidated) return;
      window.location.assign(freshConversationUrl(location.href));
    } catch (error) {
      reportAsyncFailure("automatic conversation handoff failed", error);
    }
  }
  function startController(state, settings) {
    if (contextGuard.invalidated) return;
    stopTakeoverRetry();
    startHeartbeat();
    const ctl = new RunController(state, settings, {
      onChange: (next) => {
        panel?.render(next);
        syncBackgroundRun(next);
        diagnostics.captureSnapshot("controller-change", true);
      },
      onShowCompletion: () => {
        if (controller) panel?.showCompletion(controller.state);
      },
      onConversationHandoff: (handoffState) => rolloverConversation(handoffState),
      onContextInvalidated: () => contextGuard.invalidate(),
      onDiagnosticEvent: (event) => diagnostics.recordControllerEvent(event),
      withComposerAccess: async (task) => {
        if (!await heartbeatTabLock(currentConvId, tabNonce)) {
          loseOwnership(currentConvId);
          throw new Error("Conversation ownership changed before sending");
        }
        if (panel) return panel.withNativeComposerAccess(task);
        return task();
      }
    });
    controller = ctl;
    panel?.render(state);
    syncBackgroundRun(state);
    if (state.handoffPending) {
      log.info("resuming project in a new conversation");
      setTimeout(() => {
        if (controller === ctl && !contextGuard.invalidated) ctl.dispatch({ type: "HANDOFF_READY" });
      }, 500);
      return;
    }
    if (state.phase === "plan_ready" && state.status === "awaiting_user") {
      log.info("auto-advancing legacy plan-ready state into development");
      setTimeout(() => {
        if (controller === ctl && !contextGuard.invalidated) {
          ctl.dispatch({ type: "USER_START_DEVELOPMENT" });
        }
      }, 500);
      return;
    }
    if (isActive(state) && (!state.projectId || projectIdFromUrl(location.href) === state.projectId) &&
      isProjectChat(location.href)) {
      log.info("resuming active run", state.phase, state.status);
      setTimeout(() => {
        if (controller === ctl && !contextGuard.invalidated) ctl.reconcile();
      }, 2e3);
    }
  }
  function enterPassive(state) {
    if (contextGuard.invalidated) return;
    syncBackgroundRun(null);
    controller?.dispose();
    controller = null;
    stopHeartbeat();
    panel?.render(state, true);
    scheduleTakeover(state.conversationId);
  }
  function scheduleTakeover(conversationId) {
    stopTakeoverRetry();
    if (contextGuard.invalidated) return;
    takeoverTimer = setTimeout(() => void tryTakeover(conversationId), TAKEOVER_RETRY_MS);
  }
  async function tryTakeover(conversationId) {
    takeoverTimer = void 0;
    if (contextGuard.invalidated || controller || conversationId !== currentConvId) return;
    let acquired = false;
    try {
      acquired = await acquireTabLock(conversationId, tabNonce);
      if (!acquired) {
        scheduleTakeover(conversationId);
        return;
      }
      const [settings, stored] = await Promise.all([loadSettings(), loadRun(conversationId)]);
      if (contextGuard.invalidated) return;
      if (controller || conversationId !== currentConvId) {
        await releaseOwnedLock(conversationId);
        return;
      }
      const state = stored ?? newRunState(conversationId, Date.now());
      startController(state, settings);
      log.info("took over conversation after previous tab became inactive");
    } catch (error) {
      if (contextGuard.handle(error)) return;
      if (acquired) await releaseOwnedLock(conversationId);
      log.warn("conversation ownership retry failed", error);
      if (!controller && conversationId === currentConvId) scheduleTakeover(conversationId);
    }
  }
  function loseOwnership(conversationId) {
    if (contextGuard.invalidated || !controller || conversationId !== currentConvId) return;
    const state = controller.state;
    log.info("conversation ownership moved to another tab; becoming passive");
    enterPassive(state);
  }
  async function initConversation(convId) {
    if (contextGuard.invalidated) return;
    await disposeControllerPersisted();
    stopHeartbeat();
    stopTakeoverRetry();
    currentConvId = convId;
    const settings = await loadSettings();
    const storedState = await loadRun(convId);
    if (contextGuard.invalidated || currentConvId !== convId) return;
    const projectId = projectIdFromUrl(location.href);
    const projectRepo = await loadProjectRepo(projectId);
    const state = storedState ?? newRunState(convId, Date.now());
    const historyStatus = recentConversationStatus();
    const historyMarker = historyStatus?.marker ?? null;
    if (historyMarker && (!projectRepo || !historyMarker.repo ||
        projectRepo.toLowerCase() === historyMarker.repo.toLowerCase())) {
      state.lastMarker = historyMarker;
      if (historyMarker.item) state.currentItem = historyMarker.item;
      if (historyMarker.note) state.workSummary = historyMarker.note;
      if (historyMarker.repo && !state.repoName) state.repoName = historyMarker.repo;
    }
    if (projectId && state.status === "idle" && !state.idea.trim() && !state.repoName.trim()) {
      try {
        const draft = await takeSetupDraft();
        const draftRepo = draft && normalizeRepositoryInput(draft.repoName);
        if (draft && draftRepo && (!projectRepo || projectRepo.toLowerCase() === draftRepo.toLowerCase())) {
          state.idea = draft.idea;
          state.repoName = projectRepo ?? draftRepo;
          state.repoMode = "existing";
        }
      } catch (error) {
        log.warn("Could not restore Project setup draft", error);
      }
    }
    if (storedState?.repo && !projectId) {
      state.status = "paused";
      state.pauseReason = "Open this conversation inside its ChatGPT Project to resume.";
    }
    if (projectId) {
      if (state.repo && !projectRepo && !state.projectId) {
        state.status = "paused";
        state.pauseReason = "Existing repository has no verified Project binding.";
      }
      if (state.projectId && state.projectId !== projectId) {
        state.status = "paused";
        state.pauseReason = "Project mismatch: return to the original ChatGPT Project.";
      } else if (projectRepo && state.repo && projectRepo.toLowerCase() !== state.repo.toLowerCase()) {
        state.status = "paused";
        state.pauseReason = `Project is bound to ${projectRepo}; this conversation uses ${state.repo}.`;
      } else if (state.status !== "paused" || !state.pauseReason?.includes("binding")) {
        state.projectId = projectId;
        if (state.repo && !projectRepo) await bindProjectRepo(projectId, state.repo);
        if (!state.repo && projectRepo) {
          state.repo = projectRepo;
          state.repoName = projectRepo;
          state.repoMode = "existing";
        }
      }
    }
    if (historyMarker && state.repo && (!historyMarker.repo ||
        historyMarker.repo.toLowerCase() === state.repo.toLowerCase()) &&
        !["sending", "streaming", "inserting"].includes(state.status)) {
      rememberReportedWork(state, historyMarker, historyStatus.text);
    }
    let locked;
    try {
      locked = await acquireTabLock(convId, tabNonce);
    } catch (error) {
      if (contextGuard.handle(error)) return;
      log.warn("conversation ownership verification unavailable", error);
      state.status = "error";
      state.errorCode = "ownership-service-unavailable";
      state.pauseReason = "Cannot verify tab ownership. Reload the ChatGPT tab to retry; no automatic messages will be sent until ownership is established.";
      panel?.render(state);
      return;
    }
    if (contextGuard.invalidated || currentConvId !== convId) {
      if (locked) await releaseOwnedLock(convId);
      return;
    }
    if (!locked) {
      log.info("another tab is driving this conversation; staying passive");
      enterPassive(state);
      return;
    }
    startController(state, settings);
    // A known Project/repository pair can resume its own status-marked native chat.
    // Never auto-attach an unrelated Project conversation with no status evidence.
    if (!storedState && projectRepo && historyMarker?.repo?.toLowerCase() === projectRepo.toLowerCase() &&
        conversationHasHistory() && isProjectChat(location.href)) {
      const ctl = controller;
      setTimeout(() => {
        if (ctl && ctl === controller && ctl.state.status === "idle" && !contextGuard.invalidated) {
          ctl.dispatch({ type: "USER_ATTACH_EXISTING", repoName: projectRepo });
        }
      }, 500);
    }
  }
  async function leaveConversationForUtilityPage(mode) {
    panel?.toggle(false);
    stopTakeoverRetry();
    await disposeControllerPersisted();
    stopHeartbeat();
    const previous = currentConvId;
    currentConvId = "";
    await releaseOwnedLock(previous);
    if (!contextGuard.invalidated) {
      log.debug(`Chat FreePT idle on expected non-composer route (${mode})`);
    }
  }
  var activationInFlight = false;
  async function activateComposerPage() {
    if (contextGuard.invalidated || panel || activationInFlight) return;
    activationInFlight = true;
    try {
    try {
      await require_("composer", 1500, 250);
    } catch {
      const mode = chatGptPageMode(location.href);
      if (mode !== "composer") {
        log.debug(`Chat FreePT idle on expected non-composer route (${mode})`);
        return;
      }
      if (pendingRolloverId() && projectIdFromUrl(location.href)) {
        projectWalkthrough.start("chat");
        log.warn("Project composer unavailable; guided handoff recovery active");
      } else {
        log.warn("composer never appeared; Chat FreePT idle (logged out or layout change?)");
      }
      return;
    }
    if (contextGuard.invalidated || chatGptPageMode(location.href) !== "composer" || panel) return;
    panel = new Panel({
      onEvent: (event) => controller?.dispatch(event),
      getHandoffPrompt: () => controller ? buildHandoffPrompt(controller.state) : ""
    });
    await initConversation(conversationKeyFromLocation());
    if (!contextGuard.invalidated) log.info("Chat FreePT ready");
    } finally { activationInFlight = false; }
  }
  async function onComposerNavigate(href) {
    const urlConv = conversationIdFromUrl(href);
    if (urlConv && currentConvId.startsWith("pending:") && controller &&
      controller.state.projectId === projectIdFromUrl(href)) {
      const pendingId = currentConvId;
      const ctl = controller;
      stopHeartbeat();
      let migrated;
      try {
        migrated = await adoptConversationOwnership(ctl.state, urlConv, tabNonce);
      } catch (error) {
        if (contextGuard.handle(error)) return;
        log.warn("failed to adopt permanent conversation id", error);
        startHeartbeat();
        return;
      }
      if (!migrated) {
        ctl.dispose();
        controller = null;
        await ctl.flushState();
        await releaseOwnedLock(pendingId);
        if (contextGuard.invalidated) return;
        currentConvId = urlConv;
        const state = await loadRun(urlConv) ?? newRunState(urlConv, Date.now());
        clearRollover(pendingId);
        log.info("another tab owns the permanent conversation id; staying passive");
        enterPassive(state);
        return;
      }
      currentConvId = urlConv;
      ctl.state = migrated;
      syncBackgroundRun(migrated);
      await ctl.flushState();
      await deleteRun(pendingId);
      clearRollover(pendingId);
      panel?.render(ctl.state);
      startHeartbeat();
      log.info("adopted conversation id", urlConv);
      return;
    }
    if (urlConv === currentConvId) return;
    if (!urlConv && currentConvId.startsWith("pending:") &&
      controller?.state.projectId === projectIdFromUrl(href)) return;
    stopTakeoverRetry();
    await disposeControllerPersisted();
    stopHeartbeat();
    await releaseOwnedLock(currentConvId);
    if (contextGuard.invalidated) return;
    await initConversation(urlConv ?? `pending:${crypto.randomUUID()}`);
  }
  async function onNavigate(href) {
    if (contextGuard.invalidated) return;
    const mode = chatGptPageMode(href);
    projectWalkthrough.refresh();
    if (mode !== "composer") {
      await leaveConversationForUtilityPage(mode);
      return;
    }
    if (!panel) {
      await activateComposerPage();
      return;
    }
    // URL-only SPA transitions need a mount even if React has not yet mutated
    // the composer, and the controller must follow the new conversation URL.
    panel.mount();
    await onComposerNavigate(href);
  }
  function installLifecycleListeners() {
    chrome.runtime.onMessage.addListener((message, _sender, respond) => {
      if (message.type === "toggle-panel") panel?.toggle();
      if (message.type === "cfpt-owner-probe") {
        respond({ owned: Boolean(controller && currentConvId === message.conversationId &&
          tabNonce === message.nonce && !contextGuard.invalidated) });
        return false;
      }
      if (message.type !== "cfpt-background-wake") return false;
      const ctl = controller;
      if (!ctl || !backgroundEligible(ctl.state) || message.conversationId !== currentConvId ||
          message.nonce !== tabNonce || contextGuard.invalidated) {
        respond({ active: false });
        return false;
      }
      // A wake is a reconciliation request, never an unconditional send.
      void heartbeatTabLock(currentConvId, tabNonce).then((owned) => {
        if (!owned) {
          loseOwnership(currentConvId);
          respond({ active: false });
          return;
        }
        if (ctl !== controller || !backgroundEligible(ctl.state)) {
          respond({ active: false });
          return;
        }
        ctl.watcher.tick();
        ctl.checkRuntime();
        respond({ active: backgroundEligible(ctl.state), conversationId: currentConvId });
      }).catch((error) => {
        reportAsyncFailure("background wake failed", error);
        respond({ active: false });
      });
      return true;
    });
    window.addEventListener("pagehide", () => {
      syncBackgroundRun(null);
      stopTakeoverRetry();
      stopHeartbeat();
      stopNavigation?.();
      stopNavigation = void 0;
      void controller?.flushState();
      void releaseOwnedLock(currentConvId);
    });
    stopNavigation = watchNavigation((href) => {
      void onNavigate(href).catch((error) => reportAsyncFailure("navigation handling failed", error));
    });
  }
  function observeComposerHydration() {
    let scheduled = false;
    const retry = () => {
      if (contextGuard.invalidated || panel || chatGptPageMode(location.href) !== "composer" ||
          !query("composer") || activationInFlight || scheduled) return;
      scheduled = true;
      setTimeout(() => {
        scheduled = false;
        void activateComposerPage().catch((error) => reportAsyncFailure("composer hydration retry failed", error));
      }, 100);
    };
    const observer = new MutationObserver(retry);
    observer.observe(document.documentElement, { childList: true, subtree: true });
    const timer = setInterval(() => {
      if (contextGuard.invalidated || panel) {
        clearInterval(timer);
        observer.disconnect();
      } else retry();
    }, 3000);
    window.addEventListener("pageshow", retry);
    retry();
  }
  async function boot() {
    debugDock = new DebugDock(diagnostics, submitBugReport);
    if (projectIdFromUrl(location.href) && /\/project\/?$/.test(new URL(location.href).pathname) && pendingRolloverId()) {
      projectWalkthrough.start("chat");
    }
    ensureChatStateBridge();
    installLifecycleListeners();
    observeComposerHydration();
    const mode = chatGptPageMode(location.href);
    if (mode !== "composer") {
      log.debug(`Chat FreePT idle on expected non-composer route (${mode})`);
      return;
    }
    await activateComposerPage();
  }
  void boot().catch((error) => reportAsyncFailure("Chat FreePT boot failed", error));
})();
