"use strict";
(() => {
  // src/diagnostics/sanitize.ts
  var SENSITIVE_KEY_RE = /authorization|cookie|token|secret|password|credential|api[-_]?key|session|csrf|jwt/i;
  var SEMANTIC_KEY_RE = /^(status|state|type|event|role|recipient|end_turn|finished|complete|is_complete|stop_reason|finish_reason)$/i;
  var ID_SEGMENT_RE = /^(?:[0-9a-f]{20,}|[0-9a-f]{8}-[0-9a-f-]{20,}|eyJ[A-Za-z0-9._-]{16,}|[A-Za-z0-9_-]{28,})$/i;
  var MAX_KEYS = 40;
  var MAX_SIGNALS = 80;
  function hashText(text) {
    let hash = 2166136261;
    for (let i = 0; i < text.length; i += 1) {
      hash ^= text.charCodeAt(i);
      hash = Math.imul(hash, 16777619);
    }
    return (hash >>> 0).toString(16).padStart(8, "0");
  }
  function summarizeString(text) {
    return { kind: "string", length: text.length, hash: hashText(text) };
  }
  function redactUrl(input) {
    let parsed;
    try {
      parsed = new URL(input, "https://chatgpt.com");
    } catch {
      return "[invalid-url]";
    }
    const path = parsed.pathname.split("/").map((segment) => ID_SEGMENT_RE.test(segment) ? "[id]" : segment).join("/");
    const keys = Array.from(parsed.searchParams.keys());
    const query = keys.length > 0 ? `?${keys.map((key) => `${encodeURIComponent(key)}=[redacted]`).join("&")}` : "";
    return `${parsed.origin}${path}${query}`;
  }
  function safeError(error) {
    if (error instanceof Error) {
      return { name: error.name, message: summarizeString(error.message) };
    }
    return { name: typeof error, message: summarizeString(String(error)) };
  }
  function summarizeUnknown(value) {
    if (value === null) return { kind: "null" };
    if (value === void 0) return { kind: "undefined" };
    if (typeof value === "string") return summarizeString(value);
    if (typeof value === "number" || typeof value === "boolean" || typeof value === "bigint") {
      return { kind: typeof value };
    }
    if (value instanceof URLSearchParams) {
      return { kind: "url-search-params", keys: unique(Array.from(value.keys())) };
    }
    if (typeof FormData !== "undefined" && value instanceof FormData) {
      return { kind: "form-data", keys: unique(Array.from(value.keys())) };
    }
    if (typeof Blob !== "undefined" && value instanceof Blob) {
      return { kind: "blob", length: value.size };
    }
    if (value instanceof ArrayBuffer) return { kind: "array-buffer", length: value.byteLength };
    if (ArrayBuffer.isView(value)) return { kind: "typed-array", length: value.byteLength };
    if (Array.isArray(value)) return { kind: "array", length: value.length };
    if (typeof value === "object") {
      return { kind: "object", keys: safeKeys(value) };
    }
    return { kind: typeof value };
  }
  function summarizeBody(value) {
    if (typeof value !== "string") return summarizeUnknown(value);
    const base = summarizeString(value);
    const trimmed = value.trim();
    if (!trimmed.startsWith("{") && !trimmed.startsWith("[")) return base;
    try {
      const parsed = JSON.parse(trimmed);
      if (Array.isArray(parsed)) return { ...base, kind: "json-array", length: parsed.length };
      if (parsed && typeof parsed === "object") {
        return { ...base, kind: "json-object", keys: safeKeys(parsed) };
      }
    } catch {
    }
    return base;
  }
  function summarizeResponseText(text, contentType) {
    const base = summarizeString(text);
    const semanticSignals = extractSemanticSignals(text, contentType);
    return semanticSignals.length > 0 ? { ...base, semanticSignals } : base;
  }
  function safeHeaders(headers) {
    const out = {};
    headers.forEach((value, key) => {
      if (SENSITIVE_KEY_RE.test(key)) return;
      if (/content-type|content-length|x-request-id|openai-processing-ms|server-timing/i.test(key)) {
        out[key] = value.length <= 180 ? value : `[length:${value.length}]`;
      }
    });
    return out;
  }
  function extractSemanticSignals(text, contentType) {
    const values = [];
    if (/text\/event-stream/i.test(contentType)) {
      for (const line of text.split("\n")) {
        if (!line.startsWith("data:")) continue;
        const data = line.slice(5).trim();
        if (!data || data === "[DONE]") continue;
        try {
          values.push(JSON.parse(data));
        } catch {
        }
        if (values.length >= 200) break;
      }
    } else if (/json/i.test(contentType) || /^[\s]*[{[]/.test(text)) {
      try {
        values.push(JSON.parse(text));
      } catch {
      }
    }
    const signals = [];
    for (const value of values) collectSignals(value, "$", signals, 0);
    return signals.slice(0, MAX_SIGNALS);
  }
  function collectSignals(value, path, signals, depth) {
    if (signals.length >= MAX_SIGNALS || depth > 6 || value === null || value === void 0) return;
    if (Array.isArray(value)) {
      for (let i = 0; i < Math.min(value.length, 20); i += 1) {
        collectSignals(value[i], `${path}[${i}]`, signals, depth + 1);
      }
      return;
    }
    if (typeof value !== "object") return;
    for (const [key, child] of Object.entries(value)) {
      if (SENSITIVE_KEY_RE.test(key)) continue;
      const nextPath = `${path}.${key}`;
      if (SEMANTIC_KEY_RE.test(key) && isSafeScalar(child)) {
        signals.push({ path: nextPath, value: child });
      }
      collectSignals(child, nextPath, signals, depth + 1);
      if (signals.length >= MAX_SIGNALS) return;
    }
  }
  function isSafeScalar(value) {
    if (value === null || typeof value === "number" || typeof value === "boolean") return true;
    return typeof value === "string" && value.length <= 80 && /^[\w .:/-]+$/.test(value);
  }
  function safeKeys(value) {
    return Object.keys(value).filter((key) => !SENSITIVE_KEY_RE.test(key)).slice(0, MAX_KEYS);
  }
  function unique(values) {
    return Array.from(new Set(values)).slice(0, MAX_KEYS);
  }

  // src/page/diagnostics-bridge.ts
  var CONTENT_SOURCE = "cfpt-diagnostics-content";
  var BRIDGE_SOURCE = "cfpt-diagnostics-bridge";
  var MAX_BODY_INSPECT_BYTES = 1024 * 1024;
  var channel = null;
  var installed = false;
  var requestSeq = 0;
  function emit(payload) {
    if (!channel) return;
    window.postMessage({ source: BRIDGE_SOURCE, channel, payload }, "*");
  }
  function nextId(prefix) {
    requestSeq += 1;
    return `${prefix}-${requestSeq}`;
  }
  function nowMs() {
    return Math.round(performance.now() * 100) / 100;
  }
  function bodyLengthAllowed(response) {
    const raw = response.headers.get("content-length");
    if (!raw) return true;
    const parsed = Number.parseInt(raw, 10);
    return !Number.isFinite(parsed) || parsed <= MAX_BODY_INSPECT_BYTES;
  }
  function shouldInspectResponse(response) {
    if (!bodyLengthAllowed(response)) return false;
    const contentType = response.headers.get("content-type") ?? "";
    return /json|text\/event-stream/i.test(contentType);
  }
  async function inspectFetchBody(response, id) {
    if (!shouldInspectResponse(response)) return;
    const contentType = response.headers.get("content-type") ?? "";
    try {
      const text = await response.text();
      emit({
        type: "network-body",
        transport: "fetch",
        id,
        direction: "response",
        contentType,
        summary: summarizeResponseText(text, contentType)
      });
    } catch (error) {
      emit({ type: "network-body-error", transport: "fetch", id, error: safeError(error) });
    }
  }
  function requestUrl(input) {
    if (typeof input === "string") return input;
    if (input instanceof URL) return input.toString();
    return input.url;
  }
  function requestMethod(input, init) {
    if (init?.method) return init.method.toUpperCase();
    return input instanceof Request ? input.method.toUpperCase() : "GET";
  }
  function installFetch() {
    const original = window.fetch.bind(window);
    window.fetch = async (input, init) => {
      const id = nextId("fetch");
      const startedAt = nowMs();
      emit({
        type: "network-request",
        transport: "fetch",
        id,
        method: requestMethod(input, init),
        url: redactUrl(requestUrl(input)),
        body: summarizeBody(init?.body),
        at: startedAt
      });
      try {
        const response = await original(input, init);
        emit({
          type: "network-response",
          transport: "fetch",
          id,
          url: redactUrl(response.url || requestUrl(input)),
          status: response.status,
          ok: response.ok,
          redirected: response.redirected,
          headers: safeHeaders(response.headers),
          durationMs: Math.max(0, nowMs() - startedAt)
        });
        void inspectFetchBody(response.clone(), id);
        return response;
      } catch (error) {
        emit({
          type: "network-error",
          transport: "fetch",
          id,
          durationMs: Math.max(0, nowMs() - startedAt),
          error: safeError(error)
        });
        throw error;
      }
    };
  }
  function xhrBodySummary(xhr) {
    try {
      if (xhr.responseType === "" || xhr.responseType === "text") {
        const contentType = xhr.getResponseHeader("content-type") ?? "";
        return summarizeResponseText(xhr.responseText ?? "", contentType);
      }
      if (xhr.responseType === "json") return summarizeUnknown(xhr.response);
      if (xhr.responseType === "arraybuffer" || xhr.responseType === "blob") {
        return summarizeUnknown(xhr.response);
      }
    } catch {
      return { kind: "unavailable" };
    }
    return { kind: xhr.responseType || "unknown" };
  }
  function installXhr() {
    const open = XMLHttpRequest.prototype.open;
    const send = XMLHttpRequest.prototype.send;
    const meta = /* @__PURE__ */ new WeakMap();
    XMLHttpRequest.prototype.open = function(method, url, async, username, password) {
      meta.set(this, {
        id: nextId("xhr"),
        method: method.toUpperCase(),
        url: redactUrl(String(url)),
        startedAt: 0
      });
      open.call(this, method, url, async ?? true, username ?? null, password ?? null);
    };
    XMLHttpRequest.prototype.send = function(body) {
      const info = meta.get(this);
      if (info) {
        info.startedAt = nowMs();
        emit({
          type: "network-request",
          transport: "xhr",
          id: info.id,
          method: info.method,
          url: info.url,
          body: summarizeBody(body),
          at: info.startedAt
        });
        this.addEventListener(
          "loadend",
          () => {
            emit({
              type: "network-response",
              transport: "xhr",
              id: info.id,
              url: redactUrl(this.responseURL || info.url),
              status: this.status,
              durationMs: Math.max(0, nowMs() - info.startedAt),
              body: xhrBodySummary(this)
            });
          },
          { once: true }
        );
        for (const eventName of ["error", "abort", "timeout"]) {
          this.addEventListener(
            eventName,
            () => emit({
              type: "network-error",
              transport: "xhr",
              id: info.id,
              event: eventName,
              durationMs: Math.max(0, nowMs() - info.startedAt)
            }),
            { once: true }
          );
        }
      }
      send.call(this, body ?? null);
    };
  }
  function socketDataSummary(data) {
    if (typeof data === "string") return summarizeResponseText(data, "application/json");
    return summarizeUnknown(data);
  }
  function installWebSocket() {
    const NativeWebSocket = window.WebSocket;
    class DiagnosticWebSocket extends NativeWebSocket {
      diagnosticId;
      constructor(url, protocols) {
        super(url, protocols);
        this.diagnosticId = nextId("ws");
        emit({
          type: "network-open",
          transport: "websocket",
          id: this.diagnosticId,
          url: redactUrl(String(url))
        });
        this.addEventListener(
          "open",
          () => emit({
            type: "network-state",
            transport: "websocket",
            id: this.diagnosticId,
            state: "open"
          })
        );
        this.addEventListener(
          "message",
          (event) => emit({
            type: "network-message",
            transport: "websocket",
            id: this.diagnosticId,
            direction: "receive",
            data: socketDataSummary(event.data)
          })
        );
        this.addEventListener(
          "close",
          (event) => emit({
            type: "network-state",
            transport: "websocket",
            id: this.diagnosticId,
            state: "closed",
            code: event.code,
            clean: event.wasClean
          })
        );
        this.addEventListener(
          "error",
          () => emit({ type: "network-error", transport: "websocket", id: this.diagnosticId })
        );
      }
      send(data) {
        emit({
          type: "network-message",
          transport: "websocket",
          id: this.diagnosticId,
          direction: "send",
          data: socketDataSummary(data)
        });
        super.send(data);
      }
    }
    window.WebSocket = DiagnosticWebSocket;
  }
  function installEventSource() {
    const NativeEventSource = window.EventSource;
    if (!NativeEventSource) return;
    class DiagnosticEventSource extends NativeEventSource {
      diagnosticId;
      constructor(url, eventSourceInitDict) {
        super(url, eventSourceInitDict);
        this.diagnosticId = nextId("es");
        emit({
          type: "network-open",
          transport: "eventsource",
          id: this.diagnosticId,
          url: redactUrl(String(url))
        });
        this.addEventListener(
          "open",
          () => emit({
            type: "network-state",
            transport: "eventsource",
            id: this.diagnosticId,
            state: "open"
          })
        );
        this.addEventListener(
          "message",
          (event) => emit({
            type: "network-message",
            transport: "eventsource",
            id: this.diagnosticId,
            direction: "receive",
            data: summarizeResponseText(event.data, "text/event-stream")
          })
        );
        this.addEventListener(
          "error",
          () => emit({ type: "network-error", transport: "eventsource", id: this.diagnosticId })
        );
      }
    }
    window.EventSource = DiagnosticEventSource;
  }
  function installHistory() {
    const pushState = history.pushState.bind(history);
    const replaceState = history.replaceState.bind(history);
    history.pushState = (data, unused, url) => {
      pushState(data, unused, url);
      emit({ type: "history", action: "pushState", url: redactUrl(location.href) });
    };
    history.replaceState = (data, unused, url) => {
      replaceState(data, unused, url);
      emit({ type: "history", action: "replaceState", url: redactUrl(location.href) });
    };
  }
  function install() {
    if (installed) return;
    installed = true;
    installFetch();
    installXhr();
    installWebSocket();
    installEventSource();
    installHistory();
    emit({ type: "bridge-ready", url: redactUrl(location.href) });
  }
  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || data["source"] !== CONTENT_SOURCE) return;
    if (data["action"] === "start" && typeof data["channel"] === "string") {
      channel = data["channel"];
      install();
      emit({ type: "bridge-started", url: redactUrl(location.href) });
    } else if (data["action"] === "stop" && data["channel"] === channel) {
      emit({ type: "bridge-stopped", url: redactUrl(location.href) });
      channel = null;
    }
  });
  if (!window.__CFPT_DIAGNOSTICS_BRIDGE__) {
    window.__CFPT_DIAGNOSTICS_BRIDGE__ = true;
    install();
  }
})();
