"use strict";
(() => {
  // src/common/types.ts
  var DEFAULT_SETTINGS = {
    v: 1,
    continueMessage: "continue. (End with your CHATFREEPT status block.)",
    autoContinueCap: 50,
    sendDelayMs: 8e3,
    quietMs: 3e3,
    toolQuietMs: 1e4,
    maxStreamMinutes: 20,
    contractRefreshEvery: 12,
    notificationsEnabled: true,
    templateRepo: "mlookhere/CI-Pipline"
  };

  // src/common/settings.ts
  var SETTINGS_LIMITS = {
    autoContinueCap: { min: 1, max: 500 },
    sendDelayMs: { min: 2e3, max: 6e5 },
    quietMs: { min: 1e3, max: 6e4 },
    toolQuietMs: { min: 1e3, max: 12e4 },
    maxStreamMinutes: { min: 1, max: 180 },
    contractRefreshEvery: { min: 1, max: 100 }
  };
  function asRecord(value) {
    return typeof value === "object" && value !== null ? value : {};
  }
  function normalizedNumber(source, key, fallback) {
    const value = source[key];
    if (typeof value !== "number" || !Number.isFinite(value)) return fallback;
    const { min, max } = SETTINGS_LIMITS[key];
    return Math.min(max, Math.max(min, value));
  }
  function normalizedString(source, key, fallback) {
    const value = source[key];
    if (typeof value !== "string") return fallback;
    const trimmed = value.trim();
    return trimmed || fallback;
  }
  function normalizedBoolean(source, key, fallback) {
    const value = source[key];
    return typeof value === "boolean" ? value : fallback;
  }
  function normalizeSettings(value) {
    const source = asRecord(value);
    return {
      v: DEFAULT_SETTINGS.v,
      continueMessage: normalizedString(source, "continueMessage", DEFAULT_SETTINGS.continueMessage),
      autoContinueCap: normalizedNumber(source, "autoContinueCap", DEFAULT_SETTINGS.autoContinueCap),
      sendDelayMs: normalizedNumber(source, "sendDelayMs", DEFAULT_SETTINGS.sendDelayMs),
      quietMs: normalizedNumber(source, "quietMs", DEFAULT_SETTINGS.quietMs),
      toolQuietMs: normalizedNumber(source, "toolQuietMs", DEFAULT_SETTINGS.toolQuietMs),
      maxStreamMinutes: normalizedNumber(
        source,
        "maxStreamMinutes",
        DEFAULT_SETTINGS.maxStreamMinutes
      ),
      contractRefreshEvery: normalizedNumber(
        source,
        "contractRefreshEvery",
        DEFAULT_SETTINGS.contractRefreshEvery
      ),
      notificationsEnabled: normalizedBoolean(
        source,
        "notificationsEnabled",
        DEFAULT_SETTINGS.notificationsEnabled
      ),
      templateRepo: normalizedString(source, "templateRepo", DEFAULT_SETTINGS.templateRepo)
    };
  }

  // src/common/storage.ts
  var SETTINGS_KEY = "cfpt:settings";
  async function loadSettings() {
    const storage = chrome.storage?.sync ?? chrome.storage?.local;
    if (!storage?.get) throw new Error("Chrome extension storage unavailable; reopen Chat FreePT settings after updating the extension");
    const found = await storage.get(SETTINGS_KEY);
    return normalizeSettings(found[SETTINGS_KEY]);
  }
  async function saveSettings(settings) {
    const storage = chrome.storage?.sync ?? chrome.storage?.local;
    if (!storage?.set) throw new Error("Chrome extension storage unavailable; reopen Chat FreePT settings after updating the extension");
    await storage.set({ [SETTINGS_KEY]: normalizeSettings(settings) });
  }

  // src/options/options.ts
  function el(id) {
    const found = document.getElementById(id);
    if (!found) throw new Error(`missing element #${id}`);
    return found;
  }
  function setBounds(id, min, max) {
    const input = el(id);
    input.min = String(min);
    input.max = String(max);
  }
  function render(settings) {
    el("continueMessage").value = settings.continueMessage;
    el("sendDelaySec").value = String(Math.round(settings.sendDelayMs / 1e3));
    el("quietSec").value = String(Math.round(settings.quietMs / 1e3));
    el("templateRepo").value = settings.templateRepo;
    el("notificationsEnabled").checked = settings.notificationsEnabled;
  }
  function configureBounds() {
    setBounds(
      "sendDelaySec",
      SETTINGS_LIMITS.sendDelayMs.min / 1e3,
      SETTINGS_LIMITS.sendDelayMs.max / 1e3
    );
    setBounds("quietSec", SETTINGS_LIMITS.quietMs.min / 1e3, SETTINGS_LIMITS.quietMs.max / 1e3);
  }
  async function init() {
    configureBounds();
    let settings = await loadSettings();
    render(settings);
    el("save").addEventListener("click", () => {
      void (async () => {
        const next = normalizeSettings({
          ...settings,
          continueMessage: el("continueMessage").value,
          sendDelayMs: el("sendDelaySec").valueAsNumber * 1e3,
          quietMs: el("quietSec").valueAsNumber * 1e3,
          templateRepo: el("templateRepo").value,
          notificationsEnabled: el("notificationsEnabled").checked
        });
        await saveSettings(next);
        settings = next;
        render(settings);
        const status = el("status");
        status.textContent = "Saved";
        setTimeout(() => {
          status.textContent = "";
        }, 2e3);
      })();
    });
  }
  void init();
})();
